import 'package:get/get.dart';
import 'package:crm_app/pmam/models/pmam_manager_model.dart';
import 'package:crm_app/pmam/models/pmam_investment_model.dart';
import 'package:crm_app/pmam/models/pmam_status_model.dart';
import 'package:crm_app/pmam/models/pmam_plan_model.dart';
import 'package:crm_app/services/api_service.dart';
import 'package:crm_app/widgets/custom_toast.dart';

class PmamController extends GetxController {
  static PmamController get to => Get.find();

  // ─── Loading States ─────────────────────────────────────────────────────────
  final RxBool isLoadingStatus = false.obs;
  final RxBool isLoadingManagers = false.obs;
  final RxBool isLoadingInvestments = false.obs;
  final RxBool isLoadingPlans = false.obs;
  final RxBool isLoadingDashboard = false.obs;
  final RxBool isLoadingEligibleAccounts = false.obs;
  final RxBool isLoadingPnlHistory = false.obs;
  final RxBool isLoadingFundEntries = false.obs;
  final RxBool isLoadingOpenAllocations = false.obs;
  final RxBool isSubmitting = false.obs;

  // ─── Search / Filter (Fund Managers tab) ────────────────────────────────────
  final RxString searchManagerQuery = ''.obs;
  final RxString sortBy = 'profit_percentage'.obs; // columns[x][data] key
  final RxString sortOrder = 'desc'.obs;            // asc | desc
  final RxInt pageLength = 10.obs;

  // ─── Data ───────────────────────────────────────────────────────────────────
  final Rxn<PmamStatusModel> managerStatus = Rxn<PmamStatusModel>();
  final RxList<PmamManager> managersList = <PmamManager>[].obs;
  final RxInt managersTotal = 0.obs;

  final RxList<PmamInvestment> investmentsList = <PmamInvestment>[].obs;

  // Manager-side
  final Rxn<PmamDashboardStats> dashboardStats = Rxn<PmamDashboardStats>();
  final RxList<PmamPlan> managerPlans = <PmamPlan>[].obs;
  final RxList<PmamInvestorRequest> investorRequests = <PmamInvestorRequest>[].obs;
  final Rxn<PmamPlanDetail> planDetail = Rxn<PmamPlanDetail>();

  // Investor-side
  final RxList<PmamEligibleAccount> eligibleAccounts = <PmamEligibleAccount>[].obs;
  final RxList<PmamPnlEntry> pnlHistory = <PmamPnlEntry>[].obs;
  final RxList<PmamFundEntry> fundEntries = <PmamFundEntry>[].obs;
  final RxList<PmamOpenAllocation> openAllocations = <PmamOpenAllocation>[].obs;

  // ─── Computed summaries for "My Investments" tab ────────────────────────────
  num get totalInvested => investmentsList.fold<num>(
      0, (p, e) => p + (num.tryParse(e.investedAmount ?? '0') ?? 0));

  num get totalPnl => investmentsList.fold<num>(
      0, (p, e) => p + (num.tryParse(e.totalPnl ?? '0') ?? 0));

  num get netBalance => investmentsList.fold<num>(
      0, (p, e) => p + (e.currentValue ?? 0));

  int get activePlansCount =>
      investmentsList.where((e) => e.status == 'active').length;

  @override
  void onInit() {
    super.onInit();
    fetchAllData();
  }

  // ─── Fetch all (called on init + refresh) ───────────────────────────────────
  Future<void> fetchAllData() async {
    await Future.wait([
      fetchManagerStatus(),
      fetchManagersList(),
      fetchInvestmentsList(),
    ]);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 1. MANAGER STATUS
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchManagerStatus() async {
    try {
      isLoadingStatus.value = true;
      final response = await ApiService.get(
        endpoint: 'user/pmam/manager/status',
      );
      if (response.success && response.data != null) {
        final data = response.data['data'];
        managerStatus.value =
            data != null ? PmamStatusModel.fromJson(data) : null;
      }
    } catch (e) {
      print('Error fetching PMAM manager status: $e');
    } finally {
      isLoadingStatus.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 2. APPLY AS MANAGER
  // ═══════════════════════════════════════════════════════════════════════════
  Future<bool> applyAsManager() async {
    try {
      isSubmitting.value = true;
      final response = await ApiService.post(
        endpoint: 'user/pmam/manager/apply',
        data: {'terms_accepted': true},
      );
      if (response.success) {
        CustomToastService.showSuccess(
          message: response.data?['message'] ??
              'Manager application submitted successfully.',
        );
        await fetchManagerStatus();
        return true;
      } else {
        CustomToastService.showError(
          message: response.data?['message'] ??
              'Failed to submit application. Please try again.',
        );
        return false;
      }
    } catch (e) {
      CustomToastService.showError(message: 'Error: $e');
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 3. MANAGER PLANS
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchManagerPlans() async {
    try {
      isLoadingPlans.value = true;
      final response = await ApiService.get(
        endpoint: 'user/pmam/manager/plans',
      );
      if (response.success && response.data != null) {
        final list = response.data['data'] as List? ?? [];
        managerPlans.assignAll(list.map((e) => PmamPlan.fromJson(e)).toList());
      }
    } catch (e) {
      print('Error fetching manager plans: $e');
    } finally {
      isLoadingPlans.value = false;
    }
  }

  Future<bool> createPlan({
    required int tradingAccountId,
    required String planName,
    required num commissionPercentage,
    required num minimumInvestment,
    required String strategyDescription,
    String riskInformation = '',
  }) async {
    try {
      isSubmitting.value = true;
      final response = await ApiService.post(
        endpoint: 'user/pmam/manager/plans',
        data: {
          'trading_account_id': tradingAccountId,
          'plan_name': planName,
          'commission_percentage': commissionPercentage,
          'minimum_investment': minimumInvestment,
          'strategy_description': strategyDescription,
          'risk_information': riskInformation,
        },
      );
      if (response.success) {
        CustomToastService.showSuccess(
          message: response.data?['message'] ?? 'Plan created successfully.',
        );
        await fetchManagerPlans();
        return true;
      } else {
        CustomToastService.showError(
          message: response.data?['message'] ?? 'Failed to create plan.',
        );
        return false;
      }
    } catch (e) {
      CustomToastService.showError(message: 'Error: $e');
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }

  Future<bool> inactivatePlan(int planId) async {
    try {
      isSubmitting.value = true;
      final response = await ApiService.post(
        endpoint: 'user/pmam/manager/plans/$planId/inactivate',
        data: {},
      );
      if (response.success) {
        CustomToastService.showSuccess(
            message: response.data?['message'] ?? 'Plan inactivated.');
        await fetchManagerPlans();
        return true;
      } else {
        CustomToastService.showError(
            message: response.data?['message'] ?? 'Cannot inactivate plan.');
        return false;
      }
    } catch (e) {
      CustomToastService.showError(message: 'Error: $e');
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 4. MANAGER DASHBOARD STATS
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchManagerDashboardStats() async {
    try {
      isLoadingDashboard.value = true;
      final response = await ApiService.get(
        endpoint: 'user/pmam/manager/dashboard-stats',
      );
      if (response.success && response.data != null) {
        final data = response.data['data'];
        if (data != null) {
          dashboardStats.value = PmamDashboardStats.fromJson(data);
        }
      }
    } catch (e) {
      print('Error fetching dashboard stats: $e');
    } finally {
      isLoadingDashboard.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 5. INVESTOR REQUESTS (Manager view)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchInvestorRequests(int planId) async {
    try {
      final response = await ApiService.get(
        endpoint: 'user/pmam/manager/plans/$planId/investor-requests',
      );
      if (response.success && response.data != null) {
        final list = response.data['data'] as List? ?? [];
        investorRequests.assignAll(
            list.map((e) => PmamInvestorRequest.fromJson(e)).toList());
      }
    } catch (e) {
      print('Error fetching investor requests: $e');
    }
  }

  Future<bool> approveInvestorRequest(int requestId) async {
    try {
      isSubmitting.value = true;
      final response = await ApiService.post(
        endpoint: 'user/pmam/manager/investor-requests/$requestId/approve',
        data: {},
      );
      if (response.success) {
        CustomToastService.showSuccess(
            message: response.data?['message'] ?? 'Investor request approved.');
        investorRequests.removeWhere((e) => e.id == requestId);
        return true;
      } else {
        CustomToastService.showError(
            message: response.data?['message'] ?? 'Failed to approve request.');
        return false;
      }
    } catch (e) {
      CustomToastService.showError(message: 'Error: $e');
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }

  Future<bool> rejectInvestorRequest(int requestId) async {
    try {
      isSubmitting.value = true;
      final response = await ApiService.post(
        endpoint: 'user/pmam/manager/investor-requests/$requestId/reject',
        data: {},
      );
      if (response.success) {
        CustomToastService.showSuccess(
            message: response.data?['message'] ?? 'Investor request rejected.');
        investorRequests.removeWhere((e) => e.id == requestId);
        return true;
      } else {
        CustomToastService.showError(
            message: response.data?['message'] ?? 'Failed to reject request.');
        return false;
      }
    } catch (e) {
      CustomToastService.showError(message: 'Error: $e');
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 6. PLAN DETAIL (Manager view)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchPlanDetail(int planId) async {
    try {
      final response = await ApiService.get(
        endpoint: 'user/pmam/manager/plans/$planId/detail',
      );
      if (response.success && response.data != null) {
        final data = response.data['data'];
        if (data != null) {
          planDetail.value = PmamPlanDetail.fromJson(data);
        }
      }
    } catch (e) {
      print('Error fetching plan detail: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 7. MANAGERS LIST (Investor – Fund Managers tab)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchManagersList({String? query}) async {
    try {
      isLoadingManagers.value = true;
      if (query != null) searchManagerQuery.value = query;

      // Map sortBy friendly label → column data key
      final columnIndex = _columnIndexForSort(sortBy.value);

      final payload = {
        'draw': 1,
        'start': 0,
        'length': pageLength.value,
        'search[value]': searchManagerQuery.value,
        'search[regex]': false,
        'order[0][column]': columnIndex,
        'order[0][dir]': sortOrder.value,
        'columns[0][data]': 'manager_name',
        'columns[0][searchable]': true,
        'columns[1][data]': 'manager_code',
        'columns[1][searchable]': true,
        'columns[2][data]': 'plans_count',
        'columns[3][data]': 'total_aum',
        'columns[4][data]': 'total_investors',
        'columns[5][data]': 'avg_commission',
        'columns[6][data]': 'profit_percentage',
        'columns[7][data]': 'member_since',
      };

      final response = await ApiService.post(
        endpoint: 'user/pmam/managers/datatable',
        data: payload,
      );

      if (response.success && response.data != null) {
        final dtResponse =
            PmamManagerDataTableResponse.fromJson(response.data);
        managersList.assignAll(dtResponse.data ?? []);
        managersTotal.value = dtResponse.recordsFiltered ?? 0;
      }
    } catch (e) {
      print('Error fetching PMAM managers list: $e');
    } finally {
      isLoadingManagers.value = false;
    }
  }

  int _columnIndexForSort(String key) {
    switch (key) {
      case 'manager_name':
        return 0;
      case 'manager_code':
        return 1;
      case 'plans_count':
        return 2;
      case 'total_aum':
        return 3;
      case 'total_investors':
        return 4;
      case 'avg_commission':
        return 5;
      case 'profit_percentage':
      default:
        return 6;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 8. MY INVESTMENTS (Investor)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchInvestmentsList() async {
    try {
      isLoadingInvestments.value = true;
      final response = await ApiService.get(
        endpoint: 'user/pmam/investor/enrollments',
      );
      if (response.success && response.data != null) {
        final investmentResponse =
            PmamInvestmentResponse.fromJson(response.data);
        investmentsList.assignAll(investmentResponse.data ?? []);
      }
    } catch (e) {
      print('Error fetching PMAM investments list: $e');
    } finally {
      isLoadingInvestments.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 9. ELIGIBLE ACCOUNTS (Investor)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchEligibleAccounts({int? planId}) async {
    try {
      isLoadingEligibleAccounts.value = true;
      final response = await ApiService.get(
        endpoint: 'user/pmam/investor/eligible-accounts',
        queryParameters: planId != null ? {'plan_id': planId} : null,
      );
      if (response.success && response.data != null) {
        final list = response.data['data'] as List? ?? [];
        eligibleAccounts.assignAll(
            list.map((e) => PmamEligibleAccount.fromJson(e)).toList());
      }
    } catch (e) {
      print('Error fetching eligible accounts: $e');
    } finally {
      isLoadingEligibleAccounts.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 10. REQUEST JOIN (Investor subscribe)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<bool> requestJoin({
    required int planId,
    required int investorAccountId,
    required num amount,
  }) async {
    try {
      isSubmitting.value = true;
      final response = await ApiService.post(
        endpoint: 'user/pmam/investor/request-join',
        data: {
          'plan_id': planId,
          'investor_account_id': investorAccountId,
          'amount': amount,
        },
      );
      if (response.success) {
        CustomToastService.showSuccess(
            message: response.data?['message'] ??
                'Join request submitted. Awaiting manager approval.');
        await fetchInvestmentsList();
        return true;
      } else {
        CustomToastService.showError(
            message: response.data?['message'] ?? 'Failed to submit request.');
        return false;
      }
    } catch (e) {
      CustomToastService.showError(message: 'Error: $e');
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 11. DEPOSIT FUNDS (Investor)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<bool> depositFunds({
    required int pmamInvestorId,
    required num amount,
  }) async {
    try {
      isSubmitting.value = true;
      final response = await ApiService.post(
        endpoint: 'user/pmam/investor/deposit',
        data: {
          'pmam_investor_id': pmamInvestorId,
          'amount': amount,
        },
      );
      if (response.success) {
        CustomToastService.showSuccess(
            message: response.data?['message'] ?? 'Deposit added successfully.');
        await fetchInvestmentsList();
        return true;
      } else {
        CustomToastService.showError(
            message: response.data?['message'] ?? 'Failed to deposit.');
        return false;
      }
    } catch (e) {
      CustomToastService.showError(message: 'Error: $e');
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 12. UNSUBSCRIBE (Investor)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<bool> unsubscribe(int pmamInvestorId) async {
    try {
      isSubmitting.value = true;
      final response = await ApiService.post(
        endpoint: 'user/pmam/investor/unsubscribe/$pmamInvestorId',
        data: {},
      );
      if (response.success) {
        CustomToastService.showSuccess(
            message: response.data?['message'] ?? 'Unsubscribe request accepted.');
        await fetchInvestmentsList();
        return true;
      } else {
        CustomToastService.showError(
            message: response.data?['message'] ?? 'Failed to unsubscribe.');
        return false;
      }
    } catch (e) {
      CustomToastService.showError(message: 'Error: $e');
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 13. P&L HISTORY (Investor)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchPnlHistory() async {
    try {
      isLoadingPnlHistory.value = true;
      final response = await ApiService.get(
        endpoint: 'user/pmam/investor/pnl-history',
      );
      if (response.success && response.data != null) {
        final list = response.data['data'] as List? ?? [];
        pnlHistory.assignAll(
            list.map((e) => PmamPnlEntry.fromJson(e)).toList());
      }
    } catch (e) {
      print('Error fetching P&L history: $e');
    } finally {
      isLoadingPnlHistory.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 14. FUND ENTRIES (Investor)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchFundEntries() async {
    try {
      isLoadingFundEntries.value = true;
      final response = await ApiService.get(
        endpoint: 'user/pmam/investor/my-fund-entries',
      );
      if (response.success && response.data != null) {
        final list = response.data['data'] as List? ?? [];
        fundEntries.assignAll(
            list.map((e) => PmamFundEntry.fromJson(e)).toList());
      }
    } catch (e) {
      print('Error fetching fund entries: $e');
    } finally {
      isLoadingFundEntries.value = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 15. OPEN ALLOCATIONS (Investor)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> fetchOpenAllocations() async {
    try {
      isLoadingOpenAllocations.value = true;
      final response = await ApiService.get(
        endpoint: 'user/pmam/investor/my-open-allocations',
      );
      if (response.success && response.data != null) {
        final list = response.data['data'] as List? ?? [];
        openAllocations.assignAll(
            list.map((e) => PmamOpenAllocation.fromJson(e)).toList());
      }
    } catch (e) {
      print('Error fetching open allocations: $e');
    } finally {
      isLoadingOpenAllocations.value = false;
    }
  }

  // ─── Refresh helpers ─────────────────────────────────────────────────────────
  Future<void> refreshManagers() async => await fetchManagersList();
  Future<void> refreshInvestments() async => await fetchInvestmentsList();
}
