// ─── Manager Plan (used in both create & list) ───────────────────────────────
class PmamPlan {
  int? id;
  String? planName;
  int? tradingAccountId;
  String? tradingAccountNumber;
  num? commissionPercentage;
  num? minimumInvestment;
  String? strategyDescription;
  String? riskInformation;
  String? status;
  int? activeInvestors;
  num? totalLocked;
  num? totalInvestorEquity;
  num? poolBalance;
  num? managerOwnFund;
  String? createdAt;

  PmamPlan({
    this.id,
    this.planName,
    this.tradingAccountId,
    this.tradingAccountNumber,
    this.commissionPercentage,
    this.minimumInvestment,
    this.strategyDescription,
    this.riskInformation,
    this.status,
    this.activeInvestors,
    this.totalLocked,
    this.totalInvestorEquity,
    this.poolBalance,
    this.managerOwnFund,
    this.createdAt,
  });

  PmamPlan.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    planName = json['plan_name'];
    tradingAccountId = json['trading_account_id'];
    tradingAccountNumber = json['trading_account_number'];
    commissionPercentage = _parseNum(json['commission_percentage']);
    minimumInvestment = _parseNum(json['minimum_investment']);
    strategyDescription = json['strategy_description'];
    riskInformation = json['risk_information'];
    status = json['status'];
    activeInvestors = json['active_investors'];
    totalLocked = _parseNum(json['total_locked']);
    totalInvestorEquity = _parseNum(json['total_investor_equity']);
    poolBalance = _parseNum(json['pool_balance']);
    managerOwnFund = _parseNum(json['manager_own_fund']);
    createdAt = json['created_at'];
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

// ─── Manager Dashboard Stats ──────────────────────────────────────────────────
class PmamDashboardStats {
  int? totalPlans;
  int? activeInvestors;
  int? pendingRequests;
  num? totalLockedAum;
  num? totalLotsTraded;
  num? totalPnl;
  num? totalCommission;
  num? commissionThisMonth;
  List<PmamRecentCommission>? recentCommissions;

  PmamDashboardStats({
    this.totalPlans,
    this.activeInvestors,
    this.pendingRequests,
    this.totalLockedAum,
    this.totalLotsTraded,
    this.totalPnl,
    this.totalCommission,
    this.commissionThisMonth,
    this.recentCommissions,
  });

  PmamDashboardStats.fromJson(Map<String, dynamic> json) {
    totalPlans = json['total_plans'];
    activeInvestors = json['active_investors'];
    pendingRequests = json['pending_requests'];
    totalLockedAum = _parseNum(json['total_locked_aum']);
    totalLotsTraded = _parseNum(json['total_lots_traded']);
    totalPnl = _parseNum(json['total_pnl']);
    totalCommission = _parseNum(json['total_commission']);
    commissionThisMonth = _parseNum(json['commission_this_month']);
    if (json['recent_commissions'] != null) {
      recentCommissions = (json['recent_commissions'] as List)
          .map((e) => PmamRecentCommission.fromJson(e))
          .toList();
    }
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

class PmamRecentCommission {
  String? investorName;
  int? planId;
  num? grossProfitShare;
  num? commissionCharged;
  num? netProfitCredited;
  String? settledAt;

  PmamRecentCommission.fromJson(Map<String, dynamic> json) {
    investorName = json['investor_name'];
    planId = json['plan_id'];
    grossProfitShare = _parseNum(json['gross_profit_share']);
    commissionCharged = _parseNum(json['commission_charged']);
    netProfitCredited = _parseNum(json['net_profit_credited']);
    settledAt = json['settled_at'];
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

// ─── Investor Request (Manager view) ─────────────────────────────────────────
class PmamInvestorRequest {
  int? id;
  int? investorUserId;
  int? pmamPlanId;
  num? investedAmount;
  String? status;
  String? createdAt;
  PmamRequestUser? user;
  PmamInvestorAccount? investorAccount;

  PmamInvestorRequest.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    investorUserId = json['investor_user_id'];
    pmamPlanId = json['pmam_plan_id'];
    investedAmount = _parseNum(json['invested_amount']);
    status = json['status'];
    createdAt = json['created_at'];
    user = json['user'] != null ? PmamRequestUser.fromJson(json['user']) : null;
    investorAccount = json['investor_account'] != null
        ? PmamInvestorAccount.fromJson(json['investor_account'])
        : null;
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

class PmamRequestUser {
  int? id;
  String? firstName;
  String? lastName;
  String? email;

  PmamRequestUser.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    email = json['email'];
  }

  String get fullName => '${firstName ?? ''} ${lastName ?? ''}'.trim();
}

class PmamInvestorAccount {
  int? id;
  String? metaAccountNumber;
  num? balance;
  num? pmamLockedAmount;

  PmamInvestorAccount.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    metaAccountNumber = json['meta_account_number'];
    balance = _parseNum(json['balance']);
    pmamLockedAmount = _parseNum(json['pmam_locked_amount']);
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }

  num get availableBalance => (balance ?? 0) - (pmamLockedAmount ?? 0);
}

// ─── Plan Detail (Manager view) ───────────────────────────────────────────────
class PmamPlanDetail {
  PmamPlanDetailInfo? plan;
  num? withdrawable;
  bool? canWithdraw;
  String? withdrawMessage;
  List<PmamPlanInvestor>? investors;
  List<PmamUniqueInvestor>? uniqueInvestors;

  PmamPlanDetail.fromJson(Map<String, dynamic> json) {
    plan = json['plan'] != null
        ? PmamPlanDetailInfo.fromJson(json['plan'])
        : null;
    withdrawable = _parseNum(json['withdrawable']);
    canWithdraw = json['can_withdraw'];
    withdrawMessage = json['withdraw_message'];
    if (json['investors'] != null) {
      investors = (json['investors'] as List)
          .map((e) => PmamPlanInvestor.fromJson(e))
          .toList();
    }
    if (json['unique_investors'] != null) {
      uniqueInvestors = (json['unique_investors'] as List)
          .map((e) => PmamUniqueInvestor.fromJson(e))
          .toList();
    }
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

class PmamPlanDetailInfo {
  int? id;
  String? planName;
  num? totalAum;
  num? totalPnl;
  num? totalCommission;
  int? activeInvestors;
  num? commissionPct;

  PmamPlanDetailInfo.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    planName = json['plan_name'];
    totalAum = _parseNum(json['total_aum']);
    totalPnl = _parseNum(json['total_pnl']);
    totalCommission = _parseNum(json['total_commission']);
    activeInvestors = json['active_investors'];
    commissionPct = _parseNum(json['commission_pct']);
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

class PmamPlanInvestor {
  int? id;
  int? investorUserId;
  String? investorName;
  String? investorEmail;
  String? status;
  String? activeSince;
  String? inactiveSince;
  num? investedAmount;

  PmamPlanInvestor.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    investorUserId = json['investor_user_id'];
    investorName = json['investor_name'];
    investorEmail = json['investor_email'];
    status = json['status'];
    activeSince = json['active_since'];
    inactiveSince = json['inactive_since'];
    investedAmount = _parseNum(json['invested_amount']);
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

class PmamUniqueInvestor {
  int? userId;
  String? investorName;
  String? investorEmail;

  PmamUniqueInvestor.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    investorName = json['investor_name'];
    investorEmail = json['investor_email'];
  }
}

// ─── Eligible Accounts ────────────────────────────────────────────────────────
class PmamEligibleAccount {
  int? id;
  String? metaAccountNumber;
  num? balance;
  num? pmamLockedAmount;
  String? currency;

  PmamEligibleAccount.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    metaAccountNumber = json['meta_account_number'];
    balance = _parseNum(json['balance']);
    pmamLockedAmount = _parseNum(json['pmam_locked_amount']);
    currency = json['currency'];
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }

  num get availableBalance => (balance ?? 0) - (pmamLockedAmount ?? 0);
}

// ─── P&L History entry ────────────────────────────────────────────────────────
class PmamPnlEntry {
  int? tradeId;
  num? grossProfitShare;
  num? commissionCharged;
  num? netProfitCredited;
  String? settledAt;

  PmamPnlEntry.fromJson(Map<String, dynamic> json) {
    tradeId = json['trade_id'];
    grossProfitShare = _parseNum(json['gross_profit_share']);
    commissionCharged = _parseNum(json['commission_charged']);
    netProfitCredited = _parseNum(json['net_profit_credited']);
    settledAt = json['settled_at'];
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

// ─── Fund Entry ───────────────────────────────────────────────────────────────
class PmamFundEntry {
  int? id;
  num? amount;
  String? type;
  String? typeLabel;
  String? entryTime;
  String? status;

  PmamFundEntry.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    amount = _parseNum(json['amount']);
    type = json['type'];
    typeLabel = json['type_label'];
    entryTime = json['entry_time'];
    status = json['status'];
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }
}

// ─── Open Allocation ──────────────────────────────────────────────────────────
class PmamOpenAllocation {
  int? id;
  int? positionId;
  String? tradeSymbol;
  int? tradeType; // 0=Buy, 1=Sell
  num? allocatedLot;
  num? allocationPercentage;
  num? openPrice;
  String? openTime;
  String? status;

  PmamOpenAllocation.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    positionId = json['position_id'];
    tradeSymbol = json['trade_symbol'];
    tradeType = json['trade_type'];
    allocatedLot = _parseNum(json['allocated_lot']);
    allocationPercentage = _parseNum(json['allocation_percentage']);
    openPrice = _parseNum(json['open_price']);
    openTime = json['open_time'];
    status = json['status'];
  }

  num? _parseNum(dynamic v) {
    if (v == null) return null;
    if (v is num) return v;
    return num.tryParse(v.toString());
  }

  String get tradeTypeLabel => tradeType == 0 ? 'Buy' : 'Sell';
}
