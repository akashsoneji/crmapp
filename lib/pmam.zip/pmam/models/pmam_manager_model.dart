class PmamManagerDataTableResponse {
  int? draw;
  int? recordsTotal;
  int? recordsFiltered;
  List<PmamManager>? data;

  PmamManagerDataTableResponse({this.draw, this.recordsTotal, this.recordsFiltered, this.data});

  PmamManagerDataTableResponse.fromJson(Map<String, dynamic> json) {
    draw = json['draw'];
    recordsTotal = json['recordsTotal'];
    recordsFiltered = json['recordsFiltered'];
    if (json['data'] != null) {
      data = <PmamManager>[];
      json['data'].forEach((v) {
        data!.add(PmamManager.fromJson(v));
      });
    }
  }
}

class PmamManager {
  int? id;
  int? userId;
  String? managerCode;
  String? managerName;
  String? strategyDescription;
  String? riskInformation;
  String? status;
  int? plansCount;
  num? totalAum;
  int? totalInvestors;
  num? avgCommission;
  num? profitPercentage;
  String? memberSince;
  User? user;
  List<Plan>? plans;

  PmamManager({
    this.id,
    this.userId,
    this.managerCode,
    this.managerName,
    this.strategyDescription,
    this.riskInformation,
    this.status,
    this.plansCount,
    this.totalAum,
    this.totalInvestors,
    this.avgCommission,
    this.profitPercentage,
    this.memberSince,
    this.user,
    this.plans,
  });

  PmamManager.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    managerCode = json['manager_code'];
    managerName = json['manager_name'];
    strategyDescription = json['strategy_description'];
    riskInformation = json['risk_information'];
    status = json['status'];
    plansCount = json['plans_count'];
    totalAum = json['total_aum'];
    totalInvestors = json['total_investors'];
    avgCommission = json['avg_commission'];
    profitPercentage = json['profit_percentage'];
    memberSince = json['member_since'];
    user = json['user'] != null ? User.fromJson(json['user']) : null;
    if (json['plans'] != null) {
      plans = <Plan>[];
      json['plans'].forEach((v) {
        plans!.add(Plan.fromJson(v));
      });
    }
  }
}

class User {
  int? id;
  String? email;
  String? firstName;
  String? lastName;
  String? mobile;

  User({this.id, this.email, this.firstName, this.lastName, this.mobile});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    email = json['email'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    mobile = json['mobile'];
  }
}

class Plan {
  int? id;
  String? planName;
  String? commissionPercentage;
  String? minimumInvestment;
  String? strategyDescription;
  String? riskInformation;
  String? status;

  Plan({
    this.id,
    this.planName,
    this.commissionPercentage,
    this.minimumInvestment,
    this.strategyDescription,
    this.riskInformation,
    this.status,
  });

  Plan.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    planName = json['plan_name'];
    commissionPercentage = json['commission_percentage'];
    minimumInvestment = json['minimum_investment'];
    strategyDescription = json['strategy_description'];
    riskInformation = json['risk_information'];
    status = json['status'];
  }
}
