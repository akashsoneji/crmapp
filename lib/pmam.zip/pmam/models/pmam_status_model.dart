class PmamStatusModel {
  String? status; // pending | approved | rejected | inactive
  String? managerCode;

  PmamStatusModel({this.status, this.managerCode});

  PmamStatusModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    managerCode = json['manager_code'];
  }

  Map<String, dynamic> toJson() => {
        'status': status,
        'manager_code': managerCode,
      };

  bool get isApproved => status == 'approved';
  bool get isPending => status == 'pending';
  bool get isRejected => status == 'rejected';
  bool get isInactive => status == 'inactive';
}
