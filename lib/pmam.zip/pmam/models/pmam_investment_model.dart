class PmamInvestmentResponse {
  bool? status;
  bool? success;
  String? message;
  List<PmamInvestment>? data;

  PmamInvestmentResponse({this.status, this.success, this.message, this.data});

  PmamInvestmentResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    success = json['success'];
    message = json['message'];
    if (json['data'] != null) {
      data = <PmamInvestment>[];
      json['data'].forEach((v) {
        data!.add(PmamInvestment.fromJson(v));
      });
    }
  }
}

class PmamInvestment {
  int? id;
  int? planId;
  String? planName;
  String? commissionPercentage;
  String? managerName;
  String? managerCode;
  int? investorAccountId;
  String? accountNumber;
  num? accountBalance;
  num? pmamLockedAmount;
  String? investedAmount;
  String? totalPnl;
  num? currentValue;
  String? status;
  String? activeSince;
  String? inactiveSince;
  String? createdAt;

  PmamInvestment({
    this.id,
    this.planId,
    this.planName,
    this.commissionPercentage,
    this.managerName,
    this.managerCode,
    this.investorAccountId,
    this.accountNumber,
    this.accountBalance,
    this.pmamLockedAmount,
    this.investedAmount,
    this.totalPnl,
    this.currentValue,
    this.status,
    this.activeSince,
    this.inactiveSince,
    this.createdAt,
  });

  PmamInvestment.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    planId = json['plan_id'];
    planName = json['plan_name'];
    commissionPercentage = json['commission_percentage'];
    managerName = json['manager_name'];
    managerCode = json['manager_code'];
    investorAccountId = json['investor_account_id'];
    accountNumber = json['account_number'];
    accountBalance = json['account_balance'];
    pmamLockedAmount = json['pmam_locked_amount'];
    investedAmount = json['invested_amount'];
    totalPnl = json['total_pnl'];
    currentValue = json['current_value'];
    status = json['status'];
    activeSince = json['active_since'];
    inactiveSince = json['inactive_since'];
    createdAt = json['created_at'];
  }
}
