import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:crm_app/constants/color.dart';

import 'package:crm_app/pmam/controllers/pmam_controller.dart';

class PmamManagerApplicationScreen extends StatelessWidget {
  const PmamManagerApplicationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final PmamController ctrl = Get.isRegistered<PmamController>()
        ? Get.find<PmamController>()
        : Get.put(PmamController());

    final RxBool termsAccepted = false.obs;

    WidgetsBinding.instance.addPostFrameCallback(
        (_) => ctrl.fetchManagerStatus());

    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            pinned: true,
            expandedHeight: 140.h,
            backgroundColor: AppColors.primary,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
              onPressed: () => Get.back(),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppColors.primary,
                      AppColors.primary.withValues(alpha: 0.7)
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(56.w, 16.h, 20.w, 16.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text('Become a Manager',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 22.sp,
                                fontWeight: FontWeight.bold)),
                        SizedBox(height: 4.h),
                        Text(
                            'Complete the steps below to start managing investor funds',
                            style: TextStyle(
                                color: Colors.white70, fontSize: 12.sp)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
        body: Obx(() {
          final status = ctrl.managerStatus.value;
          final appStatus = status?.status;
          return SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16.w, 16.h, 16.w, 32.h),
            child: Column(
              children: [
                // ─── Status Banner ───────────────────────────────────────────
                if (appStatus != null) ...[
                  _statusBanner(appStatus, status?.managerCode),
                  SizedBox(height: 16.h),
                ],

                // ─── Progress Steps ──────────────────────────────────────────
                _sectionLabel('Application Steps'),
                SizedBox(height: 10.h),
                _buildStepsCard(appStatus),
                SizedBox(height: 16.h),

                // ─── Benefits ────────────────────────────────────────────────
                _sectionLabel('Benefits'),
                SizedBox(height: 10.h),
                _buildBenefitsCard(),
                SizedBox(height: 16.h),

                // ─── Terms & Submit (if can apply) ───────────────────────────
                if (appStatus == null ||
                    appStatus == 'rejected' ||
                    appStatus == 'inactive') ...[
                  _buildTermsAndSubmit(ctrl, termsAccepted),
                ],

                // ─── Approved CTA: go to Manager Dashboard ───────────────────
                if (appStatus == 'approved') ...[
                  _buildApprovedCard(status?.managerCode),
                ],
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(text,
          style: TextStyle(
              fontSize: 13.sp,
              fontWeight: FontWeight.w700,
              color: Colors.grey.shade600,
              letterSpacing: 0.4)),
    );
  }

  // ─── Steps progress card ──────────────────────────────────────────────────
  Widget _buildStepsCard(String? appStatus) {
    final steps = [
      {'icon': Icons.email_outlined, 'label': 'Email Verified', 'done': true},
      {'icon': Icons.phone_android_outlined, 'label': 'Mobile Verified', 'done': true},
      {'icon': Icons.person_outlined, 'label': 'Personal Info', 'done': true},
      {
        'icon': Icons.badge_outlined,
        'label': 'Identity Verified',
        'done': true
      },
      {
        'icon': Icons.trending_up_outlined,
        'label': 'PMAM Application',
        'done': appStatus == 'approved',
        'pending': appStatus == 'pending',
      },
    ];

    return Container(
      decoration: _cardDecor(),
      padding: EdgeInsets.symmetric(vertical: 8.h),
      child: Column(
        children: steps.asMap().entries.map((entry) {
          final i = entry.key;
          final s = entry.value;
          final isDone = s['done'] as bool;
          final isPending = (s['pending'] as bool?) ?? false;
          final isLast = i == steps.length - 1;

          final dotColor = isDone
              ? AppColors.primary
              : isPending
                  ? Colors.orange
                  : Colors.grey.shade300;

          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left timeline
              Padding(
                padding: EdgeInsets.only(left: 20.w, right: 12.w),
                child: Column(
                  children: [
                    Container(
                      width: 36.w,
                      height: 36.w,
                      decoration: BoxDecoration(
                        color: dotColor.withValues(alpha: isDone ? 0.12 : 0.1),
                        shape: BoxShape.circle,
                        border: Border.all(color: dotColor, width: 1.5),
                      ),
                      child: Center(
                        child: Icon(
                          isDone
                              ? Icons.check_rounded
                              : (s['icon'] as IconData),
                          size: 16.sp,
                          color: dotColor,
                        ),
                      ),
                    ),
                    if (!isLast)
                      Container(
                          width: 1.5,
                          height: 28.h,
                          color: isDone
                              ? AppColors.primary.withValues(alpha: 0.3)
                              : Colors.grey.shade200),
                  ],
                ),
              ),
              // Content
              Expanded(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(0, 6.h, 16.w, isLast ? 8.h : 0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(s['label'] as String,
                            style: TextStyle(
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w600,
                                color: isDone
                                    ? const Color(0xFF1A1A2E)
                                    : Colors.grey)),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 8.w, vertical: 3.h),
                        decoration: BoxDecoration(
                          color: dotColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: Text(
                          isDone
                              ? 'Done'
                              : isPending
                                  ? 'Pending'
                                  : 'Required',
                          style: TextStyle(
                              fontSize: 10.sp,
                              fontWeight: FontWeight.bold,
                              color: dotColor),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        }).toList(),
      ),
    );
  }

  // ─── Benefits card ────────────────────────────────────────────────────────
  Widget _buildBenefitsCard() {
    final benefits = [
      {'icon': Icons.account_balance_wallet_outlined, 'text': 'Earn commission on investor profits'},
      {'icon': Icons.shield_outlined, 'text': 'Segregated investor funds — fully protected'},
      {'icon': Icons.analytics_outlined, 'text': 'Real-time dashboard with P&L visibility'},
      {'icon': Icons.people_alt_outlined, 'text': 'Approve or reject investor requests'},
    ];
    return Container(
      decoration: _cardDecor(),
      padding: EdgeInsets.all(16.w),
      child: Column(
        children: benefits.map((b) {
          return Padding(
            padding: EdgeInsets.only(bottom: 12.h),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(b['icon'] as IconData,
                      size: 16.sp, color: AppColors.primary),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Text(b['text'] as String,
                      style: TextStyle(
                          fontSize: 13.sp,
                          color: const Color(0xFF3D3D5C))),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  // ─── Terms & Submit ────────────────────────────────────────────────────────
  Widget _buildTermsAndSubmit(PmamController ctrl, RxBool termsAccepted) {
    return Column(
      children: [
        Container(
          decoration: _cardDecor(),
          padding: EdgeInsets.all(14.w),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Obx(() => Transform.scale(
                    scale: 1.1,
                    child: Checkbox(
                      value: termsAccepted.value,
                      onChanged: (v) => termsAccepted.value = v ?? false,
                      activeColor: AppColors.primary,
                      materialTapTargetSize:
                          MaterialTapTargetSize.shrinkWrap,
                    ),
                  )),
              SizedBox(width: 6.w),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(top: 10.h),
                  child: RichText(
                    text: TextSpan(
                      style: TextStyle(
                          fontSize: 12.sp,
                          color: Colors.grey.shade700,
                          height: 1.5),
                      children: [
                        const TextSpan(text: 'I accept the '),
                        TextSpan(
                          text: 'PMAM Manager Terms & Conditions',
                          style: TextStyle(
                              color: AppColors.primary,
                              fontWeight: FontWeight.bold),
                        ),
                        const TextSpan(
                            text:
                                ' and confirm all information provided is accurate.'),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 16.h),
        Obx(() => SizedBox(
              width: double.infinity,
              height: 50.h,
              child: ElevatedButton(
                onPressed: (termsAccepted.value &&
                        !ctrl.isSubmitting.value)
                    ? () async => await ctrl.applyAsManager()
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  disabledBackgroundColor:
                      Colors.grey.shade300,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.r)),
                ),
                child: ctrl.isSubmitting.value
                    ? SizedBox(
                        height: 20.h,
                        width: 20.h,
                        child: const CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.send_outlined,
                              color: Colors.white, size: 18.sp),
                          SizedBox(width: 8.w),
                          Text('Submit Application',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15.sp,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
              ),
            )),
      ],
    );
  }

  // ─── Approved card ────────────────────────────────────────────────────────
  Widget _buildApprovedCard(String? managerCode) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.green.shade400,
            Colors.green.shade600,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14.r),
      ),
      child: Column(
        children: [
          Icon(Icons.check_circle_outline,
              color: Colors.white, size: 48.sp),
          SizedBox(height: 12.h),
          Text('You\'re an Approved Manager!',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 17.sp,
                  fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
          SizedBox(height: 6.h),
          if (managerCode != null)
            Text('Manager Code: $managerCode',
                style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.85),
                    fontSize: 13.sp)),
          SizedBox(height: 20.h),
          SizedBox(
            width: double.infinity,
            height: 44.h,
            child: ElevatedButton(
              onPressed: () {
                // Not importing ManagerDashboardScreen here to avoid circular deps
                // Navigation handled in more_screen
                Get.back();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.green.shade700,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.r)),
              ),
              child: Text('Go to Manager Dashboard',
                  style: TextStyle(
                      fontSize: 14.sp, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Status banner ─────────────────────────────────────────────────────────
  Widget _statusBanner(String status, String? code) {
    late Color bg, border, textColor;
    late IconData icon;
    late String title, message;

    switch (status) {
      case 'pending':
        bg = Colors.orange.shade50;
        border = Colors.orange.shade200;
        textColor = Colors.orange.shade800;
        icon = Icons.hourglass_top_rounded;
        title = 'Application Under Review';
        message = 'Your application is being reviewed. We\'ll notify you once it is approved.';
        break;
      case 'approved':
        bg = Colors.green.shade50;
        border = Colors.green.shade200;
        textColor = Colors.green.shade800;
        icon = Icons.check_circle_rounded;
        title = 'Approved!';
        message = 'Your PMAM manager application was approved.${code != null ? '\nCode: $code' : ''}';
        break;
      case 'rejected':
        bg = Colors.red.shade50;
        border = Colors.red.shade200;
        textColor = Colors.red.shade800;
        icon = Icons.cancel_rounded;
        title = 'Application Rejected';
        message = 'Your application was rejected. You may re-apply by accepting the terms below.';
        break;
      case 'inactive':
        bg = Colors.grey.shade100;
        border = Colors.grey.shade300;
        textColor = Colors.grey.shade700;
        icon = Icons.block_rounded;
        title = 'Account Inactive';
        message = 'Your manager account is inactive. Re-apply below.';
        break;
      default:
        return const SizedBox.shrink();
    }

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(14.w),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: textColor, size: 22.sp),
          SizedBox(width: 10.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: TextStyle(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.bold,
                        color: textColor)),
                SizedBox(height: 3.h),
                Text(message,
                    style: TextStyle(
                        fontSize: 12.sp, color: textColor.withValues(alpha: 0.85))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  BoxDecoration _cardDecor() => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      );
}
