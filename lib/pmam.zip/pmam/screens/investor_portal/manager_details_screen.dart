import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:crm_app/constants/color.dart';

import 'package:crm_app/pmam/models/pmam_manager_model.dart';
import 'package:crm_app/pmam/controllers/pmam_controller.dart';
import 'package:fl_chart/fl_chart.dart';

class ManagerDetailsScreen extends StatefulWidget {
  final PmamManager manager;
  const ManagerDetailsScreen({super.key, required this.manager});

  @override
  State<ManagerDetailsScreen> createState() => _ManagerDetailsScreenState();
}

class _ManagerDetailsScreenState extends State<ManagerDetailsScreen>
    with SingleTickerProviderStateMixin {
  final controller = Get.find<PmamController>();
  late TabController _tabCtrl;
  String _timeFilter = '1M';

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    controller.fetchEligibleAccounts(planId: _firstPlanId);
  }

  int? get _firstPlanId => widget.manager.plans?.isNotEmpty == true
      ? widget.manager.plans!.first.id
      : null;

  Plan? get _firstPlan => widget.manager.plans?.isNotEmpty == true
      ? widget.manager.plans!.first
      : null;

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            pinned: true,
            expandedHeight: 200.h,
            backgroundColor: AppColors.primary,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
              onPressed: () => Get.back(),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: _buildHeroHeader(),
            ),
          ),
        ],
        body: Column(
          children: [
            // Stats band
            _buildStatsStrip(),
            // Tab bar
            Container(
              color: Colors.white,
              child: TabBar(
                controller: _tabCtrl,
                labelColor: AppColors.primary,
                unselectedLabelColor: Colors.grey,
                indicatorColor: AppColors.primary,
                indicatorWeight: 3,
                labelStyle: TextStyle(
                    fontSize: 13.sp, fontWeight: FontWeight.w600),
                tabs: const [
                  Tab(text: 'Overview'),
                  Tab(text: 'Plans'),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabCtrl,
                children: [
                  _buildOverviewTab(),
                  _buildPlansTab(),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildInvestBar(),
    );
  }

  // ─── Hero header (gradient + avatar + name) ────────────────────────────────
  Widget _buildHeroHeader() {
    final gain = widget.manager.profitPercentage ?? 0;
    final isPos = gain >= 0;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.primary, AppColors.primary.withValues(alpha: 0.75)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(20.w, 56.h, 20.w, 16.h),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              // Avatar
              Container(
                width: 58.w,
                height: 58.w,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                  border:
                      Border.all(color: Colors.white.withValues(alpha: 0.6), width: 2),
                ),
                child: Center(
                  child: Text(
                    _initials(widget.manager.managerName),
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22.sp,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SizedBox(width: 14.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Row(children: [
                      Text(widget.manager.managerName ?? '',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18.sp,
                              fontWeight: FontWeight.bold)),
                      SizedBox(width: 6.w),
                      Icon(Icons.verified, color: Colors.white70, size: 16.sp),
                    ]),
                    SizedBox(height: 4.h),
                    Row(children: [
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 8.w, vertical: 2.h),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(4.r),
                        ),
                        child: Text(widget.manager.managerCode ?? '',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 10.sp,
                                fontWeight: FontWeight.bold)),
                      ),
                      SizedBox(width: 8.w),
                      Icon(Icons.schedule, color: Colors.white60, size: 11.sp),
                      SizedBox(width: 3.w),
                      Text('Since ${widget.manager.memberSince ?? '—'}',
                          style: TextStyle(color: Colors.white60, fontSize: 10.sp)),
                    ]),
                  ],
                ),
              ),
              // Gain badge
              Container(
                padding:
                    EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(
                      color: Colors.white.withValues(alpha: 0.4)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${isPos ? '+' : ''}${_fmt(gain)}%',
                      style: TextStyle(
                          color: isPos
                              ? const Color(0xFF4ADE80)
                              : const Color(0xFFFF6B6B),
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold),
                    ),
                    Text('GAIN',
                        style: TextStyle(
                            color: Colors.white70,
                            fontSize: 9.sp,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Stats horizontal strip ────────────────────────────────────────────────
  Widget _buildStatsStrip() {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.symmetric(vertical: 14.h),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 14.w),
        child: Row(
          children: [
            _stripStat('AUM',
                '\$${_fmt(widget.manager.totalAum)}', AppColors.primary),
            _divider(),
            _stripStat('Investors',
                '${widget.manager.totalInvestors ?? 0}', Colors.blue),
            _divider(),
            _stripStat('Commission',
                '${_fmt(widget.manager.avgCommission)}%', Colors.orange),
            _divider(),
            _stripStat('Plans',
                '${widget.manager.plansCount ?? 0}', Colors.purple),
            _divider(),
            _stripStat('Drawdown', '—', Colors.red),
          ],
        ),
      ),
    );
  }

  Widget _stripStat(String label, String val, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w),
      child: Column(
        children: [
          Text(val,
              style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,
                  color: color)),
          SizedBox(height: 2.h),
          Text(label,
              style: TextStyle(fontSize: 10.sp, color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _divider() {
    return Container(
        height: 28.h, width: 1, color: Colors.grey.shade200);
  }

  // ─── Overview tab ──────────────────────────────────────────────────────────
  Widget _buildOverviewTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(14.w),
      child: Column(
        children: [
          // Description card
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Strategy Description',
                    style: TextStyle(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.w700,
                        color: AppColors.primary)),
                SizedBox(height: 8.h),
                Text(
                  widget.manager.strategyDescription ??
                      'No description provided.',
                  style: TextStyle(
                      fontSize: 12.sp,
                      color: Colors.grey.shade700,
                      height: 1.5),
                ),
              ],
            ),
          ),
          SizedBox(height: 12.h),
          // Risk info
          if ((widget.manager.riskInformation ?? '').isNotEmpty)
            _card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Icon(Icons.warning_amber_rounded,
                        color: Colors.orange, size: 16.sp),
                    SizedBox(width: 6.w),
                    Text('Risk Information',
                        style: TextStyle(
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w700,
                            color: Colors.orange)),
                  ]),
                  SizedBox(height: 8.h),
                  Text(
                    widget.manager.riskInformation ?? '',
                    style: TextStyle(
                        fontSize: 12.sp,
                        color: Colors.grey.shade700,
                        height: 1.5),
                  ),
                ],
              ),
            ),
          SizedBox(height: 12.h),
          // Performance chart card
          _card(child: _buildPerformanceChart()),
          SizedBox(height: 80.h),
        ],
      ),
    );
  }

  Widget _buildPerformanceChart() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Performance',
                style: TextStyle(
                    fontSize: 13.sp, fontWeight: FontWeight.w700)),
            // Time filter chips
            Row(
              children: ['1W', '1M', '3M', '6M', '1Y', 'All']
                  .map((t) => GestureDetector(
                        onTap: () => setState(() => _timeFilter = t),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          margin: EdgeInsets.only(left: 4.w),
                          padding: EdgeInsets.symmetric(
                              horizontal: 7.w, vertical: 3.h),
                          decoration: BoxDecoration(
                            color: _timeFilter == t
                                ? AppColors.primary
                                : Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(5.r),
                          ),
                          child: Text(t,
                              style: TextStyle(
                                  fontSize: 9.sp,
                                  fontWeight: FontWeight.bold,
                                  color: _timeFilter == t
                                      ? Colors.white
                                      : Colors.grey)),
                        ),
                      ))
                  .toList(),
            ),
          ],
        ),
        SizedBox(height: 16.h),
        SizedBox(
          height: 160.h,
          child: LineChart(
            LineChartData(
              gridData: FlGridData(
                show: true,
                drawVerticalLine: false,
                getDrawingHorizontalLine: (_) => FlLine(
                  color: Colors.grey.shade100,
                  strokeWidth: 1,
                ),
              ),
              titlesData: FlTitlesData(show: false),
              borderData: FlBorderData(show: false),
              lineBarsData: [
                LineChartBarData(
                  spots: const [
                    FlSpot(0, 0),
                    FlSpot(1, 0.8),
                    FlSpot(2, 0.4),
                    FlSpot(3, 2.1),
                    FlSpot(4, 1.6),
                    FlSpot(5, 3.4),
                    FlSpot(6, 2.9),
                    FlSpot(7, 4.2),
                  ],
                  isCurved: true,
                  color: AppColors.primary,
                  barWidth: 2.5,
                  dotData: FlDotData(show: false),
                  belowBarData: BarAreaData(
                    show: true,
                    gradient: LinearGradient(
                      colors: [
                        AppColors.primary.withValues(alpha: 0.2),
                        AppColors.primary.withValues(alpha: 0.0),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── Plans tab ─────────────────────────────────────────────────────────────
  Widget _buildPlansTab() {
    final plans = widget.manager.plans ?? [];
    if (plans.isEmpty) {
      return Center(
        child: Padding(
          padding: EdgeInsets.all(32.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.folder_open_outlined,
                  size: 48.sp, color: Colors.grey.shade300),
              SizedBox(height: 12.h),
              Text('No plans available',
                  style: TextStyle(
                      fontSize: 14.sp,
                      color: Colors.grey,
                      fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      );
    }
    return ListView.builder(
      padding: EdgeInsets.all(14.w),
      itemCount: plans.length,
      itemBuilder: (_, i) => _buildPlanTile(plans[i]),
    );
  }

  Widget _buildPlanTile(Plan plan) {
    final isApproved = plan.status == 'approved';
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(14.w, 12.h, 14.w, 10.h),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(plan.planName ?? 'Plan',
                          style: TextStyle(
                              fontSize: 14.sp, fontWeight: FontWeight.bold)),
                      SizedBox(height: 4.h),
                      Row(children: [
                        _planChip(
                            '${plan.commissionPercentage ?? 0}% commission',
                            Colors.orange),
                        SizedBox(width: 6.w),
                        _planChip(
                            'Min \$${plan.minimumInvestment ?? 0}',
                            AppColors.primary),
                      ]),
                    ],
                  ),
                ),
                // Status pill
                Container(
                  padding: EdgeInsets.symmetric(
                      horizontal: 8.w, vertical: 3.h),
                  decoration: BoxDecoration(
                    color: (isApproved ? Colors.green : Colors.orange)
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20.r),
                    border: Border.all(
                      color: (isApproved ? Colors.green : Colors.orange)
                          .withValues(alpha: 0.4),
                    ),
                  ),
                  child: Text(
                    isApproved ? 'Active' : (plan.status ?? '').capitalizeFirst ?? '',
                    style: TextStyle(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.bold,
                        color: isApproved ? Colors.green : Colors.orange),
                  ),
                ),
              ],
            ),
          ),
          if ((plan.strategyDescription ?? '').isNotEmpty)
            Padding(
              padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 10.h),
              child: Text(
                plan.strategyDescription ?? '',
                style:
                    TextStyle(fontSize: 11.sp, color: Colors.grey.shade600),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          if (isApproved)
            Padding(
              padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 12.h),
              child: SizedBox(
                width: double.infinity,
                height: 36.h,
                child: ElevatedButton(
                  onPressed: () => _showInvestSheet(plan),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.r)),
                  ),
                  child: Text('Invest in this Plan',
                      style: TextStyle(
                          color: Colors.white, fontSize: 12.sp)),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _planChip(String label, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 7.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: Text(label,
          style: TextStyle(
              fontSize: 10.sp,
              color: color,
              fontWeight: FontWeight.w600)),
    );
  }

  // ─── Bottom Invest bar ─────────────────────────────────────────────────────
  Widget _buildInvestBar() {
    final plan = _firstPlan;
    return Container(
      padding: EdgeInsets.fromLTRB(16.w, 10.h, 16.w, 24.h),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 12,
              offset: const Offset(0, -3)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Min. Investment',
                    style: TextStyle(
                        color: Colors.grey, fontSize: 10.sp)),
                Text(
                  '\$${plan?.minimumInvestment ?? '1,000'}',
                  style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF1A1A2E)),
                ),
              ],
            ),
            const Spacer(),
            Obx(() => SizedBox(
                  width: 160.w,
                  height: 44.h,
                  child: ElevatedButton(
                    onPressed: controller.isSubmitting.value
                        ? null
                        : () => _showInvestSheet(plan),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.r)),
                    ),
                    child: controller.isSubmitting.value
                        ? SizedBox(
                            height: 18.h,
                            width: 18.h,
                            child: const CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white))
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.bolt, color: Colors.white, size: 18.sp),
                              SizedBox(width: 4.w),
                              Text('Invest Now',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.bold)),
                            ],
                          ),
                  ),
                )),
          ],
        ),
      ),
    );
  }

  // ─── Invest bottom sheet ───────────────────────────────────────────────────
  void _showInvestSheet(Plan? plan) {
    if (plan == null || plan.id == null) {
      Get.snackbar('No Plan', 'This manager has no active plan to invest in.',
          snackPosition: SnackPosition.BOTTOM);
      return;
    }

    final amountCtrl = TextEditingController(
        text: plan.minimumInvestment ?? '1000');
    final RxInt selectedAccountId = RxInt(-1);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: DraggableScrollableSheet(
          initialChildSize: 0.65,
          minChildSize: 0.5,
          maxChildSize: 0.92,
          expand: false,
          builder: (_, scrollCtrl) => Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius:
                  BorderRadius.vertical(top: Radius.circular(20.r)),
            ),
            child: ListView(
              controller: scrollCtrl,
              padding: EdgeInsets.fromLTRB(20.w, 0, 20.w, 32.h),
              children: [
                SizedBox(height: 10.h),
                Center(
                  child: Container(
                    width: 36.w,
                    height: 4.h,
                    decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2.r)),
                  ),
                ),
                SizedBox(height: 20.h),
                // Header
                Row(children: [
                  Icon(Icons.savings_outlined,
                      color: AppColors.primary, size: 22.sp),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Invest Now',
                            style: TextStyle(
                                fontSize: 18.sp,
                                fontWeight: FontWeight.bold)),
                        Text(
                          '${plan.planName ?? 'Plan'} • ${plan.commissionPercentage ?? 0}% commission',
                          style: TextStyle(
                              fontSize: 12.sp, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ]),
                SizedBox(height: 20.h),
                Divider(color: Colors.grey.shade100),
                SizedBox(height: 16.h),

                // Select account
                Text('Select Trading Account',
                    style: TextStyle(
                        fontSize: 13.sp, fontWeight: FontWeight.w700)),
                SizedBox(height: 10.h),
                Obx(() {
                  if (controller.isLoadingEligibleAccounts.value) {
                    return const Center(
                        child: CircularProgressIndicator());
                  }
                  if (controller.eligibleAccounts.isEmpty) {
                    return Container(
                      padding: EdgeInsets.all(14.w),
                      decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                      child: Row(children: [
                        Icon(Icons.info_outline,
                            color: Colors.red, size: 18.sp),
                        SizedBox(width: 8.w),
                        Expanded(
                          child: Text(
                            'No eligible accounts found. Create a live trading account first.',
                            style: TextStyle(
                                fontSize: 12.sp,
                                color: Colors.red.shade700),
                          ),
                        ),
                      ]),
                    );
                  }
                  return Column(
                    children:
                        controller.eligibleAccounts.map((acc) {
                      return Obx(() {
                        final isSelected =
                            selectedAccountId.value == acc.id;
                        return GestureDetector(
                          onTap: () =>
                              selectedAccountId.value = acc.id!,
                          child: AnimatedContainer(
                            duration:
                                const Duration(milliseconds: 150),
                            margin: EdgeInsets.only(bottom: 8.h),
                            padding: EdgeInsets.all(12.w),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? AppColors.primary.withValues(alpha: 0.06)
                                  : const Color(0xFFF5F6FA),
                              borderRadius:
                                  BorderRadius.circular(10.r),
                              border: Border.all(
                                color: isSelected
                                    ? AppColors.primary
                                    : Colors.transparent,
                                width: 1.5,
                              ),
                            ),
                            child: Row(children: [
                              Container(
                                width: 18.w,
                                height: 18.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: isSelected
                                      ? AppColors.primary
                                      : Colors.white,
                                  border: Border.all(
                                    color: isSelected
                                        ? AppColors.primary
                                        : Colors.grey.shade300,
                                    width: 2,
                                  ),
                                ),
                                child: isSelected
                                    ? Icon(Icons.check,
                                        size: 11.sp,
                                        color: Colors.white)
                                    : null,
                              ),
                              SizedBox(width: 10.w),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      acc.metaAccountNumber ?? '—',
                                      style: TextStyle(
                                          fontSize: 13.sp,
                                          fontWeight:
                                              FontWeight.w600),
                                    ),
                                    Text(
                                      'Balance: \$${_fmt(acc.balance)}  |  Available: \$${_fmt(acc.availableBalance)}',
                                      style: TextStyle(
                                          fontSize: 11.sp,
                                          color: Colors.grey),
                                    ),
                                  ],
                                ),
                              ),
                            ]),
                          ),
                        );
                      });
                    }).toList(),
                  );
                }),
                SizedBox(height: 16.h),

                // Amount field
                Text('Investment Amount (USD)',
                    style: TextStyle(
                        fontSize: 13.sp, fontWeight: FontWeight.w700)),
                SizedBox(height: 8.h),
                TextField(
                  controller: amountCtrl,
                  keyboardType: const TextInputType.numberWithOptions(
                      decimal: true),
                  style:
                      TextStyle(fontSize: 15.sp, fontWeight: FontWeight.w600),
                  decoration: InputDecoration(
                    prefixText: '\$ ',
                    prefixStyle: TextStyle(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primary),
                    hintText: 'Enter amount',
                    filled: true,
                    fillColor: const Color(0xFFF5F6FA),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.r),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.r),
                      borderSide: BorderSide(
                          color: AppColors.primary, width: 1.5),
                    ),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
                  ),
                ),
                SizedBox(height: 6.h),
                Text(
                  'Minimum investment: \$${plan.minimumInvestment ?? '—'}',
                  style: TextStyle(
                      fontSize: 11.sp, color: Colors.grey),
                ),
                SizedBox(height: 24.h),

                // Submit
                Obx(() => SizedBox(
                      width: double.infinity,
                      height: 48.h,
                      child: ElevatedButton(
                        onPressed: controller.isSubmitting.value
                            ? null
                            : () async {
                                final amount = num.tryParse(
                                    amountCtrl.text.trim());
                                if (amount == null || amount <= 0) {
                                  Get.snackbar('Error', 'Enter a valid amount',
                                      snackPosition:
                                          SnackPosition.BOTTOM);
                                  return;
                                }
                                if (selectedAccountId.value < 0) {
                                  Get.snackbar('Error', 'Pick a trading account',
                                      snackPosition:
                                          SnackPosition.BOTTOM);
                                  return;
                                }
                                Navigator.pop(ctx);
                                final ok = await controller.requestJoin(
                                  planId: plan.id!,
                                  investorAccountId:
                                      selectedAccountId.value,
                                  amount: amount,
                                );
                                if (ok) Get.back();
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(12.r)),
                        ),
                        child: controller.isSubmitting.value
                            ? const CircularProgressIndicator(
                                color: Colors.white)
                            : Text('Submit Investment Request',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15.sp,
                                    fontWeight: FontWeight.bold)),
                      ),
                    )),
                SizedBox(height: 8.h),
                Center(
                  child: Text(
                    'Request must be approved by the manager',
                    style: TextStyle(
                        fontSize: 11.sp, color: Colors.grey),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ],
      ),
      child: child,
    );
  }

  String _initials(String? name) {
    if (name == null || name.isEmpty) return '?';
    final p = name.trim().split(' ');
    if (p.length > 1 && p[1].isNotEmpty)
      return (p[0][0] + p[1][0]).toUpperCase();
    return name.length >= 2 ? name.substring(0, 2).toUpperCase() : name.toUpperCase();
  }

  String _fmt(num? v) {
    if (v == null) return '0';
    if (v == v.round()) return v.round().toString();
    return v.toStringAsFixed(2);
  }
}
