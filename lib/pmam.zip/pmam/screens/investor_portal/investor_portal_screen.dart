import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:crm_app/pmam/controllers/pmam_controller.dart';
import 'package:crm_app/pmam/models/pmam_manager_model.dart';
import 'package:crm_app/pmam/models/pmam_investment_model.dart';
import 'package:crm_app/pmam/screens/investor_portal/manager_details_screen.dart';
import 'package:crm_app/constants/color.dart';


class InvestorPortalScreen extends StatefulWidget {
  const InvestorPortalScreen({super.key});

  @override
  State<InvestorPortalScreen> createState() => _InvestorPortalScreenState();
}

class _InvestorPortalScreenState extends State<InvestorPortalScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late PmamController controller;
  final TextEditingController _searchCtrl = TextEditingController();
  String _investmentFilter = 'all';

  final List<Map<String, String>> _sortOptions = [
    {'label': 'Profit %', 'key': 'profit_percentage'},
    {'label': 'Total AUM', 'key': 'total_aum'},
    {'label': 'Investors', 'key': 'total_investors'},
    {'label': 'Commission', 'key': 'avg_commission'},
    {'label': 'Name', 'key': 'manager_name'},
    {'label': 'Member Since', 'key': 'member_since'},
  ];

  @override
  void initState() {
    super.initState();
    controller = Get.isRegistered<PmamController>()
        ? Get.find<PmamController>()
        : Get.put(PmamController());
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        if (_tabController.index == 0) controller.fetchManagersList();
        else controller.fetchInvestmentsList();
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  // ─── Filter bottom sheet ───────────────────────────────────────────────────
  void _showFilterSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _FilterSheet(
        controller: controller,
        sortOptions: _sortOptions,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            pinned: true,
            expandedHeight: 120.h,
            backgroundColor: AppColors.primary,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
              onPressed: () => Get.back(),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.primary, AppColors.primary.withValues(alpha: 0.75)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(56.w, 12.h, 16.w, 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Investor Portal',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 22.sp,
                                fontWeight: FontWeight.bold)),
                        SizedBox(height: 4.h),
                        Text('Browse fund managers or track your investments',
                            style: TextStyle(
                                color: Colors.white70, fontSize: 12.sp)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(44.h),
              child: Container(
                color: Colors.white,
                child: TabBar(
                  controller: _tabController,
                  labelColor: AppColors.primary,
                  unselectedLabelColor: Colors.grey,
                  indicatorColor: AppColors.primary,
                  indicatorWeight: 3,
                  labelStyle: TextStyle(
                      fontSize: 13.sp, fontWeight: FontWeight.w600),
                  tabs: const [
                    Tab(text: '  Fund Managers  '),
                    Tab(text: '  My Investments  '),
                  ],
                ),
              ),
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabController,
          children: [_buildFundManagersTab(), _buildMyInvestmentsTab()],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FUND MANAGERS TAB
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildFundManagersTab() {
    return Column(
      children: [
        // ─── Search + Filter row ─────────────────────────────────────────────
        Container(
          color: Colors.white,
          padding: EdgeInsets.fromLTRB(14.w, 10.h, 14.w, 10.h),
          child: Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 40.h,
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: (v) => controller.fetchManagersList(query: v),
                    style: TextStyle(fontSize: 13.sp),
                    decoration: InputDecoration(
                      hintText: 'Search by name or code…',
                      hintStyle:
                          TextStyle(color: Colors.grey, fontSize: 13.sp),
                      prefixIcon:
                          Icon(Icons.search, size: 18.sp, color: Colors.grey),
                      suffixIcon: Obx(() =>
                          controller.searchManagerQuery.value.isNotEmpty
                              ? GestureDetector(
                                  onTap: () {
                                    _searchCtrl.clear();
                                    controller.fetchManagersList(query: '');
                                  },
                                  child: Icon(Icons.close,
                                      size: 16.sp, color: Colors.grey))
                              : const SizedBox.shrink()),
                      contentPadding: EdgeInsets.zero,
                      filled: true,
                      fillColor: const Color(0xFFF5F6FA),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.r),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 8.w),
              GestureDetector(
                onTap: _showFilterSheet,
                child: Container(
                  height: 40.h,
                  width: 40.h,
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                  child: Icon(Icons.tune, color: Colors.white, size: 20.sp),
                ),
              ),
            ],
          ),
        ),
        // ─── Count + Sort label ──────────────────────────────────────────────
        Container(
          color: const Color(0xFFF5F6FA),
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
          child: Obx(() {
            final sortLabel = _sortOptions
                .firstWhere((e) => e['key'] == controller.sortBy.value,
                    orElse: () => {'label': ''})['label'] ?? '';
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${controller.managersTotal.value} managers found',
                  style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500),
                ),
                Text(
                  'Sort: $sortLabel ${controller.sortOrder.value == 'desc' ? '↓' : '↑'}',
                  style: TextStyle(
                      color: AppColors.primary,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600),
                ),
              ],
            );
          }),
        ),
        // ─── Managers list ───────────────────────────────────────────────────
        Expanded(
          child: Obx(() {
            if (controller.isLoadingManagers.value) {
              return _loadingWidget();
            }
            if (controller.managersList.isEmpty) {
              return _noDataWidget(
                  icon: Icons.people_outline, message: 'No Fund Managers found');
            }
            return ListView.builder(
              padding: EdgeInsets.fromLTRB(14.w, 8.h, 14.w, 20.h),
              itemCount: controller.managersList.length,
              itemBuilder: (_, i) =>
                  _buildManagerCard(controller.managersList[i]),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildManagerCard(PmamManager m) {
    final gain = m.profitPercentage ?? 0;
    final isPositive = gain >= 0;
    final gainColor = isPositive ? Colors.green : Colors.red;

    return GestureDetector(
      onTap: () => Get.to(() => ManagerDetailsScreen(manager: m)),
      child: Container(
        margin: EdgeInsets.only(bottom: 12.h),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            // ─ Top row: avatar + name + GAIN badge ──────────────────────────
            Padding(
              padding: EdgeInsets.fromLTRB(14.w, 14.h, 14.w, 10.h),
              child: Row(
                children: [
                  _avatar(m.managerName, radius: 24.r),
                  SizedBox(width: 10.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(m.managerName ?? 'Unknown',
                            style: TextStyle(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFF1A1A2E)),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                        SizedBox(height: 2.h),
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 6.w, vertical: 2.h),
                              decoration: BoxDecoration(
                                color: AppColors.primary.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(4.r),
                              ),
                              child: Text(m.managerCode ?? '',
                                  style: TextStyle(
                                      color: AppColors.primary,
                                      fontSize: 10.sp,
                                      fontWeight: FontWeight.bold)),
                            ),
                            SizedBox(width: 6.w),
                            Icon(Icons.access_time,
                                size: 10.sp, color: Colors.grey),
                            SizedBox(width: 2.w),
                            Text(m.memberSince ?? '',
                                style: TextStyle(
                                    color: Colors.grey, fontSize: 10.sp)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  // Gain badge
                  Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: 10.w, vertical: 5.h),
                    decoration: BoxDecoration(
                      color: gainColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8.r),
                      border: Border.all(
                          color: gainColor.withValues(alpha: 0.3)),
                    ),
                    child: Column(
                      children: [
                        Text(
                          '${isPositive ? '+' : ''}${_fmt(gain)}%',
                          style: TextStyle(
                              color: gainColor,
                              fontSize: 14.sp,
                              fontWeight: FontWeight.bold),
                        ),
                        Text('GAIN',
                            style: TextStyle(
                                color: gainColor,
                                fontSize: 9.sp,
                                fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // ─ Divider ──────────────────────────────────────────────────────
            Divider(height: 1, color: Colors.grey.shade100),
            // ─ Stats row ────────────────────────────────────────────────────
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 10.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _statChip(Icons.bar_chart, 'AUM',
                      '\$${_fmt(m.totalAum)}', AppColors.primary),
                  _statChip(Icons.people_outline, 'Investors',
                      '${m.totalInvestors ?? 0}', Colors.blue),
                  _statChip(Icons.percent, 'Commission',
                      '${_fmt(m.avgCommission)}%', Colors.orange),
                  _statChip(Icons.folder_copy_outlined, 'Plans',
                      '${m.plansCount ?? 0}', Colors.purple),
                ],
              ),
            ),
            // ─ View button ──────────────────────────────────────────────────
            Padding(
              padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 12.h),
              child: SizedBox(
                width: double.infinity,
                height: 38.h,
                child: ElevatedButton.icon(
                  onPressed: () =>
                      Get.to(() => ManagerDetailsScreen(manager: m)),
                  icon: Icon(Icons.visibility_outlined,
                      size: 16.sp, color: Colors.white),
                  label: Text('View Manager',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w600)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.r)),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statChip(IconData icon, String label, String val, Color color) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(6.w),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 14.sp, color: color),
        ),
        SizedBox(height: 4.h),
        Text(val,
            style: TextStyle(
                fontSize: 11.sp,
                fontWeight: FontWeight.bold,
                color: const Color(0xFF1A1A2E))),
        Text(label,
            style: TextStyle(fontSize: 9.sp, color: Colors.grey)),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // MY INVESTMENTS TAB
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildMyInvestmentsTab() {
    return Column(
      children: [
        // ─── Summary cards ────────────────────────────────────────────────────
        Obx(() => _buildSummaryStrip()),
        // ─── Filter chips ─────────────────────────────────────────────────────
        Container(
          color: Colors.white,
          padding: EdgeInsets.fromLTRB(14.w, 8.h, 14.w, 10.h),
          child: Obx(() {
            final all = controller.investmentsList.length;
            final active = controller.investmentsList
                .where((e) => e.status == 'active')
                .length;
            return SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _filterChip('All ($all)', 'all'),
                  SizedBox(width: 8.w),
                  _filterChip('Active ($active)', 'active'),
                  SizedBox(width: 8.w),
                  _filterChip('Inactive (${all - active})', 'inactive'),
                ],
              ),
            );
          }),
        ),
        Divider(height: 1, color: Colors.grey.shade200),
        // ─── Investment cards ─────────────────────────────────────────────────
        Expanded(
          child: Obx(() {
            if (controller.isLoadingInvestments.value) return _loadingWidget();
            final all = controller.investmentsList;
            final filtered = _investmentFilter == 'all'
                ? all
                : all.where((e) => e.status == _investmentFilter).toList();
            if (filtered.isEmpty) {
              return _noDataWidget(
                icon: Icons.account_balance_outlined,
                message: 'No investments found',
                sub: 'Browse Fund Managers to start investing',
              );
            }
            return ListView.builder(
              padding: EdgeInsets.fromLTRB(14.w, 10.h, 14.w, 20.h),
              itemCount: filtered.length,
              itemBuilder: (_, i) => _buildInvestmentCard(filtered[i]),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildSummaryStrip() {
    final invested = controller.totalInvested;
    final pnl = controller.totalPnl;
    final net = controller.netBalance;
    final activeCount = controller.activePlansCount;

    return Container(
      color: Colors.white,
      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
      child: Column(
        children: [
          // Top big P&L card
          Container(
            margin: EdgeInsets.all(14.w),
            padding: EdgeInsets.all(16.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.primary, AppColors.primary.withValues(alpha: 0.8)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14.r),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Net Balance',
                          style: TextStyle(
                              color: Colors.white70, fontSize: 11.sp)),
                      SizedBox(height: 4.h),
                      Text('\$${_fmt(net)}',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 24.sp,
                              fontWeight: FontWeight.bold)),
                      SizedBox(height: 8.h),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 8.w, vertical: 3.h),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(6.r),
                        ),
                        child: Text(
                          '${pnl >= 0 ? '+' : ''}\$${_fmt(pnl)} P&L',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 11.sp,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _miniStat('Invested', '\$${_fmt(invested)}'),
                    SizedBox(height: 10.h),
                    _miniStat('Active Plans', '$activeCount'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat(String label, String val) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(label,
            style:
                TextStyle(color: Colors.white60, fontSize: 10.sp)),
        Text(val,
            style: TextStyle(
                color: Colors.white,
                fontSize: 14.sp,
                fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildInvestmentCard(PmamInvestment inv) {
    final pnlNum = num.tryParse(inv.totalPnl ?? '0') ?? 0.0;
    final invested = num.tryParse(inv.investedAmount ?? '0') ?? 0.0;
    final isActive = inv.status == 'active';
    final gainColor = pnlNum >= 0 ? Colors.green : Colors.red;
    final statusColor = isActive ? Colors.green : Colors.grey;

    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 10,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ─ Header ────────────────────────────────────────────────────────
          Padding(
            padding: EdgeInsets.fromLTRB(14.w, 12.h, 14.w, 10.h),
            child: Row(
              children: [
                _avatar(inv.planName, radius: 20.r, fontSize: 11.sp),
                SizedBox(width: 10.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(inv.planName ?? '—',
                          style: TextStyle(
                              fontSize: 13.sp, fontWeight: FontWeight.w700),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      Text('${inv.managerName ?? '—'} • ${inv.commissionPercentage ?? 0}% commission',
                          style: TextStyle(
                              fontSize: 11.sp, color: Colors.grey)),
                    ],
                  ),
                ),
                // Status pill
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 8.w, vertical: 3.h),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20.r),
                    border: Border.all(
                        color: statusColor.withValues(alpha: 0.4)),
                  ),
                  child: Text(
                    inv.status?.capitalizeFirst ?? '',
                    style: TextStyle(
                        color: statusColor,
                        fontSize: 10.sp,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: Colors.grey.shade100),
          // ─ Stats row ─────────────────────────────────────────────────────
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 12.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _invStat('Invested', '\$${_fmt(invested)}', null),
                _invStat('Total P&L',
                    '${pnlNum >= 0 ? '+' : ''}\$${_fmt(pnlNum)}', gainColor),
                _invStat('Net Balance', '\$${_fmt(inv.currentValue)}', null),
              ],
            ),
          ),
          // ─ Account chip ──────────────────────────────────────────────────
          Padding(
            padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 12.h),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
              decoration: BoxDecoration(
                color: const Color(0xFFF5F6FA),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.account_balance_outlined,
                      size: 12.sp, color: Colors.grey),
                  SizedBox(width: 4.w),
                  Text('Account: ${inv.accountNumber ?? '—'}  |  Balance: \$${_fmt(inv.accountBalance)}',
                      style: TextStyle(
                          fontSize: 11.sp, color: Colors.grey.shade700)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _invStat(String label, String val, Color? color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(fontSize: 10.sp, color: Colors.grey)),
        SizedBox(height: 2.h),
        Text(val,
            style: TextStyle(
                fontSize: 13.sp,
                fontWeight: FontWeight.bold,
                color: color ?? const Color(0xFF1A1A2E))),
      ],
    );
  }

  Widget _filterChip(String label, String value) {
    final isActive = _investmentFilter == value;
    return GestureDetector(
      onTap: () => setState(() => _investmentFilter = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 6.h),
        decoration: BoxDecoration(
          color: isActive ? AppColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(20.r),
          border: Border.all(
            color: isActive ? AppColors.primary : Colors.grey.shade300,
          ),
        ),
        child: Text(label,
            style: TextStyle(
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
                color: isActive ? Colors.white : Colors.grey.shade600)),
      ),
    );
  }

  // ─── Shared helpers ────────────────────────────────────────────────────────
  Widget _avatar(String? name,
      {required double radius, double? fontSize}) {
    final initials = _getInitials(name);
    return CircleAvatar(
      radius: radius,
      backgroundColor: AppColors.primary.withValues(alpha: 0.12),
      child: Text(initials,
          style: TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
              fontSize: fontSize ?? (radius * 0.55))),
    );
  }

  Widget _loadingWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: AppColors.primary),
          SizedBox(height: 12.h),
          Text('Loading…',
              style: TextStyle(color: Colors.grey, fontSize: 13.sp)),
        ],
      ),
    );
  }

  Widget _noDataWidget(
      {required IconData icon, required String message, String? sub}) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(20.w),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 40.sp, color: Colors.grey.shade400),
            ),
            SizedBox(height: 16.h),
            Text(message,
                style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade700),
                textAlign: TextAlign.center),
            if (sub != null) ...[
              SizedBox(height: 6.h),
              Text(sub,
                  style: TextStyle(
                      fontSize: 12.sp, color: Colors.grey),
                  textAlign: TextAlign.center),
            ],
          ],
        ),
      ),
    );
  }

  String _getInitials(String? name) {
    if (name == null || name.isEmpty) return '?';
    final p = name.trim().split(' ');
    if (p.length > 1 && p[1].isNotEmpty)
      return (p[0][0] + p[1][0]).toUpperCase();
    return name.length >= 2
        ? name.substring(0, 2).toUpperCase()
        : name.toUpperCase();
  }

  String _fmt(num? v) {
    if (v == null) return '0';
    if (v == v.round()) return v.round().toString();
    return v.toStringAsFixed(2);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Filter Bottom Sheet (Sort + Order + Show)
// ═══════════════════════════════════════════════════════════════════════════
class _FilterSheet extends StatelessWidget {
  final PmamController controller;
  final List<Map<String, String>> sortOptions;

  const _FilterSheet({
    required this.controller,
    required this.sortOptions,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      padding: EdgeInsets.fromLTRB(20.w, 16.h, 20.w, 32.h),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle
          Center(
            child: Container(
              width: 36.w,
              height: 4.h,
              decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2.r)),
            ),
          ),
          SizedBox(height: 16.h),
          Text('Filter & Sort',
              style: TextStyle(
                  fontSize: 16.sp, fontWeight: FontWeight.bold)),
          SizedBox(height: 16.h),

          // SORT BY
          Text('Sort By',
              style: TextStyle(
                  fontSize: 12.sp,
                  color: Colors.grey,
                  fontWeight: FontWeight.w600)),
          SizedBox(height: 8.h),
          Obx(() => Wrap(
                spacing: 8.w,
                runSpacing: 8.h,
                children: sortOptions.map((opt) {
                  final isSelected = controller.sortBy.value == opt['key'];
                  return GestureDetector(
                    onTap: () => controller.sortBy.value = opt['key']!,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      padding: EdgeInsets.symmetric(
                          horizontal: 14.w, vertical: 7.h),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppColors.primary
                            : Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(20.r),
                      ),
                      child: Text(opt['label']!,
                          style: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w600,
                              color: isSelected
                                  ? Colors.white
                                  : Colors.grey.shade700)),
                    ),
                  );
                }).toList(),
              )),
          SizedBox(height: 16.h),

          // ORDER
          Text('Order',
              style: TextStyle(
                  fontSize: 12.sp,
                  color: Colors.grey,
                  fontWeight: FontWeight.w600)),
          SizedBox(height: 8.h),
          Obx(() => Row(
                children: [
                  _orderChip('Highest first', 'desc', controller),
                  SizedBox(width: 10.w),
                  _orderChip('Lowest first', 'asc', controller),
                ],
              )),
          SizedBox(height: 16.h),

          // SHOW
          Text('Show per page',
              style: TextStyle(
                  fontSize: 12.sp,
                  color: Colors.grey,
                  fontWeight: FontWeight.w600)),
          SizedBox(height: 8.h),
          Obx(() => Row(
                children: [10, 25, 50, 100].map((n) {
                  final isSelected = controller.pageLength.value == n;
                  return Padding(
                    padding: EdgeInsets.only(right: 8.w),
                    child: GestureDetector(
                      onTap: () => controller.pageLength.value = n,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 7.h),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppColors.primary
                              : Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(20.r),
                        ),
                        child: Text('$n',
                            style: TextStyle(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.bold,
                                color: isSelected
                                    ? Colors.white
                                    : Colors.grey.shade700)),
                      ),
                    ),
                  );
                }).toList(),
              )),
          SizedBox(height: 24.h),

          // Apply button
          SizedBox(
            width: double.infinity,
            height: 46.h,
            child: ElevatedButton(
              onPressed: () {
                controller.fetchManagersList();
                Get.back();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.r)),
              ),
              child: Text('Apply Filters',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _orderChip(String label, String val, PmamController ctrl) {
    final isSelected = ctrl.sortOrder.value == val;
    return GestureDetector(
      onTap: () => ctrl.sortOrder.value = val,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 7.h),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(20.r),
        ),
        child: Text(label,
            style: TextStyle(
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
                color: isSelected ? Colors.white : Colors.grey.shade700)),
      ),
    );
  }
}
