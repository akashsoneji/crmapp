import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:crm_app/constants/color.dart';

import 'package:crm_app/pmam/controllers/pmam_controller.dart';
import 'package:crm_app/pmam/models/pmam_plan_model.dart';

class PlanDetailScreen extends StatefulWidget {
  final PmamPlan plan;
  const PlanDetailScreen({super.key, required this.plan});

  @override
  State<PlanDetailScreen> createState() => _PlanDetailScreenState();
}

class _PlanDetailScreenState extends State<PlanDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  final controller = Get.find<PmamController>();

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            pinned: true,
            expandedHeight: 180.h,
            backgroundColor: AppColors.primary,
            leading: IconButton(
              icon:
                  const Icon(Icons.arrow_back_ios_new, color: Colors.white),
              onPressed: () => Get.back(),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: _buildHeroHeader(),
            ),
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(44.h),
              child: Container(
                color: Colors.white,
                child: TabBar(
                  controller: _tabCtrl,
                  labelColor: AppColors.primary,
                  unselectedLabelColor: Colors.grey,
                  indicatorColor: AppColors.primary,
                  indicatorWeight: 3,
                  labelStyle: TextStyle(
                      fontSize: 13.sp, fontWeight: FontWeight.w600),
                  tabs: const [
                    Tab(text: 'Investors'),
                    Tab(text: 'Pending Requests'),
                  ],
                ),
              ),
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabCtrl,
          children: [_buildInvestorsTab(), _buildRequestsTab()],
        ),
      ),
    );
  }

  // ─── Hero header ───────────────────────────────────────────────────────────
  Widget _buildHeroHeader() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.primary,
            AppColors.primary.withValues(alpha: 0.7)
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        child: Obx(() {
          final d = controller.planDetail.value;
          final p = d?.plan;
          return Padding(
            padding: EdgeInsets.fromLTRB(20.w, 56.h, 20.w, 20.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.plan.planName ?? 'Plan Detail',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.bold),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                SizedBox(height: 4.h),
                Text(
                    'Account: ${widget.plan.tradingAccountNumber ?? '—'}',
                    style: TextStyle(
                        color: Colors.white70, fontSize: 12.sp)),
                SizedBox(height: 12.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _heroBit('AUM', '\$${_fmt(p?.totalAum)}'),
                    _heroBit('P&L', '\$${_fmt(p?.totalPnl)}'),
                    _heroBit('Commission', '${_fmt(p?.commissionPct)}%'),
                    _heroBit('Investors',
                        '${p?.activeInvestors ?? widget.plan.activeInvestors ?? 0}'),
                  ],
                ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _heroBit(String label, String val) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(val,
            style: TextStyle(
                color: Colors.white,
                fontSize: 14.sp,
                fontWeight: FontWeight.bold)),
        Text(label,
            style: TextStyle(color: Colors.white60, fontSize: 10.sp)),
      ],
    );
  }

  // ─── Investors tab ─────────────────────────────────────────────────────────
  Widget _buildInvestorsTab() {
    return Obx(() {
      // Withdrawable banner
      final d = controller.planDetail.value;
      final canWithdraw = d?.canWithdraw == true;
      final investors = d?.investors ?? [];

      return Column(
        children: [
          if (canWithdraw)
            Container(
              margin: EdgeInsets.fromLTRB(14.w, 10.h, 14.w, 0),
              padding: EdgeInsets.all(12.w),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(10.r),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Row(
                children: [
                  Icon(Icons.account_balance_wallet_outlined,
                      color: Colors.green, size: 18.sp),
                  SizedBox(width: 8.w),
                  Text(
                      'Withdrawable: \$${_fmt(d?.withdrawable)}',
                      style: TextStyle(
                          color: Colors.green.shade700,
                          fontWeight: FontWeight.bold,
                          fontSize: 13.sp)),
                ],
              ),
            ),
          Expanded(
            child: investors.isEmpty
                ? _emptyState(
                    icon: Icons.people_outline,
                    message: 'No active investors yet',
                    sub:
                        'Approve pending requests to get investors in this plan',
                  )
                : ListView.separated(
                    padding: EdgeInsets.all(14.w),
                    itemCount: investors.length,
                    separatorBuilder: (_, __) => SizedBox(height: 10.h),
                    itemBuilder: (_, i) =>
                        _investorCard(investors[i]),
                  ),
          ),
        ],
      );
    });
  }

  Widget _investorCard(PmamPlanInvestor inv) {
    final isActive = inv.status == 'active';
    final color = isActive ? Colors.green : Colors.grey;
    return Container(
      padding: EdgeInsets.all(14.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Row(
        children: [
          _avatarCircle(inv.investorName ?? '', 22.r),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(inv.investorName ?? '—',
                    style: TextStyle(
                        fontSize: 13.sp, fontWeight: FontWeight.w600)),
                Text(inv.investorEmail ?? '—',
                    style: TextStyle(
                        fontSize: 11.sp, color: Colors.grey)),
                if (inv.activeSince != null)
                  Text('Active since: ${_shortDate(inv.activeSince)}',
                      style: TextStyle(
                          fontSize: 10.sp, color: Colors.grey)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('\$${_fmt(inv.investedAmount)}',
                  style: TextStyle(
                      fontSize: 14.sp, fontWeight: FontWeight.bold)),
              SizedBox(height: 4.h),
              Container(
                padding: EdgeInsets.symmetric(
                    horizontal: 8.w, vertical: 2.h),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: Text(
                  inv.status?.capitalizeFirst ?? '—',
                  style: TextStyle(
                      color: color,
                      fontSize: 10.sp,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── Requests tab ──────────────────────────────────────────────────────────
  Widget _buildRequestsTab() {
    return Obx(() {
      final reqs = controller.investorRequests;
      if (reqs.isEmpty) {
        return _emptyState(
          icon: Icons.pending_actions_rounded,
          message: 'No pending requests',
          sub: 'New investor requests will appear here',
        );
      }
      return ListView.separated(
        padding: EdgeInsets.all(14.w),
        itemCount: reqs.length,
        separatorBuilder: (_, __) => SizedBox(height: 10.h),
        itemBuilder: (_, i) => _requestCard(reqs[i]),
      );
    });
  }

  Widget _requestCard(PmamInvestorRequest req) {
    return Container(
      padding: EdgeInsets.all(14.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: Colors.orange.shade100),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top row
          Row(
            children: [
              _avatarCircle(req.user?.fullName ?? '', 22.r,
                  color: Colors.orange),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(req.user?.fullName ?? '—',
                        style: TextStyle(
                            fontSize: 13.sp, fontWeight: FontWeight.w600)),
                    Text(req.user?.email ?? '—',
                        style: TextStyle(
                            fontSize: 11.sp, color: Colors.grey)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('\$${_fmt(req.investedAmount)}',
                      style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary)),
                  Text('Requested',
                      style: TextStyle(
                          fontSize: 10.sp, color: Colors.orange)),
                ],
              ),
            ],
          ),
          // Account info
          if (req.investorAccount != null) ...[
            SizedBox(height: 8.h),
            Container(
              padding:
                  EdgeInsets.symmetric(horizontal: 10.w, vertical: 7.h),
              decoration: BoxDecoration(
                color: const Color(0xFFF5F6FA),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Row(
                children: [
                  Icon(Icons.account_balance_outlined,
                      size: 13.sp, color: Colors.grey),
                  SizedBox(width: 6.w),
                  Expanded(
                    child: Text(
                      'Account: ${req.investorAccount!.metaAccountNumber ?? '—'}  •  Available: \$${_fmt(req.investorAccount!.availableBalance)}',
                      style: TextStyle(
                          fontSize: 11.sp, color: Colors.grey.shade700),
                    ),
                  ),
                ],
              ),
            ),
          ],
          SizedBox(height: 12.h),
          // Action buttons
          Obx(() => Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 40.h,
                      child: OutlinedButton.icon(
                        onPressed: controller.isSubmitting.value
                            ? null
                            : () => _onReject(req.id!),
                        icon: Icon(Icons.close_rounded,
                            size: 16.sp, color: Colors.red),
                        label: Text('Reject',
                            style: TextStyle(
                                fontSize: 13.sp, color: Colors.red)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.red),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r)),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 10.w),
                  Expanded(
                    child: SizedBox(
                      height: 40.h,
                      child: ElevatedButton.icon(
                        onPressed: controller.isSubmitting.value
                            ? null
                            : () => _onApprove(req.id!),
                        icon: controller.isSubmitting.value
                            ? SizedBox(
                                height: 14.h,
                                width: 14.h,
                                child: const CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white))
                            : Icon(Icons.check_rounded,
                                size: 16.sp, color: Colors.white),
                        label: Text('Approve',
                            style: TextStyle(
                                fontSize: 13.sp, color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r)),
                        ),
                      ),
                    ),
                  ),
                ],
              )),
        ],
      ),
    );
  }

  Future<void> _onApprove(int id) async {
    await controller.approveInvestorRequest(id);
    if (widget.plan.id != null) {
      controller.fetchPlanDetail(widget.plan.id!);
    }
  }

  Future<void> _onReject(int id) async {
    await controller.rejectInvestorRequest(id);
  }

  Widget _emptyState(
      {required IconData icon,
      required String message,
      String? sub}) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(20.w),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 38.sp, color: Colors.grey.shade400),
            ),
            SizedBox(height: 16.h),
            Text(message,
                style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade700),
                textAlign: TextAlign.center),
            if (sub != null) ...[
              SizedBox(height: 6.h),
              Text(sub,
                  style: TextStyle(
                      fontSize: 12.sp, color: Colors.grey),
                  textAlign: TextAlign.center),
            ],
          ],
        ),
      ),
    );
  }

  Widget _avatarCircle(String name, double radius, {Color? color}) {
    final c = color ?? AppColors.primary;
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';
    return CircleAvatar(
      radius: radius,
      backgroundColor: c.withValues(alpha: 0.12),
      child: Text(initials,
          style: TextStyle(
              color: c,
              fontWeight: FontWeight.bold,
              fontSize: radius * 0.7)),
    );
  }

  String _fmt(num? v) {
    if (v == null) return '0';
    if (v == v.round()) return v.round().toString();
    return v.toStringAsFixed(2);
  }

  String _shortDate(String? iso) {
    if (iso == null) return '—';
    try {
      final d = DateTime.parse(iso);
      return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }
}
