import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:crm_app/constants/color.dart';

import 'package:crm_app/pmam/controllers/pmam_controller.dart';
import 'package:crm_app/pmam/models/pmam_plan_model.dart';
import 'package:crm_app/pmam/screens/manager_portal/plan_detail_screen.dart';
import 'package:crm_app/pmam/screens/manager_portal/create_plan_screen.dart';

class ManagerDashboardScreen extends StatefulWidget {
  const ManagerDashboardScreen({super.key});

  @override
  State<ManagerDashboardScreen> createState() =>
      _ManagerDashboardScreenState();
}

class _ManagerDashboardScreenState extends State<ManagerDashboardScreen> {
  late PmamController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.isRegistered<PmamController>()
        ? Get.find<PmamController>()
        : Get.put(PmamController());
    controller.fetchManagerDashboardStats();
    controller.fetchManagerPlans();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: () async {
          await controller.fetchManagerDashboardStats();
          await controller.fetchManagerPlans();
        },
        child: NestedScrollView(
          headerSliverBuilder: (_, __) => [
            SliverAppBar(
              pinned: true,
              expandedHeight: 150.h,
              backgroundColor: AppColors.primary,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
                onPressed: () => Get.back(),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.refresh, color: Colors.white),
                  onPressed: () {
                    controller.fetchManagerDashboardStats();
                    controller.fetchManagerPlans();
                  },
                ),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppColors.primary,
                        AppColors.primary.withValues(alpha: 0.7)
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: SafeArea(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(56.w, 16.h, 20.w, 20.h),
                      child: Obx(() {
                        final stats = controller.dashboardStats.value;
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text('Manager Dashboard',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22.sp,
                                    fontWeight: FontWeight.bold)),
                            SizedBox(height: 6.h),
                            Row(children: [
                              _topStat('AUM',
                                  '\$${_fmt(stats?.totalLockedAum)}'),
                              SizedBox(width: 20.w),
                              _topStat('Investors',
                                  '${stats?.activeInvestors ?? 0}'),
                              SizedBox(width: 20.w),
                              _topStat('Commission',
                                  '\$${_fmt(stats?.totalCommission)}'),
                            ]),
                          ],
                        );
                      }),
                    ),
                  ),
                ),
              ),
            ),
          ],
          body: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: EdgeInsets.fromLTRB(14.w, 14.h, 14.w, 80.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildStatsGrid(),
                SizedBox(height: 16.h),
                _buildRecentCommissions(),
                SizedBox(height: 16.h),
                _buildPlansSection(),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Get.to(() => const CreatePlanScreen());
          controller.fetchManagerPlans();
        },
        backgroundColor: AppColors.primary,
        elevation: 4,
        icon: const Icon(Icons.add_rounded, color: Colors.white),
        label: Text('New Plan',
            style: TextStyle(
                color: Colors.white,
                fontSize: 14.sp,
                fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _topStat(String label, String val) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(val,
            style: TextStyle(
                color: Colors.white,
                fontSize: 15.sp,
                fontWeight: FontWeight.bold)),
        Text(label,
            style: TextStyle(color: Colors.white60, fontSize: 10.sp)),
      ],
    );
  }

  // ─── Stats 2×3 Grid ────────────────────────────────────────────────────────
  Widget _buildStatsGrid() {
    return Obx(() {
      final s = controller.dashboardStats.value;
      if (controller.isLoadingDashboard.value) {
        return SizedBox(
          height: 100.h,
          child:
              Center(child: CircularProgressIndicator(color: AppColors.primary)),
        );
      }
      final items = [
        {
          'label': 'Total Plans',
          'val': '${s?.totalPlans ?? 0}',
          'icon': Icons.bar_chart_rounded,
          'color': AppColors.primary,
        },
        {
          'label': 'Pending Requests',
          'val': '${s?.pendingRequests ?? 0}',
          'icon': Icons.pending_actions_rounded,
          'color': Colors.orange,
        },
        {
          'label': 'Total P&L',
          'val': '\$${_fmt(s?.totalPnl)}',
          'icon': Icons.trending_up_rounded,
          'color':
              (s?.totalPnl ?? 0) >= 0 ? Colors.green : Colors.red,
        },
        {
          'label': 'This Month',
          'val': '\$${_fmt(s?.commissionThisMonth)}',
          'icon': Icons.calendar_today_rounded,
          'color': Colors.purple,
        },
        {
          'label': 'Lots Traded',
          'val': _fmt(s?.totalLotsTraded),
          'icon': Icons.swap_horiz_rounded,
          'color': Colors.teal,
        },
        {
          'label': 'Active Investors',
          'val': '${s?.activeInvestors ?? 0}',
          'icon': Icons.people_alt_rounded,
          'color': Colors.blue,
        },
      ];
      return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 1.8,
          mainAxisSpacing: 10.h,
          crossAxisSpacing: 10.w,
        ),
        itemCount: items.length,
        itemBuilder: (_, i) {
          final item = items[i];
          final color = item['color'] as Color;
          return Container(
            padding: EdgeInsets.all(14.w),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12.r),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.04),
                    blurRadius: 8,
                    offset: const Offset(0, 2)),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(item['label'] as String,
                          style: TextStyle(
                              fontSize: 11.sp,
                              color: Colors.grey,
                              fontWeight: FontWeight.w500),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                    ),
                    Container(
                      padding: EdgeInsets.all(6.w),
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(item['icon'] as IconData,
                          size: 14.sp, color: color),
                    ),
                  ],
                ),
                Text(item['val'] as String,
                    style: TextStyle(
                        fontSize: 19.sp,
                        fontWeight: FontWeight.bold,
                        color: color)),
              ],
            ),
          );
        },
      );
    });
  }

  // ─── Recent Commissions ────────────────────────────────────────────────────
  Widget _buildRecentCommissions() {
    return Obx(() {
      final comms =
          controller.dashboardStats.value?.recentCommissions ?? [];
      if (comms.isEmpty) return const SizedBox.shrink();
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionHeader('Recent Commissions', null),
          SizedBox(height: 8.h),
          Container(
            decoration: _cardDecor(),
            child: Column(
              children: comms.asMap().entries.map((e) {
                final c = e.value;
                final isLast = e.key == comms.length - 1;
                return Column(
                  children: [
                    ListTile(
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 14.w, vertical: 4.h),
                      leading: _avatar(c.investorName ?? '', radius: 20.r),
                      title: Text(c.investorName ?? '—',
                          style: TextStyle(
                              fontSize: 13.sp, fontWeight: FontWeight.w600)),
                      subtitle: Text(
                          'Commission: \$${_fmt(c.commissionCharged)}',
                          style: TextStyle(
                              fontSize: 11.sp, color: Colors.grey)),
                      trailing: Text(
                        '+\$${_fmt(c.grossProfitShare)}',
                        style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                            fontSize: 14.sp),
                      ),
                    ),
                    if (!isLast)
                      Divider(height: 1, color: Colors.grey.shade100, indent: 14.w),
                  ],
                );
              }).toList(),
            ),
          ),
        ],
      );
    });
  }

  // ─── Plans ────────────────────────────────────────────────────────────────
  Widget _buildPlansSection() {
    return Obx(() {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionHeader('My Plans', () async {
            await Get.to(() => const CreatePlanScreen());
            controller.fetchManagerPlans();
          }),
          SizedBox(height: 8.h),
          if (controller.isLoadingPlans.value)
            Center(
                child: CircularProgressIndicator(color: AppColors.primary))
          else if (controller.managerPlans.isEmpty)
            _buildEmptyPlans()
          else
            ...controller.managerPlans
                .map((p) => _buildPlanCard(p))
                .toList(),
        ],
      );
    });
  }

  Widget _sectionHeader(String title, VoidCallback? onAdd) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title,
            style: TextStyle(
                fontSize: 15.sp,
                fontWeight: FontWeight.bold,
                color: const Color(0xFF1A1A2E))),
        if (onAdd != null)
          GestureDetector(
            onTap: onAdd,
            child: Container(
              padding:
                  EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.add, size: 14.sp, color: AppColors.primary),
                  SizedBox(width: 3.w),
                  Text('Add',
                      style: TextStyle(
                          color: AppColors.primary,
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildEmptyPlans() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(28.w),
      decoration: _cardDecor(),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16.w),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.post_add_rounded,
                size: 36.sp, color: AppColors.primary),
          ),
          SizedBox(height: 14.h),
          Text('No Plans Yet',
              style: TextStyle(
                  fontSize: 15.sp, fontWeight: FontWeight.bold)),
          SizedBox(height: 6.h),
          Text(
              'Create a plan to start accepting investors.',
              style: TextStyle(
                  fontSize: 12.sp, color: Colors.grey),
              textAlign: TextAlign.center),
          SizedBox(height: 20.h),
          SizedBox(
            width: 180.w,
            height: 42.h,
            child: ElevatedButton.icon(
              onPressed: () async {
                await Get.to(() => const CreatePlanScreen());
                controller.fetchManagerPlans();
              },
              icon: const Icon(Icons.add, color: Colors.white),
              label: Text('Create Plan',
                  style: TextStyle(
                      color: Colors.white, fontSize: 13.sp)),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.r)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlanCard(PmamPlan plan) {
    final isActive = plan.status == 'approved';
    final statusColor = isActive ? Colors.green : Colors.orange;

    return GestureDetector(
      onTap: () {
        if (plan.id != null) {
          controller.fetchPlanDetail(plan.id!);
          controller.fetchInvestorRequests(plan.id!);
          Get.to(() => PlanDetailScreen(plan: plan));
        }
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 12.h),
        decoration: _cardDecor(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: EdgeInsets.fromLTRB(14.w, 12.h, 14.w, 10.h),
              child: Row(
                children: [
                  Container(
                    width: 42.w,
                    height: 42.w,
                    decoration: BoxDecoration(
                      color: AppColors.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10.r),
                    ),
                    child: Icon(Icons.bar_chart_rounded,
                        color: AppColors.primary, size: 22.sp),
                  ),
                  SizedBox(width: 10.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(plan.planName ?? 'Unnamed Plan',
                            style: TextStyle(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.bold),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                        Text('Account: ${plan.tradingAccountNumber ?? '—'}',
                            style: TextStyle(
                                fontSize: 11.sp, color: Colors.grey)),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: 8.w, vertical: 3.h),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(
                          color: statusColor.withValues(alpha: 0.4)),
                    ),
                    child: Text(
                      isActive
                          ? 'Active'
                          : (plan.status == 'pending_admin'
                              ? 'Review'
                              : (plan.status?.capitalizeFirst ?? '')),
                      style: TextStyle(
                          color: statusColor,
                          fontSize: 10.sp,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: Colors.grey.shade100),
            // Stats
            Padding(
              padding:
                  EdgeInsets.symmetric(horizontal: 14.w, vertical: 10.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _planStat(Icons.percent, 'Commission',
                      '${_fmt(plan.commissionPercentage)}%', Colors.orange),
                  _planStat(Icons.savings_outlined, 'Min. Invest',
                      '\$${_fmt(plan.minimumInvestment)}', AppColors.primary),
                  _planStat(Icons.people_outline, 'Investors',
                      '${plan.activeInvestors ?? 0}', Colors.blue),
                  _planStat(Icons.account_balance_wallet_outlined, 'AUM',
                      '\$${_fmt(plan.totalLocked)}', Colors.teal),
                ],
              ),
            ),
            // Buttons
            Padding(
              padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 12.h),
              child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 36.h,
                      child: OutlinedButton(
                        onPressed: () => _showInactivateDialog(plan),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.red,
                          side: const BorderSide(color: Colors.red),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r)),
                          padding: EdgeInsets.zero,
                        ),
                        child: Text('Inactivate',
                            style: TextStyle(fontSize: 12.sp)),
                      ),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    flex: 2,
                    child: SizedBox(
                      height: 36.h,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          if (plan.id != null) {
                            controller.fetchPlanDetail(plan.id!);
                            controller.fetchInvestorRequests(plan.id!);
                            Get.to(() => PlanDetailScreen(plan: plan));
                          }
                        },
                        icon: Icon(Icons.arrow_forward,
                            size: 14.sp, color: Colors.white),
                        label: Text('View Details',
                            style: TextStyle(
                                fontSize: 12.sp, color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _planStat(IconData icon, String label, String val, Color color) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(6.w),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 14.sp, color: color),
        ),
        SizedBox(height: 4.h),
        Text(val,
            style: TextStyle(
                fontSize: 11.sp, fontWeight: FontWeight.bold)),
        Text(label,
            style: TextStyle(fontSize: 9.sp, color: Colors.grey)),
      ],
    );
  }

  void _showInactivateDialog(PmamPlan plan) {
    Get.dialog(Dialog(
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
      child: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(14.w),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.warning_amber_rounded,
                  color: Colors.red, size: 32.sp),
            ),
            SizedBox(height: 14.h),
            Text('Inactivate Plan?',
                style: TextStyle(
                    fontSize: 16.sp, fontWeight: FontWeight.bold)),
            SizedBox(height: 8.h),
            Text(
              '"${plan.planName}" will be inactivated. Only possible if there are no active investors with AUM.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12.sp, color: Colors.grey),
            ),
            SizedBox(height: 20.h),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Get.back(),
                  child: Text('Cancel',
                      style: TextStyle(fontSize: 13.sp)),
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: ElevatedButton(
                  onPressed: () async {
                    Get.back();
                    await controller.inactivatePlan(plan.id!);
                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red),
                  child: Text('Inactivate',
                      style: TextStyle(
                          color: Colors.white, fontSize: 13.sp)),
                ),
              ),
            ]),
          ],
        ),
      ),
    ));
  }

  Widget _avatar(String name, {required double radius}) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: AppColors.primary.withValues(alpha: 0.1),
      child: Text(
        name.isNotEmpty ? name[0].toUpperCase() : '?',
        style: TextStyle(
            color: AppColors.primary,
            fontWeight: FontWeight.bold,
            fontSize: radius * 0.7),
      ),
    );
  }

  BoxDecoration _cardDecor() => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ],
      );

  String _fmt(num? v) {
    if (v == null) return '0';
    if (v == v.round()) return v.round().toString();
    return v.toStringAsFixed(2);
  }
}
