import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:crm_app/constants/color.dart';
import 'package:crm_app/constants/text_styles.dart';
import 'package:crm_app/pmam/controllers/pmam_controller.dart';
import 'package:crm_app/services/api_service.dart';

class CreatePlanScreen extends StatefulWidget {
  const CreatePlanScreen({super.key});

  @override
  State<CreatePlanScreen> createState() => _CreatePlanScreenState();
}

class _CreatePlanScreenState extends State<CreatePlanScreen> {
  final _formKey = GlobalKey<FormState>();
  final controller = Get.find<PmamController>();

  final _planNameCtrl = TextEditingController();
  final _commissionCtrl = TextEditingController();
  final _minInvestCtrl = TextEditingController(text: '1000');
  final _descCtrl = TextEditingController();
  final _riskCtrl = TextEditingController();

  // MT5 Accounts dropdown
  final RxList<Map<String, dynamic>> _mt5Accounts = <Map<String, dynamic>>[].obs;
  final Rxn<int> _selectedAccountId = Rxn<int>();
  final RxBool _loadingAccounts = false.obs;

  @override
  void initState() {
    super.initState();
    _loadMt5Accounts();
  }

  Future<void> _loadMt5Accounts() async {
    try {
      _loadingAccounts.value = true;
      // Fetch live MT5 accounts of the manager
      final response = await ApiService.get(endpoint: 'user/accounts');
      if (response.success && response.data != null) {
        final list = response.data['data'] as List? ?? [];
        _mt5Accounts.assignAll(
          list
              .where((a) => a['account_type'] == 'live' || a['type'] == 'live')
              .map<Map<String, dynamic>>((a) => Map<String, dynamic>.from(a))
              .toList(),
        );
      }
    } catch (e) {
      print('Error loading MT5 accounts: $e');
    } finally {
      _loadingAccounts.value = false;
    }
  }

  @override
  void dispose() {
    _planNameCtrl.dispose();
    _commissionCtrl.dispose();
    _minInvestCtrl.dispose();
    _descCtrl.dispose();
    _riskCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('Create PMAM Plan', style: AppTextStyles.screenTitle),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.w),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Plan Information',
                style: AppTextStyles.headingblack.copyWith(fontSize: 18.sp),
              ),
              SizedBox(height: 6.h),
              Text(
                'Configure your PMAM plan. Investors will see this information.',
                style: AppTextStyles.subheading,
              ),
              SizedBox(height: 24.h),

              // Trading Account
              _buildLabel('Trading Account *'),
              SizedBox(height: 6.h),
              Obx(() {
                if (_loadingAccounts.value) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (_mt5Accounts.isEmpty) {
                  return Container(
                    padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade50,
                      borderRadius: BorderRadius.circular(8.r),
                      border: Border.all(color: Colors.orange.shade100),
                    ),
                    child: Text(
                      'No live MT5 accounts found. Please create a live trading account first.',
                      style: AppTextStyles.grey11400
                          .copyWith(color: Colors.orange.shade800),
                    ),
                  );
                }
                return DropdownButtonFormField<int>(
                  value: _selectedAccountId.value,
                  decoration: _inputDecoration('Select trading account'),
                  items: _mt5Accounts.map((acc) {
                    final id = acc['id'] as int?;
                    final number = acc['meta_account_number'] ??
                        acc['account_number'] ??
                        '—';
                    final balance = acc['balance'] ?? 0;
                    return DropdownMenuItem<int>(
                      value: id,
                      child: Text(
                        '$number (Balance: \$$balance)',
                        style: TextStyle(fontSize: 13.sp),
                      ),
                    );
                  }).toList(),
                  onChanged: (v) => _selectedAccountId.value = v,
                  validator: (v) =>
                      v == null ? 'Please select a trading account' : null,
                );
              }),
              SizedBox(height: 16.h),

              // Plan Name
              _buildLabel('Plan Name *'),
              SizedBox(height: 6.h),
              TextFormField(
                controller: _planNameCtrl,
                decoration: _inputDecoration('e.g. Gold Swing Strategy'),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'Plan name is required';
                  if (v.trim().length < 3) return 'Min 3 characters';
                  return null;
                },
              ),
              SizedBox(height: 16.h),

              // Commission & Min Investment in row
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildLabel('Commission % *'),
                        SizedBox(height: 6.h),
                        TextFormField(
                          controller: _commissionCtrl,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true),
                          decoration: _inputDecoration('0–100'),
                          validator: (v) {
                            final n = num.tryParse(v ?? '');
                            if (n == null) return 'Required';
                            if (n < 0 || n > 100)
                              return '0–100 only';
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildLabel('Min. Investment (USD) *'),
                        SizedBox(height: 6.h),
                        TextFormField(
                          controller: _minInvestCtrl,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true),
                          decoration: _inputDecoration('e.g. 1000'),
                          validator: (v) {
                            final n = num.tryParse(v ?? '');
                            if (n == null) return 'Required';
                            if (n < 0) return 'Must be ≥ 0';
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16.h),

              // Strategy Description
              _buildLabel('Strategy Description *'),
              SizedBox(height: 6.h),
              TextFormField(
                controller: _descCtrl,
                maxLines: 4,
                decoration: _inputDecoration(
                    'Describe your trading strategy in detail…'),
                validator: (v) {
                  if (v == null || v.trim().isEmpty)
                    return 'Description is required';
                  if (v.trim().length < 10) return 'Min 10 characters';
                  return null;
                },
              ),
              SizedBox(height: 16.h),

              // Risk Information
              _buildLabel('Risk Information'),
              SizedBox(height: 6.h),
              TextFormField(
                controller: _riskCtrl,
                maxLines: 3,
                decoration: _inputDecoration(
                    'Describe any risk factors investors should know…'),
              ),
              SizedBox(height: 32.h),

              // Submit
              Obx(() => SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: controller.isSubmitting.value
                          ? null
                          : _onSubmit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        disabledBackgroundColor:
                            AppColors.primary.withOpacity(0.5),
                        padding: EdgeInsets.symmetric(vertical: 15.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                      ),
                      child: controller.isSubmitting.value
                          ? SizedBox(
                              height: 20.h,
                              width: 20.h,
                              child: const CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : Text('Create Plan', style: AppTextStyles.button),
                    ),
                  )),
              SizedBox(height: 20.h),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _onSubmit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedAccountId.value == null) {
      Get.snackbar('Error', 'Please select a trading account.',
          snackPosition: SnackPosition.BOTTOM);
      return;
    }
    final success = await controller.createPlan(
      tradingAccountId: _selectedAccountId.value!,
      planName: _planNameCtrl.text.trim(),
      commissionPercentage: num.parse(_commissionCtrl.text.trim()),
      minimumInvestment: num.parse(_minInvestCtrl.text.trim()),
      strategyDescription: _descCtrl.text.trim(),
      riskInformation: _riskCtrl.text.trim(),
    );
    if (success) Get.back();
  }

  Widget _buildLabel(String text) {
    return Text(text,
        style:
            AppTextStyles.label.copyWith(fontWeight: FontWeight.w600));
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: AppTextStyles.grey11400,
      contentPadding:
          EdgeInsets.symmetric(horizontal: 14.w, vertical: 12.h),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8.r),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8.r),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8.r),
        borderSide: BorderSide(color: AppColors.primary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8.r),
        borderSide: const BorderSide(color: Colors.red),
      ),
    );
  }
}
