import 'dart:io';
import 'package:pipze/core/constants/api_const.dart';
import 'package:pipze/core/services/api_service.dart';
import 'package:pipze/data/models/login_response_model.dart';

abstract class AuthRepository {
  Future<ApiResponse<LoginResponseModel>> login({
    required String email,
    required String password,
  });
  
  Future<ApiResponse<Map<String, dynamic>>> sendOTP({
    required String email,
  });
  
  Future<ApiResponse<Map<String, dynamic>>> verifyOTP({
    required String email,
    required String otp,
  });
  
  Future<ApiResponse<Map<String, dynamic>>> resetPassword({
    required String email,
    required String otp,
    required String newPassword,
  });
  
  Future<ApiResponse<Map<String, dynamic>>> register({
    required String firstName,
    required String lastName,
    required String email,
    required String password,
    required String mobile,
    required String otp,
    required String registerEventType,
    required bool acceptTerms,
  });
}

class AuthRepositoryImpl implements AuthRepository {
  @override
  Future<ApiResponse<LoginResponseModel>> login({
    required String email,
    required String password,
  }) async {
    try {
      final data = {'email': email, 'password': password};

      final response = await ApiService.post(
        endpoint: ApiConstants.login,
        data: data,
      );

      print("object of_loginmesafe 1 ${response.data?['message']}");

      if (response.data != null) {
        try {
          final loginResponse = LoginResponseModel.fromJson(response.data);

          // Check if the API response indicates success
          if (loginResponse.status) {
            return ApiResponse.success(loginResponse);
          } else {
            // API returned success: false, return the error message
            return ApiResponse.error(loginResponse.message);
          }
        } catch (e, t) {
          print("object of_loginmesafe 2 ${e.toString()}");
          print("object of_loginmesafe 3 ${t.toString()}");
          return ApiResponse.error(
            'Failed to parse login response: ${e.toString()}',
          );
        }
      } else {
        return ApiResponse.error(response.message ?? 'Login failed');
      }
    } on SocketException {
      return ApiResponse.error(
        'No internet connection. Please check your network.',
      );
    } catch (e, t) {
      print("object of_loginmesafe 4 ${e.toString()}");
      print("object of_loginmesafe 5 ${t.toString()}");
      return ApiResponse.error('Login failed: ${e.toString()}');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> sendOTP({
    required String email,
  }) async {
    try {
      final data = {'email': email};

      final response = await ApiService.post(
        endpoint: ApiConstants.forgotPassword,
        data: data,
      );

      if (response.data != null) {
        // Check if the API response indicates success
        final status = response.data['status'];
        final message = response.data['message'];
        
        print("SendOTP API Response - Status: $status, Message: $message");
        
        if (status == true) {
          return ApiResponse.success(response.data);
        } else {
          // API returned status: false, return the error message
          return ApiResponse.error(message ?? 'Failed to send OTP');
        }
      } else {
        return ApiResponse.error(response.message ?? 'Failed to send OTP');
      }
    } on SocketException {
      return ApiResponse.error(
        'No internet connection. Please check your network.',
      );
    } catch (e) {
      return ApiResponse.error('Failed to send OTP: ${e.toString()}');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> verifyOTP({
    required String email,
    required String otp,
  }) async {
    try {
      final data = {
        'email': email,
        'otp': otp,
      };

      final response = await ApiService.post(
        endpoint: ApiConstants.verifyOTP,
        data: data,
      );

      if (response.data != null) {
        // Check if the API response indicates success
        final status = response.data['status'];
        final message = response.data['message'];
        
        print("VerifyOTP API Response - Status: $status, Message: $message");
        
        if (status == true) {
          return ApiResponse.success(response.data);
        } else {
          // API returned status: false, return the error message
          return ApiResponse.error(message ?? 'Failed to verify OTP');
        }
      } else {
        return ApiResponse.error(response.message ?? 'Failed to verify OTP');
      }
    } on SocketException {
      return ApiResponse.error(
        'No internet connection. Please check your network.',
      );
    } catch (e) {
      return ApiResponse.error('Failed to verify OTP: ${e.toString()}');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> resetPassword({
    required String email,
    required String otp,
    required String newPassword,
  }) async {
    try {
      final data = {
        'email': email,
        'otp': otp,
        'new_password': newPassword,
      };

      final response = await ApiService.post(
        endpoint: ApiConstants.resetPassword,
        data: data,
      );

      if (response.data != null) {
        // Check if the API response indicates success
        final status = response.data['status'];
        final message = response.data['message'];
        
        print("ResetPassword API Response - Status: $status, Message: $message");
        
        if (status == true) {
          return ApiResponse.success(response.data);
        } else {
          // API returned status: false, return the error message
          return ApiResponse.error(message ?? 'Failed to reset password');
        }
      } else {
        return ApiResponse.error(response.message ?? 'Failed to reset password');
      }
    } on SocketException {
      return ApiResponse.error(
        'No internet connection. Please check your network.',
      );
    } catch (e) {
      return ApiResponse.error('Failed to reset password: ${e.toString()}');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> register({
    required String firstName,
    required String lastName,
    required String email,
    required String password,
    required String mobile,
    required String otp,
    required String registerEventType,
    required bool acceptTerms,
  }) async {
    try {
      final data = {
        'first_name': firstName,
        'last_name': lastName,
        'email': email,
        'password': password,
        'mobile': mobile,
        'otp': otp,
        'register_event_type': registerEventType,
        'accept_terms': acceptTerms,
      };

      final response = await ApiService.post(
        endpoint: ApiConstants.register,
        data: data,
      );

      if (response.data != null) {
        // Check if the API response indicates success
        final status = response.data['status'];
        final message = response.data['message'];
        
        print("Register API Response - Status: $status, Message: $message");
        
        if (status == true) {
          return ApiResponse.success(response.data);
        } else {
          // API returned status: false, return the error message
          return ApiResponse.error(message ?? 'Registration failed');
        }
      } else {
        return ApiResponse.error(response.message ?? 'Registration failed');
      }
    } on SocketException {
      return ApiResponse.error(
        'No internet connection. Please check your network.',
      );
    } catch (e) {
      return ApiResponse.error('Registration failed: ${e.toString()}');
    }
  }
}
