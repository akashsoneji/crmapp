import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/account_model.dart';

abstract class AccountRepository {
  Future<List<AccountModel>> getAccounts();
  Future<AccountModel?> getActiveAccount();
  Future<void> setActiveAccount(String accountId);
  Future<void> addAccount(AccountModel account);
  Future<void> updateAccount(AccountModel account);
  Future<void> deleteAccount(String accountId);
  Future<void> updateAccountBalance(String accountId, double newBalance);
  Future<void> resetToDefaultAccounts();
}

class AccountRepositoryImpl implements AccountRepository {
  static const String _accountsKey = 'user_accounts';
  static const String _activeAccountKey = 'active_account_id';

  @override
  Future<List<AccountModel>> getAccounts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final accountsJson = prefs.getString(_accountsKey);

      if (accountsJson == null) {
        // Initialize with default accounts if none exist
        final defaultAccounts = _getDefaultAccounts();
        await _saveAccounts(defaultAccounts);
        return defaultAccounts;
      }

      final List<dynamic> accountsList = jsonDecode(accountsJson);
      final accounts =
          accountsList.map((json) => AccountModel.fromJson(json)).toList();

      // Ensure we have at least the default accounts
      if (accounts.isEmpty) {
        final defaultAccounts = _getDefaultAccounts();
        await _saveAccounts(defaultAccounts);
        return defaultAccounts;
      }

      return accounts;
    } catch (e) {
      print('Error loading accounts: $e');
      final defaultAccounts = _getDefaultAccounts();
      await _saveAccounts(defaultAccounts);
      return defaultAccounts;
    }
  }

  @override
  Future<AccountModel?> getActiveAccount() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final activeAccountId = prefs.getString(_activeAccountKey);

      if (activeAccountId == null) {
        final accounts = await getAccounts();
        if (accounts.isNotEmpty) {
          // Set first account as active if none is set
          await setActiveAccount(accounts.first.id);
          return accounts.first;
        }
        return null;
      }

      final accounts = await getAccounts();
      return accounts.firstWhere(
        (account) => account.id == activeAccountId,
        orElse:
            () =>
                accounts.isNotEmpty
                    ? accounts.first
                    : _getDefaultAccounts().first,
      );
    } catch (e) {
      print('Error getting active account: $e');
      return null;
    }
  }

  @override
  Future<void> setActiveAccount(String accountId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_activeAccountKey, accountId);

      // Update accounts list to mark the selected account as active
      final accounts = await getAccounts();
      final updatedAccounts =
          accounts.map((account) {
            return account.copyWith(isActive: account.id == accountId);
          }).toList();

      await _saveAccounts(updatedAccounts);

      // Simulate balance changes for demo purposes
      await _simulateBalanceChange(accountId);
    } catch (e) {
      print('Error setting active account: $e');
    }
  }

  // Simulate balance changes when switching accounts
  Future<void> _simulateBalanceChange(String accountId) async {
    try {
      final accounts = await getAccounts();
      final accountIndex = accounts.indexWhere(
        (account) => account.id == accountId,
      );

      if (accountIndex != -1) {
        final account = accounts[accountIndex];
        double newBalance;

        // Simulate different balance changes based on account type
        if (account.type == 'REAL') {
          // Real account: small random changes
          final random = DateTime.now().millisecondsSinceEpoch % 100;
          newBalance = account.balance + (random - 50) * 0.01; // Small changes
        } else {
          // Demo account: larger random changes for demonstration
          final random = DateTime.now().millisecondsSinceEpoch % 200;
          newBalance = account.balance + (random - 100) * 0.1; // Larger changes
        }

        // Ensure balance doesn't go negative
        newBalance = newBalance < 0 ? 0 : newBalance;

        // Update the account balance
        accounts[accountIndex] = account.copyWith(balance: newBalance);
        await _saveAccounts(accounts);
      }
    } catch (e) {
      print('Error simulating balance change: $e');
    }
  }

  @override
  Future<void> addAccount(AccountModel account) async {
    try {
      final accounts = await getAccounts();
      accounts.add(account);
      await _saveAccounts(accounts);
    } catch (e) {
      print('Error adding account: $e');
    }
  }

  @override
  Future<void> updateAccount(AccountModel updatedAccount) async {
    try {
      final accounts = await getAccounts();
      final index = accounts.indexWhere(
        (account) => account.id == updatedAccount.id,
      );

      if (index != -1) {
        accounts[index] = updatedAccount;
        await _saveAccounts(accounts);
      }
    } catch (e) {
      print('Error updating account: $e');
    }
  }

  @override
  Future<void> deleteAccount(String accountId) async {
    try {
      final accounts = await getAccounts();
      accounts.removeWhere((account) => account.id == accountId);
      await _saveAccounts(accounts);

      // If deleted account was active, set first available account as active
      final activeAccount = await getActiveAccount();
      if (activeAccount?.id == accountId && accounts.isNotEmpty) {
        await setActiveAccount(accounts.first.id);
      }
    } catch (e) {
      print('Error deleting account: $e');
    }
  }

  @override
  Future<void> updateAccountBalance(String accountId, double newBalance) async {
    try {
      final accounts = await getAccounts();
      final index = accounts.indexWhere((account) => account.id == accountId);

      if (index != -1) {
        accounts[index] = accounts[index].copyWith(balance: newBalance);
        await _saveAccounts(accounts);
      }
    } catch (e) {
      print('Error updating account balance: $e');
    }
  }

  // Reset accounts to default values
  @override
  Future<void> resetToDefaultAccounts() async {
    try {
      final defaultAccounts = _getDefaultAccounts();
      await _saveAccounts(defaultAccounts);

      // Set the first account (REAL) as active
      if (defaultAccounts.isNotEmpty) {
        await setActiveAccount(defaultAccounts.first.id);
      }
    } catch (e) {
      print('Error resetting to default accounts: $e');
    }
  }

  Future<void> _saveAccounts(List<AccountModel> accounts) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final accountsJson = jsonEncode(
        accounts.map((account) => account.toJson()).toList(),
      );
      await prefs.setString(_accountsKey, accountsJson);
    } catch (e) {
      print('Error saving accounts: $e');
    }
  }

  List<AccountModel> _getDefaultAccounts() {
    return [
      AccountModel(
        id: '124796510',
        type: 'REAL',
        balance: 1250.75,
        currency: 'USD',
        isActive: true,
        createdAt: DateTime.now(),
        metadata: {'isDefault': true},
      ),
      AccountModel(
        id: '321587053',
        type: 'DEMO',
        balance: 5021.96,
        currency: 'USD',
        isActive: false,
        createdAt: DateTime.now().subtract(Duration(days: 7)),
        metadata: {'isDefault': true},
      ),
    ];
  }
}
