import '../models/candle_data_model.dart';
import '../datasources/remote/trading_api_service.dart';

class TradingRepository {
  final TradingApiService _apiService = TradingApiService();

  // Get candlestick data
  Future<List<CandleDataModel>> getCandlestickData({
    required String symbol,
    required String interval,
    required int limit,
  }) async {
    try {
      return await _apiService.getCandlestickData(
        symbol: symbol,
        interval: interval,
        limit: limit,
      );
    } catch (e) {
      throw Exception('Failed to fetch candlestick data: $e');
    }
  }

  // Get real-time price
  Future<Map<String, dynamic>> getRealTimePrice(String symbol) async {
    try {
      return await _apiService.getRealTimePrice(symbol);
    } catch (e) {
      throw Exception('Failed to fetch real-time price: $e');
    }
  }

  // Get available symbols
  List<String> getAvailableSymbols() {
    return [
      'EURUSD',
      'GBPUSD',
      'USDJPY',
      'USDCHF',
      'AUDUSD',
      'USDCAD',
      'NZDUSD',
      'EURGBP',
      'EURJPY',
      'GBPJPY',
    ];
  }

  // Get available timeframes
  List<String> getAvailableTimeframes() {
    return [
      '1s',
      '5s',
      '15s',
      '30s',
      '1m',
      '5m',
      '15m',
      '30m',
      '1h',
      '4h',
      '1d',
      '1w',
      '1M',
    ];
  }

  // Convert timeframe to API format
  String convertTimeframeToApiFormat(String timeframe) {
    switch (timeframe) {
      case '1s':
        return '1s';
      case '5s':
        return '5s';
      case '15s':
        return '15s';
      case '30s':
        return '30s';
      case '1m':
        return '1m';
      case '5m':
        return '5m';
      case '15m':
        return '15m';
      case '30m':
        return '30m';
      case '1h':
        return '1h';
      case '4h':
        return '4h';
      case '1d':
        return '1d';
      case '1w':
        return '1w';
      case '1M':
        return '1M';
      default:
        return '1m';
    }
  }

  // Get default limit for timeframe
  int getDefaultLimitForTimeframe(String timeframe) {
    switch (timeframe) {
      case '1s':
      case '5s':
      case '15s':
      case '30s':
        return 100;
      case '1m':
      case '5m':
      case '15m':
      case '30m':
        return 200;
      case '1h':
      case '4h':
        return 100;
      case '1d':
      case '1w':
      case '1M':
        return 50;
      default:
        return 100;
    }
  }
}
