import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;

class MarketDataService {
  // Alpha Vantage API (Free tier available)
  static const String _alphaVantageApiKey = 'demo'; // Replace with your API key
  static const String _alphaVantageBaseUrl =
      'https://www.alphavantage.co/query';

  // Alternative: Finnhub API
  static const String _finnhubApiKey = 'demo'; // Replace with your API key
  static const String _finnhubBaseUrl = 'https://finnhub.io/api/v1';

  // Alternative: Yahoo Finance API
  static const String _yahooBaseUrl =
      'https://query1.finance.yahoo.com/v8/finance/chart';

  /// Fetch real-time forex data
  static Future<Map<String, dynamic>> getForexData(String symbol) async {
    try {
      // Try Alpha Vantage first
      final response = await http.get(
        Uri.parse(
          '$_alphaVantageBaseUrl?function=CURRENCY_EXCHANGE_RATE&from_currency=${symbol.substring(0, 3)}&to_currency=${symbol.substring(3, 6)}&apikey=$_alphaVantageApiKey',
        ),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['Realtime Currency Exchange Rate'] != null) {
          final rate = data['Realtime Currency Exchange Rate'];
          return {
            'symbol': symbol,
            'bid': double.parse(rate['5. Exchange Rate']),
            'ask': double.parse(rate['5. Exchange Rate']) + 0.0001,
            'timestamp': DateTime.parse(rate['6. Last Refreshed']),
            'change': 0.0, // Calculate from previous data
            'changePercent': 0.0,
          };
        }
      }

      // Fallback to simulated data with realistic values
      return _getSimulatedForexData(symbol);
    } catch (e) {
      print('Error fetching forex data: $e');
      return _getSimulatedForexData(symbol);
    }
  }

  /// Fetch historical candlestick data
  static Future<List<Map<String, dynamic>>> getCandlestickData(
    String symbol,
    String interval,
    int count,
  ) async {
    try {
      // Convert interval to API format
      final apiInterval = _convertIntervalToApi(interval);

      // Try Yahoo Finance API
      final response = await http.get(
        Uri.parse('$_yahooBaseUrl/$symbol?interval=$apiInterval&range=1d'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['chart'] != null && data['chart']['result'] != null) {
          final result = data['chart']['result'][0];
          final timestamps = result['timestamp'] as List;
          final quotes = result['indicators']['quote'][0];

          List<Map<String, dynamic>> candles = [];
          for (int i = 0; i < timestamps.length && i < count; i++) {
            if (quotes['open'][i] != null) {
              candles.add({
                'time': DateTime.fromMillisecondsSinceEpoch(
                  timestamps[i] * 1000,
                ),
                'open': quotes['open'][i].toDouble(),
                'high': quotes['high'][i].toDouble(),
                'low': quotes['low'][i].toDouble(),
                'close': quotes['close'][i].toDouble(),
                'volume': quotes['volume'][i]?.toDouble() ?? 0.0,
              });
            }
          }

          if (candles.isNotEmpty) {
            return candles;
          }
        }
      }

      // Fallback to realistic simulated data
      return _getSimulatedCandlestickData(symbol, interval, count);
    } catch (e) {
      print('Error fetching candlestick data: $e');
      return _getSimulatedCandlestickData(symbol, interval, count);
    }
  }

  /// Get real-time price updates
  static Stream<Map<String, dynamic>> getRealTimePriceStream(
    String symbol,
  ) async* {
    while (true) {
      try {
        final data = await getForexData(symbol);
        yield data;
        await Future.delayed(Duration(seconds: 1));
      } catch (e) {
        print('Error in real-time stream: $e');
        await Future.delayed(Duration(seconds: 5));
      }
    }
  }

  /// Convert interval to API format
  static String _convertIntervalToApi(String interval) {
    switch (interval) {
      case '15s':
        return '1m'; // Yahoo doesn't support 15s, use 1m
      case '1m':
        return '1m';
      case '5m':
        return '5m';
      case '15m':
        return '15m';
      case '1h':
        return '1h';
      case '4h':
        return '4h';
      case '1d':
        return '1d';
      default:
        return '1m';
    }
  }

  /// Get simulated forex data with realistic values
  static Map<String, dynamic> _getSimulatedForexData(String symbol) {
    final basePrice = _getBasePriceForSymbol(symbol);
    final random = DateTime.now().millisecondsSinceEpoch % 1000 / 1000.0;
    final change = (random - 0.5) * 0.001;
    final currentPrice = basePrice + change;

    return {
      'symbol': symbol,
      'bid': currentPrice - 0.0001,
      'ask': currentPrice + 0.0001,
      'timestamp': DateTime.now(),
      'change': change,
      'changePercent': (change / basePrice) * 100,
    };
  }

  /// Get simulated candlestick data with realistic values
  static List<Map<String, dynamic>> _getSimulatedCandlestickData(
    String symbol,
    String interval,
    int count,
  ) {
    final basePrice = _getBasePriceForSymbol(symbol);
    final random = Random();
    final now = DateTime.now();
    final intervalSeconds = _getIntervalSeconds(interval);

    List<Map<String, dynamic>> candles = [];
    double currentPrice = basePrice;

    for (int i = count - 1; i >= 0; i--) {
      final time = now.subtract(Duration(seconds: i * intervalSeconds));

      // Generate realistic price movement
      final volatility = 0.0005; // 5 pips volatility
      final direction = random.nextBool() ? 1 : -1;
      final movement = random.nextDouble() * volatility * direction;

      final open = currentPrice;
      final close = currentPrice + movement;
      final high =
          open > close
              ? open + random.nextDouble() * volatility
              : close + random.nextDouble() * volatility;
      final low =
          open > close
              ? close - random.nextDouble() * volatility
              : open - random.nextDouble() * volatility;
      final volume = 1000 + random.nextDouble() * 2000;

      candles.add({
        'time': time,
        'open': open,
        'high': high,
        'low': low,
        'close': close,
        'volume': volume,
      });

      currentPrice = close;
    }

    return candles;
  }

  /// Get base price for different symbols
  static double _getBasePriceForSymbol(String symbol) {
    switch (symbol.toUpperCase()) {
      case 'EURUSD':
        return 1.0850;
      case 'GBPUSD':
        return 1.2650;
      case 'USDJPY':
        return 148.50;
      case 'USDCHF':
        return 0.8650;
      case 'AUDUSD':
        return 0.6650;
      case 'USDCAD':
        return 1.3550;
      case 'NZDUSD':
        return 0.6150;
      case 'XAUUSD':
        return 2020.0;
      case 'XAGUSD':
        return 23.50;
      default:
        return 1.0850;
    }
  }

  /// Get interval in seconds
  static int _getIntervalSeconds(String interval) {
    switch (interval) {
      case '15s':
        return 15;
      case '1m':
        return 60;
      case '5m':
        return 300;
      case '15m':
        return 900;
      case '1h':
        return 3600;
      case '4h':
        return 14400;
      case '1d':
        return 86400;
      default:
        return 60;
    }
  }
}
