// TradingView Charting Library Types
// Simple data classes for TradingView chart configuration

class TVChartConfig {
  final String? symbol;
  final String? interval;
  final String? timezone;
  final String? theme;
  final String? style;
  final String? locale;
  final String? toolbar_bg;
  final bool? enable_publishing;
  final bool? hide_side_toolbar;
  final bool? allow_symbol_change;
  final String? container_id;
  final List<String>? studies;
  final bool? show_popup_button;
  final String? popup_width;
  final String? popup_height;
  final String? library_path;
  final String? custom_css_url;
  final String? disabled_features;
  final String? enabled_features;
  final String? charts_storage_url;
  final String? charts_storage_api_version;
  final String? client_id;
  final String? user_id;
  final String? fullscreen;
  final String? autosize;
  final String? studies_overrides;
  final String? theme_overrides;
  final String? loading_screen;
  final String? custom_indicators;
  final String? overrides;
  final String? favorites;
  final String? saved_objects;
  final String? settings;
  final String? actions;
  final String? indicators_file_name;
  final String? container;
  final String? datafeed;

  TVChartConfig({
    this.symbol,
    this.interval,
    this.timezone,
    this.theme,
    this.style,
    this.locale,
    this.toolbar_bg,
    this.enable_publishing,
    this.hide_side_toolbar,
    this.allow_symbol_change,
    this.container_id,
    this.studies,
    this.show_popup_button,
    this.popup_width,
    this.popup_height,
    this.library_path,
    this.custom_css_url,
    this.disabled_features,
    this.enabled_features,
    this.charts_storage_url,
    this.charts_storage_api_version,
    this.client_id,
    this.user_id,
    this.fullscreen,
    this.autosize,
    this.studies_overrides,
    this.theme_overrides,
    this.loading_screen,
    this.custom_indicators,
    this.overrides,
    this.favorites,
    this.saved_objects,
    this.settings,
    this.actions,
    this.indicators_file_name,
    this.container,
    this.datafeed,
  });

  Map<String, dynamic> toJson() {
    return {
      if (symbol != null) 'symbol': symbol,
      if (interval != null) 'interval': interval,
      if (timezone != null) 'timezone': timezone,
      if (theme != null) 'theme': theme,
      if (style != null) 'style': style,
      if (locale != null) 'locale': locale,
      if (toolbar_bg != null) 'toolbar_bg': toolbar_bg,
      if (enable_publishing != null) 'enable_publishing': enable_publishing,
      if (hide_side_toolbar != null) 'hide_side_toolbar': hide_side_toolbar,
      if (allow_symbol_change != null)
        'allow_symbol_change': allow_symbol_change,
      if (container_id != null) 'container_id': container_id,
      if (studies != null) 'studies': studies,
      if (show_popup_button != null) 'show_popup_button': show_popup_button,
      if (popup_width != null) 'popup_width': popup_width,
      if (popup_height != null) 'popup_height': popup_height,
      if (library_path != null) 'library_path': library_path,
      if (custom_css_url != null) 'custom_css_url': custom_css_url,
      if (disabled_features != null) 'disabled_features': disabled_features,
      if (enabled_features != null) 'enabled_features': enabled_features,
      if (charts_storage_url != null) 'charts_storage_url': charts_storage_url,
      if (charts_storage_api_version != null)
        'charts_storage_api_version': charts_storage_api_version,
      if (client_id != null) 'client_id': client_id,
      if (user_id != null) 'user_id': user_id,
      if (fullscreen != null) 'fullscreen': fullscreen,
      if (autosize != null) 'autosize': autosize,
      if (studies_overrides != null) 'studies_overrides': studies_overrides,
      if (theme_overrides != null) 'theme_overrides': theme_overrides,
      if (loading_screen != null) 'loading_screen': loading_screen,
      if (custom_indicators != null) 'custom_indicators': custom_indicators,
      if (overrides != null) 'overrides': overrides,
      if (favorites != null) 'favorites': favorites,
      if (saved_objects != null) 'saved_objects': saved_objects,
      if (settings != null) 'settings': settings,
      if (actions != null) 'actions': actions,
      if (indicators_file_name != null)
        'indicators_file_name': indicators_file_name,
      if (container != null) 'container': container,
      if (datafeed != null) 'datafeed': datafeed,
    };
  }
}

class TVChartData {
  final String? symbol;
  final String? interval;
  final List<TVCandlestick>? candles;

  TVChartData({this.symbol, this.interval, this.candles});

  Map<String, dynamic> toJson() {
    return {
      if (symbol != null) 'symbol': symbol,
      if (interval != null) 'interval': interval,
      if (candles != null) 'candles': candles?.map((c) => c.toJson()).toList(),
    };
  }
}

class TVCandlestick {
  final int? time;
  final double? open;
  final double? high;
  final double? low;
  final double? close;
  final double? volume;

  TVCandlestick({
    this.time,
    this.open,
    this.high,
    this.low,
    this.close,
    this.volume,
  });

  Map<String, dynamic> toJson() {
    return {
      if (time != null) 'time': time,
      if (open != null) 'open': open,
      if (high != null) 'high': high,
      if (low != null) 'low': low,
      if (close != null) 'close': close,
      if (volume != null) 'volume': volume,
    };
  }
}

class TVChartMessage {
  final String? type;
  final dynamic data;

  TVChartMessage({this.type, this.data});

  Map<String, dynamic> toJson() {
    return {if (type != null) 'type': type, if (data != null) 'data': data};
  }
}
