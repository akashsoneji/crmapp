class ChartSampleData {
  ChartSampleData({
    this.x,
    this.open,
    this.close,
    this.low,
    this.high,
    this.volume,
  });

  final DateTime? x;
  final num? open;
  final num? close;
  final num? low;
  final num? high;
  final num? volume;
}
