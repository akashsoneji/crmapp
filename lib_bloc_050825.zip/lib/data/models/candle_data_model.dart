class CandleDataModel {
  final double open;
  final double high;
  final double low;
  final double close;
  final int volume;
  final DateTime timestamp;
  final String symbol;

  CandleDataModel({
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
    required this.timestamp,
    required this.symbol,
  });

  factory CandleDataModel.fromJson(Map<String, dynamic> json) {
    return CandleDataModel(
      open: (json['open'] as num).toDouble(),
      high: (json['high'] as num).toDouble(),
      low: (json['low'] as num).toDouble(),
      close: (json['close'] as num).toDouble(),
      volume: json['volume'] as int,
      timestamp: DateTime.fromMillisecondsSinceEpoch(json['timestamp'] as int),
      symbol: json['symbol'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'open': open,
      'high': high,
      'low': low,
      'close': close,
      'volume': volume,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'symbol': symbol,
    };
  }

  bool get isBullish => close > open;
  bool get isBearish => close < open;
  double get bodySize => (close - open).abs();
  double get upperWick => high - (close > open ? close : open);
  double get lowerWick => (close > open ? open : close) - low;
  double get totalRange => high - low;
}
