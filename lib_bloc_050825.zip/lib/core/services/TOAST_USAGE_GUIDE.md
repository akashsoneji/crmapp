# Custom Toast Usage Guide

## Overview
This custom toast system provides beautiful, animated toast messages that slide down from the top of the screen, wait for a specified duration, then slide back up with smooth animations. It's designed to replace the default Scaffold messages throughout your app.

## Features
- ✅ Smooth slide animations (down → wait → up)
- ✅ Multiple toast types (success, error, warning, info)
- ✅ Customizable duration
- ✅ Automatic queuing for multiple toasts
- ✅ Manual dismiss with X button
- ✅ Consistent styling with your app theme
- ✅ Responsive design with ScreenUtil

## Quick Start

### 1. Basic Usage
```dart
// Show a simple info toast
ToastService().showInfo('This is an informational message');

// Show success toast
ToastService().showSuccess('Operation completed successfully!');

// Show error toast
ToastService().showError('Something went wrong. Please try again.');

// Show warning toast
ToastService().showWarning('Please check your input before proceeding.');
```

### 2. Custom Duration
```dart
// Show toast for 6 seconds
ToastService().showSuccess(
  'This will stay visible for 6 seconds',
  duration: const Duration(seconds: 6),
);

// Show error for longer duration
ToastService().showError(
  'Important error message',
  duration: const Duration(seconds: 5),
);
```

### 3. Custom Toast Type
```dart
// Use the generic showToast method for custom types
ToastService().showToast(
  message: 'Custom message',
  type: ToastType.info, // or success, error, warning
  duration: const Duration(seconds: 3),
);
```

## Toast Types

| Type | Color | Icon | Use Case |
|------|-------|------|----------|
| `ToastType.success` | Green | ✓ | Successful operations |
| `ToastType.error` | Red | ⚠ | Errors and failures |
| `ToastType.warning` | Orange | ⚠ | Warnings and cautions |
| `ToastType.info` | Blue | ℹ | General information |

## Advanced Usage

### Multiple Toasts
The system automatically queues multiple toasts. When one toast finishes, the next one appears:

```dart
// These will show one after another
ToastService().showSuccess('First toast');
ToastService().showError('Second toast');
ToastService().showWarning('Third toast');
ToastService().showInfo('Fourth toast');
```

### Manual Dismiss
Users can tap the X button to manually dismiss a toast:

```dart
// The toast will be dismissed when user taps X
ToastService().showInfo('Tap X to dismiss me');
```

### Dismiss All Toasts
```dart
// Clear all current and queued toasts
ToastService().dismissAll();
```

## Integration Examples

### In BLoC/Cubit
```dart
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  void _onLoginSubmitted(LoginSubmitted event, Emitter<AuthState> emit) async {
    try {
      // Login logic here
      emit(LoginSuccess());
      ToastService().showSuccess('Login successful!');
    } catch (e) {
      emit(LoginFailure(e.toString()));
      ToastService().showError('Login failed. Please try again.');
    }
  }
}
```

### In API Calls
```dart
Future<void> fetchData() async {
  try {
    final data = await apiService.getData();
    // Handle data
    ToastService().showSuccess('Data loaded successfully');
  } catch (e) {
    ToastService().showError('Failed to load data: ${e.toString()}');
  }
}
```

### In Form Validation
```dart
void validateForm() {
  if (emailController.text.isEmpty) {
    ToastService().showWarning('Please enter your email address');
    return;
  }
  
  if (!isValidEmail(emailController.text)) {
    ToastService().showError('Please enter a valid email address');
    return;
  }
  
  // Proceed with form submission
  ToastService().showSuccess('Form submitted successfully!');
}
```

## Customization

### Colors
The toast colors are defined in `lib/core/constants/color.dart`:

```dart
class AppColors {
  static const Color success = Color(0xFF4CAF50);
  static const Color error = Color(0xFFF44336);
  static const Color warning = Color(0xFFFF9800);
  static const Color primary = Color(0xFF5F259E); // Used for info toasts
}
```

### Styling
The toast styling is defined in `lib/presentation/widgets/custom_toast.dart`. You can modify:
- Border radius
- Padding and margins
- Shadow effects
- Icon sizes
- Text styles

### Animation Duration
The animation durations are set in the `CustomToast` widget:
- Slide animation: 300ms
- Fade animation: 200ms
- Default display duration: 3 seconds

## Best Practices

1. **Keep messages concise** - Toasts should be brief and to the point
2. **Use appropriate types** - Match the toast type to the message content
3. **Don't overuse** - Too many toasts can be annoying
4. **Provide context** - Make sure the message is clear and actionable
5. **Test on different screen sizes** - Ensure toasts look good on all devices

## Demo
To see the toast system in action, navigate to `/toast-demo` in your app or use the demo screen:

```dart
Navigator.pushNamed(context, '/toast-demo');
```

## Troubleshooting

### Toast not showing
- Make sure `navigatorKey` is properly set in `MaterialApp`
- Check that the context is valid
- Ensure the toast service is imported correctly

### Multiple toasts not queuing
- The queuing system is automatic
- If toasts are overlapping, check the duration settings
- Make sure you're not calling `dismissAll()` unexpectedly

### Styling issues
- Check that `flutter_screenutil` is properly initialized
- Verify color constants are defined
- Ensure text styles are imported correctly 