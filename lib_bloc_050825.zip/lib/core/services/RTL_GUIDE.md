# 🌐 RTL (Right-to-Left) Support Guide

## 📋 Overview

This guide explains how to implement and use RTL (Right-to-Left) support in the Pipze app. The app now fully supports RTL languages like Arabic with automatic layout adaptation.

## 🎯 Features

### ✅ **Automatic RTL Detection**
- Automatically detects RTL languages (Arabic)
- Switches text direction automatically
- Adapts UI layout for RTL

### ✅ **RTL-Aware Components**
- Text fields with proper text alignment
- Buttons with correct icon positioning
- Lists with proper leading/trailing positioning
- Cards with RTL-aware margins
- Icons that flip directionally

### ✅ **Theme Integration**
- RTL-aware input decoration
- Proper text alignment in all components
- Consistent spacing and padding

## 🛠️ How to Use RTL Helper

### **1. Import the RTL Helper**
```dart
import 'package:pipze/core/utils/rtl_helper.dart';
```

### **2. Use RTL-Aware Text Fields**
```dart
// Instead of TextFormField
RTLHelper.rtlTextField(
  controller: emailController,
  labelText: "Email",
  keyboardType: TextInputType.emailAddress,
  validator: (value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    return null;
  },
)
```

### **3. Use RTL-Aware Buttons**
```dart
// Instead of ElevatedButton
RTLHelper.rtlButton(
  text: "Login",
  onPressed: () => handleLogin(),
  icon: Icon(Icons.login),
)
```

### **4. Use RTL-Aware List Tiles**
```dart
// Instead of ListTile
RTLHelper.rtlListTile(
  title: "Settings",
  subtitle: "Configure your preferences",
  leading: Icon(Icons.settings),
  onTap: () => navigateToSettings(),
)
```

### **5. Use RTL-Aware Cards**
```dart
// Instead of Card
RTLHelper.rtlCard(
  child: YourContent(),
  margin: EdgeInsets.all(16),
)
```

### **6. Use RTL-Aware Icons**
```dart
// Instead of Icon
RTLHelper.rtlIcon(
  Icons.arrow_back,
  color: Colors.black,
  size: 24,
)
```

### **7. Use RTL-Aware Rows**
```dart
// Instead of Row
RTLHelper.rtlRow(
  children: [
    Icon(Icons.star),
    Text("Rating"),
    Text("5.0"),
  ],
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
)
```

## 📐 Layout Utilities

### **RTL-Aware Padding**
```dart
EdgeInsets padding = RTLHelper.getRTLPadding(
  left: 16,
  right: 8,
  top: 12,
  bottom: 12,
);
```

### **RTL-Aware Margin**
```dart
EdgeInsets margin = RTLHelper.getRTLMargin(
  left: 16,
  right: 8,
  top: 12,
  bottom: 12,
);
```

### **RTL-Aware Alignment**
```dart
Alignment alignment = RTLHelper.getRTLAlignment(Alignment.centerLeft);
```

### **RTL-Aware Border Radius**
```dart
BorderRadius radius = RTLHelper.getRTLBorderRadius(
  topLeft: 12,
  topRight: 8,
  bottomLeft: 8,
  bottomRight: 12,
);
```

## 🎨 Theme Integration

### **RTL-Aware Input Decoration**
The app theme automatically provides RTL-aware input decoration:

```dart
// Automatically applied in theme
inputDecorationTheme: InputDecorationTheme(
  contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
  alignLabelWithHint: true,
  floatingLabelAlignment: isRTL 
      ? FloatingLabelAlignment.start 
      : FloatingLabelAlignment.start,
)
```

### **RTL-Aware App Bar**
```dart
appBarTheme: AppBarTheme(
  centerTitle: true,
  titleTextStyle: TextStyle(
    color: Colors.white,
    fontSize: 18.sp,
    fontWeight: FontWeight.w600,
  ),
)
```

## 🔄 Automatic Icon Flipping

The RTL helper automatically flips directional icons:

- `Icons.arrow_back` ↔ `Icons.arrow_forward`
- `Icons.arrow_back_ios` ↔ `Icons.arrow_forward_ios`
- `Icons.keyboard_arrow_left` ↔ `Icons.keyboard_arrow_right`

## 📱 Testing RTL

### **1. Switch to Arabic**
1. Open the app
2. Navigate to trading main screen
3. Open drawer (hamburger menu)
4. Tap "Language"
5. Select "العربية" (Arabic)

### **2. Verify RTL Layout**
- Text should align to the right
- Icons should be on the opposite side
- Text fields should have right-aligned text
- Buttons should have proper icon positioning
- Lists should have leading/trailing swapped

## 🚀 Best Practices

### **1. Always Use RTL Helper**
```dart
// ✅ Good
RTLHelper.rtlTextField(controller: controller, labelText: "Email")

// ❌ Bad
TextFormField(controller: controller, decoration: InputDecoration(labelText: "Email"))
```

### **2. Use RTL-Aware Alignment**
```dart
// ✅ Good
alignment: RTLHelper.getRTLAlignment(Alignment.centerRight)

// ❌ Bad
alignment: Alignment.centerRight
```

### **3. Use RTL-Aware Padding/Margin**
```dart
// ✅ Good
padding: RTLHelper.getRTLPadding(left: 16, right: 8)

// ❌ Bad
padding: EdgeInsets.only(left: 16, right: 8)
```

### **4. Test Both Directions**
Always test your UI in both LTR and RTL modes:
- English (LTR)
- Arabic (RTL)

## 🔧 Custom RTL Components

### **Creating Custom RTL Widgets**
```dart
class RTLWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RTLHelper.rtlContainer(
      padding: RTLHelper.getRTLPadding(left: 16, right: 8),
      child: RTLHelper.rtlRow(
        children: [
          RTLHelper.rtlIcon(Icons.star),
          Text("Rating"),
        ],
      ),
    );
  }
}
```

## 📋 Checklist for RTL Implementation

- [ ] Use `RTLHelper.rtlTextField()` for text inputs
- [ ] Use `RTLHelper.rtlButton()` for buttons
- [ ] Use `RTLHelper.rtlListTile()` for list items
- [ ] Use `RTLHelper.rtlIcon()` for icons
- [ ] Use `RTLHelper.rtlRow()` for horizontal layouts
- [ ] Use `RTLHelper.getRTLPadding()` for padding
- [ ] Use `RTLHelper.getRTLMargin()` for margins
- [ ] Use `RTLHelper.getRTLAlignment()` for alignment
- [ ] Test in both LTR and RTL modes
- [ ] Verify text alignment is correct
- [ ] Verify icon positioning is correct
- [ ] Verify layout flow is natural

## 🎉 Result

With proper RTL implementation, your app will:
- ✅ Automatically adapt to RTL languages
- ✅ Provide natural reading flow for Arabic users
- ✅ Maintain consistent design across languages
- ✅ Offer better user experience for RTL users

---

**Remember**: Always test your RTL implementation with Arabic language to ensure the layout flows naturally from right to left! 🌐 