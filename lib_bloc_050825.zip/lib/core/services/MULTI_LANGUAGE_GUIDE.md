# 🌍 Multi-Language System Guide

## 📋 Overview

This comprehensive guide explains how to use the multi-language system in the Pipze app. The system now supports **6 languages**: English, Spanish, Arabic, Turkish, French, and German, with full RTL (Right-to-Left) support for Arabic.

## 🏗️ System Architecture

### 📁 File Structure
```
lib/core/constants/languages/
├── en.json          # English (default)
├── es.json          # Spanish
├── ar.json          # Arabic (RTL)
├── tr.json          # Turkish
├── fr.json          # French
└── de.json          # German
```

### 🔧 Core Components
- **LanguageService**: Manages language switching and translations
- **ListenableBuilder**: Makes UI reactive to language changes
- **Directionality**: Handles RTL/LTR text direction
- **JSON Files**: Flat structure for easy maintenance

## 🚀 Supported Languages

| Language | Code | Direction | Status |
|----------|------|-----------|--------|
| English | `en` | LTR | ✅ Complete |
| Spanish | `es` | LTR | ✅ Complete |
| Arabic | `ar` | RTL | ✅ Complete |
| Turkish | `tr` | LTR | ✅ Complete |
| French | `fr` | LTR | 🔄 Partial |
| German | `de` | LTR | 🔄 Partial |

## 📱 Usage Examples

### 1. Basic Translation
```dart
import 'package:pipze/core/services/language_service.dart';

// Simple translation
Text("welcome_title".tr)

// With extension
String message = "login_button".tr;
```

### 2. Translation with Arguments
```dart
// For dynamic values
Text("validation_password_min_length".trArgs({
  'min': '8',
}))

// Result: "Password must be at least 8 characters"
```

### 3. Translation with Fallback
```dart
// If key doesn't exist, use fallback
String message = "some_key".trf("Default message");
```

### 4. Change Language
```dart
// Change to Arabic (RTL)
await languageService.changeLanguage('ar');

// Change to Turkish
await languageService.changeLanguage('tr');

// Change to English
await languageService.changeLanguage('en');
```

## 🎨 RTL Support (Arabic)

### Automatic RTL Detection
The system automatically detects RTL languages and applies proper text direction:

```dart
// In main.dart
Directionality(
  textDirection: languageService.isRTL ? TextDirection.rtl : TextDirection.ltr,
  child: MaterialApp(...),
)
```

### RTL Best Practices
1. **Text Alignment**: Use `TextAlign.start` instead of `TextAlign.left`
2. **Padding/Margin**: Use `EdgeInsetsDirectional` instead of `EdgeInsets`
3. **Icons**: Consider mirroring icons for RTL
4. **Numbers**: Arabic numbers are automatically handled

## 📝 Adding New Languages

### Step 1: Create JSON File
Create `lib/core/constants/languages/ja.json` for Japanese:

```json
{
  "app_name": "Pipze",
  "welcome_title": "こんにちは、ようこそ！👋",
  "login_title": "ログイン",
  "login_email": "メールアドレス",
  "login_password": "パスワード",
  "login_button": "ログイン"
}
```

### Step 2: Add to Language Service
Update `lib/core/services/language_service.dart`:

```dart
static const Map<String, String> supportedLanguages = {
  'en': 'English',
  'es': 'Español',
  'ar': 'العربية',
  'tr': 'Türkçe',
  'ja': '日本語', // Add this
};
```

### Step 3: Add Language Names
Add language names to all JSON files:

```json
{
  "settings_language_japanese": "日本語"
}
```

### Step 4: Test RTL Support
If the language is RTL (like Hebrew), add to RTL check:

```dart
bool get isRTL {
  return _currentLanguage == 'ar' || _currentLanguage == 'he' || _currentLanguage == 'fa';
}
```

## 🔧 Implementation Examples

### Complete Screen Example
```dart
import 'package:flutter/material.dart';
import 'package:pipze/core/services/language_service.dart';

class ExampleScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: languageService,
      builder: (context, child) {
        return Scaffold(
          appBar: AppBar(
            title: Text("example_title".tr),
          ),
          body: Column(
            children: [
              Text("example_welcome".tr),
              TextFormField(
                decoration: InputDecoration(
                  labelText: "example_email".tr,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "validation_email_required".tr;
                  }
                  return null;
                },
              ),
              ElevatedButton(
                onPressed: () {
                  ContextToastService.showSuccess(
                    context,
                    "toast_example_success".tr,
                  );
                },
                child: Text("example_button".tr),
              ),
            ],
          ),
        );
      },
    );
  }
}
```

### Form Validation Example
```dart
TextFormField(
  decoration: InputDecoration(
    labelText: "login_email".tr,
    hintText: "login_email_hint".tr,
  ),
  validator: (value) {
    if (value == null || value.isEmpty) {
      return 'validation_email_required'.tr;
    }
    if (!_validateEmail(value)) {
      return 'validation_email_invalid'.tr;
    }
    return null;
  },
)
```

### Toast Messages Example
```dart
// Success toast
ContextToastService.showSuccess(
  context,
  'toast_login_success'.tr,
  duration: const Duration(seconds: 2),
);

// Error toast
ContextToastService.showError(
  context,
  'toast_network_error'.tr,
  duration: const Duration(seconds: 3),
);

// Info toast
ContextToastService.showInfo(
  context,
  'toast_coming_soon'.tr,
  duration: const Duration(seconds: 2),
);
```

## 🎯 Key Features

### ✅ What's Working
- **6 Languages**: English, Spanish, Arabic, Turkish, French, German
- **RTL Support**: Full Arabic RTL support
- **Real-time Updates**: UI updates immediately when language changes
- **Persistent Storage**: Language preference is saved
- **Fallback System**: Graceful handling of missing translations
- **Argument Interpolation**: Dynamic values in translations
- **Flat JSON Structure**: Easy to maintain and extend

### 🔄 What's Partially Complete
- **French**: Basic translations (needs completion)
- **German**: Basic translations (needs completion)

### 🚧 Future Enhancements
- **Pluralization**: Support for plural forms
- **Gender Support**: Gender-specific translations
- **Context Support**: Context-aware translations
- **Online Updates**: Remote translation updates
- **Auto-detection**: Device language auto-detection

## 🧪 Testing

### Language Switching Test
1. Open the app
2. Navigate to login screen
3. Tap orange "Test Language Switch" button
4. Select different languages
5. Verify text changes immediately
6. Test RTL layout with Arabic

### RTL Testing Checklist
- [ ] Text flows right-to-left
- [ ] Icons are properly positioned
- [ ] Numbers display correctly
- [ ] Input fields work properly
- [ ] Navigation works correctly

## 📊 Performance Tips

1. **Caching**: Translations are cached in memory
2. **Lazy Loading**: Languages load only when needed
3. **Minimal JSON**: Keep JSON files focused
4. **Efficient Updates**: Only affected widgets rebuild

## 🔍 Troubleshooting

### Common Issues

#### 1. Language Not Changing
```dart
// Check if language is supported
if (languageService.isLanguageSupported('ja')) {
  await languageService.changeLanguage('ja');
}
```

#### 2. RTL Not Working
```dart
// Ensure Directionality is properly set
Directionality(
  textDirection: languageService.isRTL ? TextDirection.rtl : TextDirection.ltr,
  child: YourWidget(),
)
```

#### 3. Missing Translations
```dart
// Use fallback
Text("missing_key".trf("Default text"))

// Check console for missing keys
print('Translation: ${"key".tr}');
```

#### 4. Arguments Not Working
```dart
// Check placeholder syntax
"validation_password_min_length": "Password must be at least {min} characters"

// Use trArgs method
"validation_password_min_length".trArgs({'min': '8'})
```

## 📚 Best Practices

### 1. Key Naming
- Use descriptive, hierarchical names
- Keep keys short but clear
- Use underscores to separate sections
- Be consistent across the app

### 2. Organization
- Group related keys together
- Use prefixes for different sections:
  - `login_*` for login screen
  - `validation_*` for validation messages
  - `toast_*` for toast messages
  - `error_*` for error messages

### 3. RTL Considerations
- Use `TextAlign.start` instead of `TextAlign.left`
- Use `EdgeInsetsDirectional` for padding/margin
- Test with Arabic language
- Consider icon mirroring

### 4. Testing
- Test all languages when adding new features
- Verify argument interpolation works
- Check for missing translations
- Test RTL layout thoroughly

## 🎉 Quick Start

### For New Developers
1. **Import the service**:
   ```dart
   import 'package:pipze/core/services/language_service.dart';
   ```

2. **Wrap your screen**:
   ```dart
   ListenableBuilder(
     listenable: languageService,
     builder: (context, child) {
       return YourScreen();
     },
   )
   ```

3. **Use translations**:
   ```dart
   Text("your_key".tr)
   ```

4. **Test language switching**:
   ```dart
   await languageService.changeLanguage('ar');
   ```

## 📞 Support

For questions or issues:
1. Check this guide first
2. Verify JSON syntax
3. Test with different languages
4. Check console for error messages
5. Test RTL layout with Arabic

---

**Happy Internationalization! 🌍✨**

This system provides a solid foundation for multi-language support that's easy to use, maintain, and extend. The addition of Arabic and Turkish with full RTL support makes the app truly global-ready! 