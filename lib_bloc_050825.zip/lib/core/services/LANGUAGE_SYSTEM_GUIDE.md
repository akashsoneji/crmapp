# Flutter Language System Guide

## Overview
This guide explains how to use the new flat JSON-based multi-language system in the Pipze app. The system is designed to be simple, efficient, and easy to maintain.

## Structure

### JSON Files
- **Location**: `lib/core/constants/languages/`
- **Files**: `en.json`, `es.json`, etc.
- **Structure**: Flat key-value pairs (no nested objects)

### Key Naming Convention
Keys follow a simple pattern: `section_element_type`
- `login_title` - Login section, title element
- `validation_email_required` - Validation section, email field, required type
- `toast_login_success` - Toast section, login action, success type

## Usage

### 1. Basic Translation
```dart
import 'package:pipze/core/services/language_service.dart';

// Simple translation
Text("login_title".tr)

// With extension
String message = "welcome_title".tr;
```

### 2. Translation with Arguments
```dart
// For dynamic values
Text("validation_password_min_length".trArgs({
  'min': '8',
}))

// Result: "Password must be at least 8 characters"
```

### 3. Translation with Fallback
```dart
// If key doesn't exist, use fallback
String message = "some_key".trf("Default message");
```

### 4. Change Language
```dart
// Change to Spanish
await languageService.changeLanguage('es');

// Change to English
await languageService.changeLanguage('en');
```

## Adding New Languages

### 1. Create JSON File
Create `lib/core/constants/languages/fr.json` for French:

```json
{
  "app_name": "Pipze",
  "welcome_title": "Bonjour, Bienvenue! 👋",
  "login_title": "Connexion",
  "login_email": "E-mail",
  "login_password": "Mot de passe",
  "login_button": "Se connecter"
}
```

### 2. Add to Supported Languages
Update `lib/core/services/language_service.dart`:

```dart
static const Map<String, String> supportedLanguages = {
  'en': 'English',
  'es': 'Español',
  'fr': 'Français', // Add this
};
```

### 3. Update pubspec.yaml
Make sure the language files are included in assets:

```yaml
flutter:
  assets:
    - lib/core/constants/languages/
```

## Adding New Translation Keys

### 1. Add to All Language Files
Add the same key to all JSON files:

**en.json:**
```json
{
  "new_feature_title": "New Feature"
}
```

**es.json:**
```json
{
  "new_feature_title": "Nueva Función"
}
```

### 2. Use in Code
```dart
Text("new_feature_title".tr)
```

## Best Practices

### 1. Key Naming
- Use descriptive, hierarchical names
- Keep keys short but clear
- Use underscores to separate sections
- Be consistent across the app

### 2. Organization
- Group related keys together in JSON
- Use prefixes for different sections:
  - `login_*` for login screen
  - `validation_*` for validation messages
  - `toast_*` for toast messages
  - `error_*` for error messages

### 3. Arguments
- Use `{placeholder}` syntax for dynamic values
- Keep placeholders simple and descriptive
- Document expected arguments

### 4. Testing
- Test all languages when adding new features
- Verify argument interpolation works
- Check for missing translations

## Common Patterns

### Form Validation
```dart
validator: (value) {
  if (value == null || value.isEmpty) {
    return 'validation_email_required'.tr;
  }
  if (!_validateEmail(value)) {
    return 'validation_email_invalid'.tr;
  }
  return null;
}
```

### Toast Messages
```dart
ContextToastService.showSuccess(
  context,
  'toast_login_success'.tr,
  duration: const Duration(seconds: 2),
);
```

### Navigation
```dart
AppBar(
  title: Text("dashboard_title".tr),
)
```

## Troubleshooting

### 1. Key Not Found
- Check if key exists in all language files
- Verify spelling and case
- Use `trf()` for fallback values

### 2. Arguments Not Working
- Check placeholder syntax `{placeholder}`
- Verify argument names match
- Use `trArgs()` method

### 3. Language Not Changing
- Check if language code is supported
- Verify JSON file exists
- Restart app after adding new language

## Example Implementation

### Complete Screen Example
```dart
import 'package:flutter/material.dart';
import 'package:pipze/core/services/language_service.dart';

class ExampleScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("example_title".tr),
      ),
      body: Column(
        children: [
          Text("example_welcome".tr),
          TextFormField(
            decoration: InputDecoration(
              labelText: "example_email".tr,
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return "validation_email_required".tr;
              }
              return null;
            },
          ),
          ElevatedButton(
            onPressed: () {
              ContextToastService.showSuccess(
                context,
                "toast_example_success".tr,
              );
            },
            child: Text("example_button".tr),
          ),
        ],
      ),
    );
  }
}
```

## Migration from Old System

If migrating from the old nested JSON structure:

1. **Flatten the structure**: Convert `auth.login.title` to `login_title`
2. **Update all references**: Change all `.tr` calls in code
3. **Test thoroughly**: Verify all translations work
4. **Update documentation**: Keep this guide updated

## Performance Tips

- The language service loads JSON files once and caches them
- Use `ListenableBuilder` for reactive UI updates
- Avoid calling `tr()` in build methods unnecessarily
- Consider lazy loading for large translation files

## Support

For questions or issues:
1. Check this guide first
2. Verify JSON syntax
3. Test with different languages
4. Check console for error messages 