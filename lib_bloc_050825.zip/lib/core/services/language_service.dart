import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LanguageService extends ChangeNotifier {
  static const String _languageKey = 'selected_language';
  static const String _defaultLanguage = 'en';

  Map<String, dynamic> _translations = {};
  String _currentLanguage = _defaultLanguage;

  // Supported languages
  static const Map<String, String> supportedLanguages = {
    'en': 'English',
    'es': 'Español',
    'fr': 'Français',
    'de': 'Deutsch',
    'pt': 'Português',
    'it': 'Italiano',
    'ru': 'Русский',
    'zh': '中文',
    'ja': '日本語',
    'ko': '한국어',
    'ar': 'العربية',
    'tr': 'Türkçe',
    'hi': 'हिन्दी',
  };

  LanguageService() {
    _loadSavedLanguage();
  }

  String get currentLanguage => _currentLanguage;
  Map<String, dynamic> get translations => _translations;

  // Get translation by key (e.g., "login_title")
  String tr(String key, {Map<String, dynamic>? args}) {
    try {
      if (_translations.containsKey(key)) {
        String result = _translations[key];

        // Replace arguments if provided
        if (args != null) {
          args.forEach((argKey, val) {
            result = result.replaceAll('{$argKey}', val.toString());
          });
        }

        return result;
      }

      // Return the key if translation not found
      return key;
    } catch (e) {
      print('Translation error for key: $key - $e');
      return key;
    }
  }

  // Get translation with fallback
  String trf(String key, {String fallback = '', Map<String, dynamic>? args}) {
    final translation = tr(key, args: args);
    return translation != key ? translation : fallback;
  }

  // Change language
  Future<void> changeLanguage(String languageCode) async {
    if (!supportedLanguages.containsKey(languageCode)) {
      print('Unsupported language: $languageCode');
      return;
    }

    try {
      await _loadTranslations(languageCode);
      _currentLanguage = languageCode;
      await _saveLanguage(languageCode);
      notifyListeners();
    } catch (e) {
      print('Error changing language: $e');
    }
  }

  // Load saved language from preferences
  Future<void> _loadSavedLanguage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedLanguage = prefs.getString(_languageKey) ?? _defaultLanguage;
      await changeLanguage(savedLanguage);
    } catch (e) {
      print('Error loading saved language: $e');
      await _loadTranslations(_defaultLanguage);
    }
  }

  // Save language to preferences
  Future<void> _saveLanguage(String languageCode) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_languageKey, languageCode);
    } catch (e) {
      print('Error saving language: $e');
    }
  }

  // Load translations from JSON file
  Future<void> _loadTranslations(String languageCode) async {
    try {
      final jsonString = await rootBundle.loadString(
        'lib/core/constants/languages/$languageCode.json',
      );
      _translations = json.decode(jsonString);
    } catch (e) {
      print('Error loading translations for $languageCode: $e');
      // Fallback to English
      if (languageCode != _defaultLanguage) {
        await _loadTranslations(_defaultLanguage);
      }
    }
  }

  // Get current language name
  String get currentLanguageName {
    return supportedLanguages[_currentLanguage] ?? 'Unknown';
  }

  // Check if language is RTL (Right-to-Left)
  bool get isRTL {
    return _currentLanguage == 'ar' || _currentLanguage == 'he';
  }

  // Get locale for current language
  Locale get locale {
    return Locale(_currentLanguage);
  }

  // Get all supported languages
  Map<String, String> get allLanguages => supportedLanguages;

  // Check if a language is supported
  bool isLanguageSupported(String languageCode) {
    return supportedLanguages.containsKey(languageCode);
  }

  // Get device language and set it if supported
  Future<void> setDeviceLanguage() async {
    try {
      final deviceLocale = WidgetsBinding.instance.window.locale;
      final deviceLanguage = deviceLocale.languageCode;

      if (isLanguageSupported(deviceLanguage)) {
        await changeLanguage(deviceLanguage);
      } else {
        // Try to find a close match (e.g., 'en-US' -> 'en')
        final baseLanguage = deviceLanguage.split('-')[0];
        if (isLanguageSupported(baseLanguage)) {
          await changeLanguage(baseLanguage);
        }
      }
    } catch (e) {
      print('Error setting device language: $e');
    }
  }
}

// Global instance
final languageService = LanguageService();

// Extension for easy access to translations
extension TranslationExtension on String {
  String get tr => languageService.tr(this);

  String trArgs(Map<String, dynamic> args) =>
      languageService.tr(this, args: args);

  String trf(String fallback) => languageService.trf(this, fallback: fallback);
}
