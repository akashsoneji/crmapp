# WebView Performance Guide

## Frame Rate Warning Explanation

The console warning `setRequestedFrameRate frameRate=-4.0` is a common WebView warning that appears when:

1. **WebView Performance Optimization**: The WebView engine automatically adjusts frame rates for performance
2. **Background Processing**: When WebView content is not actively visible or in focus
3. **System Resource Management**: Android's WebView implementation optimizes rendering

## Impact on App

✅ **This warning does NOT harm your app's functionality**
✅ **Your app continues to work normally**
✅ **It's just a console log message, not an error**

## Solutions Implemented

### 1. Optimized WebView Configuration

We've implemented several optimizations to reduce these warnings:

- **Disabled zoom controls** to reduce rendering overhead
- **Set background color** to prevent flashing
- **Disabled unnecessary features** like context menus and scroll gestures
- **Added proper error handling** for better user experience

### 2. Performance Improvements

- **Navigation delegation** with proper callbacks
- **Resource error handling** with retry functionality
- **Loading states** with visual feedback
- **External URL prevention** for security

### 3. Code Structure

The optimizations are implemented in:

- `lib/presentation/widgets/trading_view_webview.dart` - Main WebView widget
- `lib/presentation/widgets/trading_view_advanced_charts.dart` - Advanced charts
- `lib/presentation/widgets/tradingview_charting_library.dart` - Charting library
- `lib/core/utils/webview_utils.dart` - Utility functions

## Best Practices

1. **Always handle loading states** - Show loading indicators
2. **Implement error handling** - Provide retry options
3. **Optimize WebView settings** - Disable unnecessary features
4. **Monitor performance** - Check for memory leaks
5. **Test on different devices** - Ensure compatibility

## Additional Recommendations

If you still see the warning frequently:

1. **Update WebView packages** to latest versions
2. **Consider using native charts** for better performance
3. **Implement lazy loading** for multiple charts
4. **Monitor memory usage** during chart rendering

## Testing

To verify the optimizations work:

1. Run the app in debug mode
2. Navigate to chart screens
3. Check console for reduced warnings
4. Test on different Android versions
5. Verify chart functionality remains intact 