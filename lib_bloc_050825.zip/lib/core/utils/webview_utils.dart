import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebViewUtils {
  /// Creates optimized NavigationDelegate with error handling
  static NavigationDelegate getOptimizedNavigationDelegate({
    required VoidCallback onPageStarted,
    required VoidCallback onPageFinished,
    required VoidCallback onError,
  }) {
    return NavigationDelegate(
      onPageStarted: (String url) {
        onPageStarted();
      },
      onPageFinished: (String url) {
        onPageFinished();
      },
      onWebResourceError: (WebResourceError error) {
        onError();
      },
      // Prevent navigation to external URLs
      onNavigationRequest: (NavigationRequest request) {
        // Only allow navigation to the original URL or relative paths
        if (request.url.startsWith('http') &&
            !request.url.contains('my.pipze.com')) {
          return NavigationDecision.prevent;
        }
        return NavigationDecision.navigate;
      },
    );
  }

  /// Creates a WebViewController with optimized settings
  static WebViewController createOptimizedController({
    required String url,
    required NavigationDelegate navigationDelegate,
  }) {
    return WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..enableZoom(false)
      ..setNavigationDelegate(navigationDelegate)
      ..loadRequest(Uri.parse(url));
  }
}
