import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/constants/color.dart';
import '../../../core/constants/text_styles.dart';
import '../../../core/services/language_service.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: languageService,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: AppColors.backgroundLight,
          appBar: AppBar(
            title: Text("privacy_policy_title".tr),
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            elevation: 0,
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSectionTitle("privacy_policy_introduction".tr),
                  SizedBox(height: 16.h),
                  _buildParagraph("privacy_policy_intro_text".tr),
                  SizedBox(height: 24.h),
                  _buildSectionTitle("privacy_policy_data_collection".tr),
                  SizedBox(height: 16.h),
                  _buildParagraph("privacy_policy_data_collection_text".tr),
                  SizedBox(height: 16.h),
                  _buildBulletPoint("privacy_policy_bullet_1".tr),
                  _buildBulletPoint("privacy_policy_bullet_2".tr),
                  _buildBulletPoint("privacy_policy_bullet_3".tr),
                  SizedBox(height: 24.h),
                  _buildSectionTitle("privacy_policy_data_usage".tr),
                  SizedBox(height: 16.h),
                  _buildParagraph("privacy_policy_data_usage_text".tr),
                  SizedBox(height: 24.h),
                  _buildSectionTitle("privacy_policy_data_protection".tr),
                  SizedBox(height: 16.h),
                  _buildParagraph("privacy_policy_data_protection_text".tr),
                  SizedBox(height: 24.h),
                  _buildSectionTitle("privacy_policy_contact".tr),
                  SizedBox(height: 16.h),
                  _buildParagraph("privacy_policy_contact_text".tr),
                  SizedBox(height: 32.h),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
      child: Row(
        children: [
          // Back button container
          Container(
            height: 40.h,
            width: 40.w,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
              iconSize: 17.h,
              padding: EdgeInsets.only(left: 5.w),
            ),
          ),

          SizedBox(width: 16.w),

          // Progress bar row
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                _progressBar(active: true),
                SizedBox(width: 8.w),
                _progressBar(active: true),
                SizedBox(width: 8.w),
                _progressBar(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _progressBar({bool active = false}) {
    return Container(
      width: 60.w,
      height: 4.h,
      decoration: BoxDecoration(
        color: active ? AppColors.primary : AppColors.border,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }

  Widget _buildContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildParagraph(
          "At Pipze, your privacy and data security are our top priorities. "
          "This Privacy Policy details how we collect, use, protect, and share "
          "your personal and financial information when you use our trading services "
          "(stocks, crypto, forex, or commodities). We are fully compliant with "
          "legal and regulatory standards including SEBI, RBI, GDPR, and CCPA. "
          "We never sell your data and use advanced encryption and security protocols "
          "to keep your information safe. Please review this policy to understand "
          "your rights and how we protect your trading journey.",
        ),
        SizedBox(height: 24.h),
        _buildSectionTitle("Legal Basis for Processing"),
        SizedBox(height: 12.h),
        _buildBulletPoint("Your consent"),
        _buildBulletPoint(
          "The need to perform a contract (e.g., open and manage your trading account)",
        ),
        _buildBulletPoint("Legal obligations (e.g., SEBI, RBI, or tax laws)"),
        _buildBulletPoint(
          "Our legitimate business interests (e.g., platform improvement, fraud prevention)",
        ),
        SizedBox(height: 24.h),
        _buildSectionTitle("Data Security"),
        SizedBox(height: 12.h),
        _buildParagraph(
          "We implement industry-standard security measures to protect your information:",
        ),
        SizedBox(height: 8.h),
        _buildBulletPoint("End-to-end encryption"),
        _buildBulletPoint("Secure socket layer (SSL) technology"),
        _buildBulletPoint("Role-based access controls"),
        _buildBulletPoint("Regular audits and security assessments"),
      ],
    );
  }

  Widget _buildParagraph(String text) {
    return Text(
      text,
      style: TextStyle(fontSize: 14.sp, color: AppColors.textGrey, height: 1.5),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: AppTextStyles.heading.copyWith(
        fontSize: 18.sp,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildBulletPoint(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.only(top: 8.h, right: 12.w),
            width: 4.w,
            height: 4.w,
            decoration: BoxDecoration(
              color: AppColors.primary,
              shape: BoxShape.circle,
            ),
          ),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 14.sp,
                color: AppColors.textGrey,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
