import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/constants/color.dart';
import '../../../core/services/language_service.dart';

class LanguageSelectorScreen extends StatelessWidget {
  const LanguageSelectorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('settings_language_title'.tr),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16.w),
        itemCount: languageService.allLanguages.length,
        itemBuilder: (context, index) {
          final languageCode = languageService.allLanguages.keys.elementAt(
            index,
          );
          final languageName = languageService.allLanguages.values.elementAt(
            index,
          );
          final isSelected = languageService.currentLanguage == languageCode;

          return Card(
            margin: EdgeInsets.only(bottom: 8.h),
            child: ListTile(
              title: Text(
                languageName,
                style: TextStyle(
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  color: isSelected ? AppColors.primary : Colors.black,
                ),
              ),
              trailing:
                  isSelected
                      ? Icon(Icons.check_circle, color: AppColors.primary)
                      : null,
              onTap: () async {
                await languageService.changeLanguage(languageCode);
                if (context.mounted) {
                  Navigator.pop(context);
                }
              },
            ),
          );
        },
      ),
    );
  }
}
