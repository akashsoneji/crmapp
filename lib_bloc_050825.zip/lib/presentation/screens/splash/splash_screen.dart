import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:pipze/core/services/secure_storage_service.dart';
import 'package:pipze/presentation/blocs/auth/auth_bloc.dart';
import 'package:pipze/presentation/blocs/auth/auth_event.dart';

import '../getstart/get_started_screen.dart';
import '../trading/trading_main_screen.dart';
import '../../../core/services/toast_service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(seconds: 3), () {
      _checkAuthAndNavigate();
    });
  }

  Future<void> _checkAuthAndNavigate() async {
    try {
      // Check if user is logged in
      final isLoggedIn = await SecureStorageService.isUserLoggedIn();
      print('SplashScreen: User login status: $isLoggedIn');

      if (isLoggedIn) {
        // User is logged in, trigger auth check in bloc
        context.read<AuthBloc>().add(CheckAuthStatus());

        // Navigate to trading screen
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const TradingMainScreen()),
          );
        }
      } else {
        // User is not logged in, navigate to get started screen
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const GetStartedScreen()),
          );
        }
      }
    } catch (e) {
      print('SplashScreen: Error checking auth status: $e');
      // On error, navigate to get started screen
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const GetStartedScreen()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF692EAF),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: AvatarGlow(
              startDelay: const Duration(milliseconds: 1000),
              glowColor: Colors.white,
              glowShape: BoxShape.circle,
              animate: true,
              curve: Curves.fastOutSlowIn,
              child: Container(
                height: 250,
                width: 250,
                child: SvgPicture.asset(
                  'assets/image/splash_logo.svg',
                  height: 60,
                  width: 90,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
