import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:pipze/presentation/screens/getstart/get_started_login_option_screen.dart';
import 'package:pipze/presentation/screens/onboarding/create_account_screen.dart';
import 'package:pipze/presentation/screens/onboarding/privacy_policy_screen.dart';

import '../../../core/constants/color.dart';
import '../../../core/services/language_service.dart';

class GetStartedScreen extends StatelessWidget {
  const GetStartedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        // maintainBottomViewPadding: true,
        child: ListenableBuilder(
          listenable: languageService,
          builder: (context, child) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 135.h),
                  // Image.asset("assets/images/pipze_logo.png", height: 100),
                  Center(
                    child: SvgPicture.asset(
                      'assets/svg/logo.svg',
                      height: 130.h,
                      width: 130.w,
                      semanticsLabel: 'Pipze Logo',
                    ),
                  ),
                  SizedBox(height: 50.h),
                  Text(
                    "onboarding_slide1_description".tr,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 50.h),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const GetStartedLoginOptionScreen(),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF692EAF),
                        padding: EdgeInsets.all(14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            12,
                          ), // button's shape
                        ),
                      ),
                      child: Text(
                        "onboarding_get_started".tr,
                        style: TextStyle(color: AppColors.secondary),
                      ),
                    ),
                  ),
                  SizedBox(height: 15.h),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const CreateAccountScreen(),
                          ),
                        );
                      },
                      style: OutlinedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            12,
                          ), // button's shape
                        ),
                        padding: EdgeInsets.all(14),
                      ),
                      child: Text("register_title".tr),
                    ),
                  ),
                  const Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Text.rich(
                      TextSpan(
                        style: TextStyle(color: AppColors.textGrey),
                        text: "${"register_terms".tr}\n",
                        children: [
                          TextSpan(
                            text: "Terms & Condition",
                            style: TextStyle(
                              decoration: TextDecoration.underline,
                              color: AppColors.primary,
                              fontWeight: FontWeight.w500,
                            ),
                            recognizer:
                                TapGestureRecognizer()
                                  ..onTap = () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder:
                                            (context) => PrivacyPolicyScreen(),
                                      ),
                                    );
                                  },
                          ),
                          TextSpan(text: " and "),
                          TextSpan(
                            text: "Privacy Policy",
                            style: TextStyle(
                              decoration: TextDecoration.underline,
                              color: AppColors.primary,
                              fontWeight: FontWeight.w500,
                            ),
                            recognizer:
                                TapGestureRecognizer()
                                  ..onTap = () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder:
                                            (context) => PrivacyPolicyScreen(),
                                      ),
                                    );
                                  },
                          ),
                        ],
                      ),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
