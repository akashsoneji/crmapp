import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:pipze/presentation/screens/getstart/login_screen.dart';
import 'package:pipze/presentation/screens/getstart/widgets/social_button.dart';
import 'package:pipze/presentation/screens/onboarding/create_account_screen.dart';
import '../../../core/constants/color.dart';
import '../../../core/services/language_service.dart';

class GetStartedLoginOptionScreen extends StatelessWidget {
  const GetStartedLoginOptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListenableBuilder(
        listenable: languageService,
        builder: (context, child) {
          return Scaffold(
            body: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: constraints.maxHeight,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: IntrinsicHeight(
                        child: Column(
                          children: [
                            SizedBox(height: 135.h),
                            Center(
                              child: SvgPicture.asset(
                                'assets/svg/logo.svg',
                                height: 130.h,
                                width: 130.w,
                                semanticsLabel: 'Pipze Logo',
                              ),
                            ),
                            SizedBox(height: 50.h),
                            Text(
                              "welcome_login_title".tr,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 27.sp,
                                height: 34 / 27,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 10.h),
                            Text(
                              "login_subtitle".tr,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 17.sp,
                                height: 24 / 17,
                                fontWeight: FontWeight.w400,
                                color: AppColors.textGrey,
                              ),
                            ),
                            SizedBox(height: 50.h),
                            SocialButton(
                              label: 'login_google'.tr,
                              icon: 'assets/svg/GoogleLogo.svg',
                              onPressed: () {},
                            ),
                            const SizedBox(height: 12),
                            SocialButton(
                              label: 'login_apple'.tr,
                              icon: 'assets/svg/apple_logo.svg',
                              onPressed: () {},
                            ),
                            const SizedBox(height: 12),
                            SocialButton(
                              label: 'login_email'.tr,
                              icon: 'assets/svg/emailLogo.svg',
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => LoginScreen(),
                                  ),
                                );
                              },
                            ),
                            SizedBox(height: 30.h),
                            const Spacer(),
                            Center(
                              child: TextButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => LoginScreen(),
                                    ),
                                  );
                                },
                                child: Text.rich(
                                  TextSpan(
                                    style: TextStyle(color: AppColors.textGrey),
                                    text: "${"login_no_account".tr} ",
                                    children: [
                                      TextSpan(
                                        text: " ${"login_button".tr}",
                                        style: TextStyle(
                                          decoration: TextDecoration.underline,
                                          color: AppColors.primary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              height: MediaQuery.of(context).padding.bottom,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
