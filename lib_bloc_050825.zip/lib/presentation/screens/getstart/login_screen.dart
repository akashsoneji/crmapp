import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:pipze/core/constants/color.dart';
import 'package:pipze/core/services/toast_service.dart';
import 'package:pipze/core/services/language_service.dart';
import 'package:pipze/core/utils/rtl_helper.dart';
import 'package:pipze/data/repositories/auth_repository.dart';
import 'package:pipze/presentation/blocs/auth/auth_bloc.dart';
import 'package:pipze/presentation/blocs/auth/auth_event.dart';
import 'package:pipze/presentation/blocs/auth/auth_state.dart';
import 'package:pipze/presentation/screens/getstart/widgets/social_button.dart';
import 'package:pipze/presentation/widgets/AppTextField.dart';

import '../onboarding/create_account_screen.dart';
import '../auth/forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool obscureText = true;

  // Validation states
  bool isEmailValid = false;
  bool isPasswordValid = false;

  // Validation methods
  bool _validateEmail(String email) {
    final emailRegex = RegExp(
      r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
    );
    return emailRegex.hasMatch(email);
  }

  bool _validatePassword(String password) {
    return password.length >= 6;
  }

  String? _validatePasswordStrength(String password) {
    if (password.isEmpty) {
      return 'Password is required';
    }
    if (password.length < 6) {
      return 'Password must be at least 6 characters';
    }
    if (!password.contains(RegExp(r'[A-Z]'))) {
      return 'Password must contain at least one uppercase letter';
    }
    if (!password.contains(RegExp(r'[a-z]'))) {
      return 'Password must contain at least one lowercase letter';
    }
    if (!password.contains(RegExp(r'[0-9]'))) {
      return 'Password must contain at least one number';
    }
    return null;
  }

  void _handleLogin() {
    if (_formKey.currentState!.validate()) {
      context.read<AuthBloc>().add(
        LoginRequested(
          email: emailController.text.trim(),
          password: passwordController.text.trim(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is LoginSuccess) {
          // Show success toast and navigate
          ContextToastService.showSuccess(
            context,
            'toast_login_success'.tr,
            duration: const Duration(seconds: 2),
          );

          // Navigate to trading screen
          Future.delayed(const Duration(seconds: 1), () {
            Navigator.pushNamedAndRemoveUntil(
              context,
              '/trading',
              (route) => false,
            );
          });
        } else if (state is AuthError) {
          ContextToastService.showError(
            context,
            state.message,
            duration: const Duration(seconds: 2),
          );
        }
      },
      child: Scaffold(
        body: SafeArea(
          maintainBottomViewPadding: true,
          child: ListenableBuilder(
            listenable: languageService,
            builder: (context, child) {
              return LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: constraints.maxHeight,
                      ),
                      child: IntrinsicHeight(
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 60.h),
                              Text(
                                "welcome_title".tr,
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 40.h),

                              RTLHelper.rtlTextField(
                                controller: emailController,
                                labelText: "register_email".tr,
                                keyboardType: TextInputType.emailAddress,
                                onChanged: (value) {
                                  setState(() {
                                    isEmailValid = _validateEmail(value);
                                  });
                                },
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'validation_email_required'.tr;
                                  }
                                  if (!_validateEmail(value)) {
                                    return 'validation_email_invalid'.tr;
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: 16.h),
                              RTLHelper.rtlTextField(
                                controller: passwordController,
                                labelText: "login_password".tr,
                                obscureText: obscureText,
                                suffixIcon: InkWell(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 14,
                                    ),
                                    child: SvgPicture.asset(
                                      obscureText
                                          ? 'assets/svg/eye-slash.svg'
                                          : "assets/svg/eye_icon.svg",
                                      height: 12.h,
                                      width: 18.w,
                                      color: AppColors.textGrey,
                                    ),
                                  ),
                                  onTap:
                                      () => setState(
                                        () => obscureText = !obscureText,
                                      ),
                                ),
                                onChanged: (value) {
                                  setState(() {
                                    isPasswordValid = _validatePassword(value);
                                  });
                                },
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'validation_password_required'.tr;
                                  }
                                  if (value.length < 6) {
                                    return 'validation_password_min_length'
                                        .trArgs({'min': '6'});
                                  }
                                  return null;
                                },
                              ),
                              Align(
                                alignment: RTLHelper.getRTLAlignment(
                                  Alignment.centerRight,
                                ),
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder:
                                            (context) =>
                                                const ForgotPasswordScreen(),
                                      ),
                                    );
                                  },
                                  child: Text(
                                    "login_forgot_password".tr,
                                    style: TextStyle(
                                      color: AppColors.textPrimary,
                                      fontSize: 13.sp,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 35.h),
                              BlocBuilder<AuthBloc, AuthState>(
                                builder: (context, state) {
                                  final isLoading = state is AuthLoading;
                                  return SizedBox(
                                    width: double.infinity,
                                    child: ElevatedButton(
                                      onPressed:
                                          isLoading ? null : _handleLogin,
                                      style: ElevatedButton.styleFrom(
                                        padding: EdgeInsets.symmetric(
                                          vertical: 12.w,
                                        ),
                                        minimumSize: Size(
                                          double.infinity,
                                          40.h,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            10,
                                          ),
                                        ),
                                        side: BorderSide(
                                          color: AppColors.border,
                                        ),
                                      ),
                                      child:
                                          isLoading
                                              ? SizedBox(
                                                height: 20.h,
                                                width: 20.w,
                                                child: CircularProgressIndicator(
                                                  strokeWidth: 2,
                                                  valueColor:
                                                      AlwaysStoppedAnimation<
                                                        Color
                                                      >(AppColors.whiteColor),
                                                ),
                                              )
                                              : Text(
                                                "login_button".tr,
                                                style: TextStyle(
                                                  fontSize: 16.sp,
                                                  color: AppColors.whiteColor,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                    ),
                                  );
                                },
                              ),
                              SizedBox(height: 29.h),
                              Row(
                                children: [
                                  Expanded(child: Divider()),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 43.w,
                                    ),
                                    child: Text(
                                      "login_or_with".tr,
                                      style: TextStyle(
                                        color: AppColors.textGrey,
                                        height: 24 / 16,
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                  Expanded(child: Divider()),
                                ],
                              ),
                              SizedBox(height: 30.h),
                              SocialButton(
                                label: 'login_google'.tr,
                                icon: 'assets/svg/GoogleLogo.svg',
                                onPressed: () {
                                  ContextToastService.showInfo(
                                    context,
                                    'login_google_coming_soon'.tr,
                                    duration: const Duration(seconds: 2),
                                  );
                                },
                              ),
                              const SizedBox(height: 12),
                              SocialButton(
                                label: 'login_apple'.tr,
                                icon: 'assets/svg/apple_logo.svg',
                                onPressed: () {
                                  ContextToastService.showInfo(
                                    context,
                                    'login_apple_coming_soon'.tr,
                                    duration: const Duration(seconds: 2),
                                  );
                                },
                              ),
                              const Spacer(),
                              Center(
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder:
                                            (context) => CreateAccountScreen(),
                                      ),
                                    );
                                  },
                                  child: Text.rich(
                                    TextSpan(
                                      style: TextStyle(
                                        color: AppColors.textGrey,
                                      ),
                                      text: "${"login_no_account_login".tr} ",
                                      children: [
                                        TextSpan(
                                          text: "login_register".tr,
                                          style: TextStyle(
                                            decoration:
                                                TextDecoration.underline,
                                            color: AppColors.primary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 12.h),

                              // Language test button (remove this after testing)
                              // SizedBox(height: 20.h),
                              // Center(
                              //   child: ElevatedButton(
                              //     onPressed: () {
                              //       Navigator.pushNamed(
                              //         context,
                              //         '/language-selector',
                              //       );
                              //     },
                              //     style: ElevatedButton.styleFrom(
                              //       backgroundColor: Colors.orange,
                              //       foregroundColor: Colors.white,
                              //     ),
                              //     child: Text('Test Language Switch'),
                              //   ),
                              // ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
