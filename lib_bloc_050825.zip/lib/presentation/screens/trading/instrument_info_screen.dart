import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/constants/color.dart';
import '../../../core/constants/text_styles.dart';
import '../../../core/services/language_service.dart';

class InstrumentInfoScreen extends StatefulWidget {
  const InstrumentInfoScreen({super.key});

  @override
  State<InstrumentInfoScreen> createState() => _InstrumentInfoScreenState();
}

class _InstrumentInfoScreenState extends State<InstrumentInfoScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListenableBuilder(
        listenable: languageService,
        builder: (context, child) {
          return SafeArea(
            child: Column(
              children: [
                // Header
                _buildHeader(),
                // Content
                Expanded(child: _buildContent()),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      child: Row(
        children: [
          // Time
          Text(
            '9:41',
            style: AppTextStyles.label.copyWith(
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
          const Spacer(),

          // Account Balance
          Text(
            '\$0.00',
            style: AppTextStyles.label.copyWith(
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(width: 16.w),

          // Account Type
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(4.r),
            ),
            child: Text(
              'REAL',
              style: AppTextStyles.label.copyWith(
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),
          SizedBox(width: 16.w),

          // Icons
          Icon(Icons.info_outline, size: 20.h, color: AppColors.textGrey),
          SizedBox(width: 8.w),
          Icon(Icons.star_border, size: 20.h, color: AppColors.textGrey),
        ],
      ),
    );
  }

  Widget _buildContent() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          Text(
            'Gold on Stop',
            style: AppTextStyles.heading.copyWith(
              fontSize: 20.sp,
              fontWeight: FontWeight.w700,
            ),
          ),

          SizedBox(height: 16.h),

          // Description
          Text(
            'Trading gold actually means trading gold to 15 dollar. This is crucial to take into account when you consider trading this symbol, as the USD is much less stable and more volatile currency. Major gold-mining players are Australia, China, Russia, and the USA. Of all the symbols in the commodity market, gold is one of the most actively traded and can be analyzed easily.',
            style: AppTextStyles.subheading.copyWith(
              fontSize: 14.sp,
              fontWeight: FontWeight.w400,
              color: AppColors.textGrey,
              height: 1.5,
            ),
          ),

          SizedBox(height: 24.h),

          // Parameters Section
          Text(
            'Parameters',
            style: AppTextStyles.heading.copyWith(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
            ),
          ),

          SizedBox(height: 12.h),

          _buildParameterItem('Digits', '3'),
          _buildParameterItem('Lot size', '100'),
          _buildParameterItem('Pip price', '100'),
          _buildParameterItem('Minimum volume', '100'),
          _buildParameterItem('Maximum volume', '100'),
          _buildParameterItem('Margin percentage', '100'),
          _buildParameterItem('Order execution mode', 'Market'),

          SizedBox(height: 24.h),

          // Trading Hours Section
          Text(
            'Trading hours (Asia/Kolkata)',
            style: AppTextStyles.heading.copyWith(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
            ),
          ),

          SizedBox(height: 12.h),

          _buildTradingHourItem('Monday', '3:30 AM-11:59 PM'),
          _buildTradingHourItem('Monday', '12:00 AM-2:30 AM'),
          _buildTradingHourItem('Tuesday', '3:30 AM-11:59 PM'),
          _buildTradingHourItem('Tuesday', '12:00 AM-2:30 AM'),
          _buildTradingHourItem('Wednesday', '3:30 AM-11:59 PM'),
          _buildTradingHourItem('Wednesday', '12:00 AM-2:30 AM'),
          _buildTradingHourItem('Thursday', '3:30 AM-11:59 PM'),
          _buildTradingHourItem('Thursday', '12:00 AM-2:30 AM'),
          _buildTradingHourItem('Friday', '3:30 AM-11:59 PM'),
          _buildTradingHourItem('Friday', '12:00 AM-2:30 AM'),
          _buildTradingHourItem('Saturday', '3:30 AM-11:59 PM'),
          _buildTradingHourItem('Saturday', 'Market Closed'),
          _buildTradingHourItem('Sunday', '3:30 AM-11:59 PM'),
          _buildTradingHourItem('Sunday', '12:00 AM-2:30 AM'),
        ],
      ),
    );
  }

  Widget _buildParameterItem(String label, String value) {
    return Container(
      margin: EdgeInsets.only(bottom: 8.h),
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: AppColors.secondary,
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: AppTextStyles.label.copyWith(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: AppColors.textGrey,
              ),
            ),
          ),
          Text(
            value,
            style: AppTextStyles.label.copyWith(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTradingHourItem(String day, String hours) {
    return Container(
      margin: EdgeInsets.only(bottom: 8.h),
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: AppColors.secondary,
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              day,
              style: AppTextStyles.label.copyWith(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: AppColors.textGrey,
              ),
            ),
          ),
          Text(
            hours,
            style: AppTextStyles.label.copyWith(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
