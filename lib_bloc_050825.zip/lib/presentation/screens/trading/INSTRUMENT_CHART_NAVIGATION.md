# Instrument to Chart Navigation

## Overview

This feature allows users to tap on any instrument in the instruments list and automatically navigate to the chart screen with the selected symbol loaded.

## How It Works

### 1. User Interaction
- User taps on any instrument item in the instruments list
- The instrument item has visual feedback (ripple effect) and a navigation arrow
- A toast notification shows "Opening chart for [SYMBOL]"

### 2. Navigation Flow
```
Instruments List → Tap Instrument → Chart Screen
```

### 3. Code Implementation

#### Instruments Screen (`instruments_screen.dart`)
- **Instrument Item Widget**: Each instrument is wrapped in a `GestureDetector` with `InkWell` for visual feedback
- **Navigation Method**: `_navigateToChartWithSymbol(String symbol)` handles the tap
- **Symbol Setting**: Uses `ChartScreen.setSelectedSymbol(symbol)` to pass the selected symbol
- **Navigation Callback**: Calls `widget.onNavigateToChart()` to switch to chart tab

#### Trading Main Screen (`trading_main_screen.dart`)
- **Navigation Callback**: `_navigateToChart()` method switches to chart tab (index 1)
- **Screen Integration**: Instruments screen is initialized with the navigation callback

#### Chart Screen (`chart_screen.dart`)
- **Static Symbol Management**: Uses `ValueNotifier` to handle symbol changes
- **Symbol Listener**: `_onSymbolChangedFromInstruments()` updates the chart when symbol changes
- **Chart Update**: Automatically loads new chart data for the selected symbol

## Features

### ✅ **Visual Feedback**
- Ripple effect when tapping instrument items
- Navigation arrow icon on each instrument
- Toast notification showing selected symbol

### ✅ **Seamless Navigation**
- Automatic tab switching from instruments to chart
- Symbol is immediately available in chart screen
- Chart updates with new symbol data

### ✅ **User Experience**
- Smooth transitions between screens
- Clear visual indicators for tappable items
- Immediate feedback on selection

## Supported Instruments

The navigation works with all instrument types:
- **Currency Pairs**: EURUSD, GBPUSD, USDJPY, etc.
- **Metals**: XAUUSD, XAGUSD
- **Indices**: AU200, DE40, ES35, etc.

## Technical Details

### Key Components
1. **GestureDetector**: Handles tap events
2. **InkWell**: Provides visual feedback
3. **ValueNotifier**: Manages symbol state across screens
4. **Navigation Callback**: Enables tab switching
5. **Toast Service**: Shows user feedback

### State Management
- Symbol selection is managed through static `ValueNotifier`
- Chart screen listens for symbol changes
- Navigation state is handled by tab index

## Usage Example

```dart
// User taps on EURUSD instrument
// 1. Toast shows: "Opening chart for EURUSD"
// 2. Symbol is set: ChartScreen.setSelectedSymbol("EURUSD")
// 3. Navigation occurs: Switch to chart tab
// 4. Chart loads: EURUSD chart data is displayed
```

## Testing

To test the navigation:
1. Open the trading app
2. Go to Instruments tab
3. Tap on any instrument (e.g., EURUSD)
4. Verify toast notification appears
5. Verify navigation to chart tab
6. Verify chart shows the selected symbol 