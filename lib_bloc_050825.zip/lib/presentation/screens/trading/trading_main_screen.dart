import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/constants/color.dart';
import '../../../core/constants/text_styles.dart';
import '../../../core/services/language_service.dart';
import '../../../core/utils/rtl_helper.dart';
import '../../widgets/trading_bottom_navigation.dart';
import '../../widgets/global_drawer.dart';
import 'instruments_screen.dart';
import 'chart_screen.dart';
import 'trade_screen.dart';
import 'dashboard_screen.dart';
import 'more_screen.dart';

class TradingMainScreen extends StatefulWidget {
  const TradingMainScreen({super.key});

  @override
  State<TradingMainScreen> createState() => _TradingMainScreenState();
}

class _TradingMainScreenState extends State<TradingMainScreen> {
  int _currentIndex = 0;
  late List<Widget> _screens;

  // Callback to switch to chart tab
  void _switchToChartTab() {
    print(
      'TradingMainScreen: Switching to chart tab from index $_currentIndex',
    );
    setState(() {
      _currentIndex = 1; // Chart screen is at index 1
    });
    print(
      'TradingMainScreen: Switched to chart tab, new index: $_currentIndex',
    );
  }

  @override
  void initState() {
    super.initState();
    _screens = [
      // Pass the callback to InstrumentsScreen
      InstrumentsScreen(onNavigateToChart: _switchToChartTab),
      const ChartScreen(),
      const TradeScreen(),
      const DashboardScreen(),
      const MoreScreen(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListenableBuilder(
        listenable: languageService,
        builder: (context, child) {
          return Scaffold(
            backgroundColor: AppColors.backgroundLight,
            // appBar: AppBar(
            //   title: Text(_getCurrentScreenTitle()),
            //   backgroundColor: AppColors.primary,
            //   foregroundColor: Colors.white,
            //   elevation: 0,
            // ),
            drawer: const GlobalDrawer(),
            body: SafeArea(
              child: IndexedStack(index: _currentIndex, children: _screens),
            ),
            bottomNavigationBar: TradingBottomNavigation(
              currentIndex: _currentIndex,
              onTap: (index) {
                setState(() {
                  _currentIndex = index;
                });
              },
            ),
          );
        },
      ),
    );
  }

  String _getCurrentScreenTitle() {
    switch (_currentIndex) {
      case 0:
        return "instruments_title".tr;
      case 1:
        return "chart_title".tr;
      case 2:
        return "trade_title".tr;
      case 3:
        return "dashboard_title".tr;
      case 4:
        return "more_title".tr;
      default:
        return "app_name".tr;
    }
  }
}

// Placeholder screen for other trading sections
class PlaceholderScreen extends StatelessWidget {
  final String title;

  const PlaceholderScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: languageService,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: AppColors.backgroundLight,
          body: SafeArea(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.construction,
                    size: 64.h,
                    color: AppColors.textGrey,
                  ),
                  SizedBox(height: 16.h),
                  Text(
                    title,
                    style: AppTextStyles.heading.copyWith(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    'common_coming_soon'.tr,
                    style: AppTextStyles.subheading.copyWith(
                      color: AppColors.textGrey,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
