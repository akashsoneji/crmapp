import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_svg/svg.dart';
import 'package:pipze/core/services/language_service.dart';
import 'package:pipze/core/utils/rtl_helper.dart';
import '../../../core/constants/color.dart';
import '../../../core/constants/text_styles.dart';
import '../../widgets/global_drawer.dart';
import '../../blocs/account/account_bloc.dart';
import '../../blocs/account/account_state.dart';
import '../../blocs/account/account_event.dart';
import '../../widgets/account_selector.dart';
import 'chart_screen.dart';

// Instrument Model
class Instrument {
  final String name;
  final String flag;
  final String status;
  final String bidPrice;
  final String askPrice;
  final String lowPrice;
  final String? heigh;
  final String highPrice;
  final bool isFavorite;
  final String category;

  Instrument({
    required this.name,
    required this.flag,
    required this.status,
    required this.bidPrice,
    this.heigh,
    required this.askPrice,
    required this.lowPrice,
    required this.highPrice,
    this.isFavorite = false,
    required this.category,
  });
}

// Events
abstract class InstrumentsEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadInstruments extends InstrumentsEvent {}

class SearchInstruments extends InstrumentsEvent {
  final String query;
  SearchInstruments(this.query);

  @override
  List<Object?> get props => [query];
}

class FilterInstruments extends InstrumentsEvent {
  final String filter;
  FilterInstruments(this.filter);

  @override
  List<Object?> get props => [filter];
}

class SortInstruments extends InstrumentsEvent {
  final String sortBy;
  SortInstruments(this.sortBy);

  @override
  List<Object?> get props => [sortBy];
}

class ToggleFavorite extends InstrumentsEvent {
  final String instrumentName;
  ToggleFavorite(this.instrumentName);

  @override
  List<Object?> get props => [instrumentName];
}

// States
abstract class InstrumentsState extends Equatable {
  @override
  List<Object?> get props => [];
}

class InstrumentsInitial extends InstrumentsState {}

class InstrumentsLoading extends InstrumentsState {}

class InstrumentsLoaded extends InstrumentsState {
  final List<Instrument> instruments;
  final String currentFilter;
  final String currentSort;
  final String searchQuery;
  final bool isSearching;

  InstrumentsLoaded({
    required this.instruments,
    this.currentFilter = 'All',
    this.currentSort = 'Popularity',
    this.searchQuery = '',
    this.isSearching = false,
  });

  @override
  List<Object?> get props => [
    instruments,
    currentFilter,
    currentSort,
    searchQuery,
    isSearching,
  ];
}

class InstrumentsError extends InstrumentsState {
  final String message;
  InstrumentsError(this.message);

  @override
  List<Object?> get props => [message];
}

// BLoC
class InstrumentsBloc extends Bloc<InstrumentsEvent, InstrumentsState> {
  InstrumentsBloc() : super(InstrumentsInitial()) {
    on<LoadInstruments>(_onLoadInstruments);
    on<SearchInstruments>(_onSearchInstruments);
    on<FilterInstruments>(_onFilterInstruments);
    on<SortInstruments>(_onSortInstruments);
    on<ToggleFavorite>(_onToggleFavorite);
  }

  List<Instrument> _allInstruments = [
    // Currency pairs - matching the image exactly
    Instrument(
      name: 'EURUSD',
      flag: '🇪🇺🇺🇸',
      status: 'Market closed',
      bidPrice: '1.24948',
      askPrice: '1.24959',
      lowPrice: '0.65514',
      highPrice: '0.65582',
      category: 'Currency',
    ),
    Instrument(
      name: 'AUDCHF',
      flag: '🇦🇺🇨🇭',
      status: 'Market closed',
      bidPrice: '1.24948',
      askPrice: '1.24959',
      lowPrice: '0.65514',
      highPrice: '0.65582',
      category: 'Currency',
    ),
    Instrument(
      name: 'AUDJPY',
      flag: '🇦🇺🇯🇵',
      status: '10:47:54',
      heigh: 'S 0.06',
      bidPrice: '1.24948',
      askPrice: '1.24959',
      lowPrice: '0.65514',
      highPrice: '0.65582',
      category: 'Currency',
    ),
    Instrument(
      name: 'AUDCHF',
      flag: '🇦🇺🇨🇭',
      status: 'Market closed',
      bidPrice: '1.24948',
      askPrice: '1.24959',
      lowPrice: '0.65514',
      highPrice: '0.65582',
      category: 'Currency',
    ),
    Instrument(
      name: 'EURUSD',
      flag: '🇪🇺🇺🇸',
      status: 'Market closed',
      bidPrice: '1.24948',
      askPrice: '1.24959',
      lowPrice: '0.65514',
      highPrice: '0.65582',
      category: 'Currency',
    ),
    Instrument(
      name: 'AUDCHF',
      flag: '🇦🇺🇨🇭',
      status: 'Market closed',
      bidPrice: '1.24948',
      askPrice: '1.24959',
      lowPrice: '0.65514',
      highPrice: '0.65582',
      category: 'Currency',
    ),
    Instrument(
      name: 'AUDJPY',
      flag: '🇦🇺🇯🇵',
      status: 'Market closed',
      bidPrice: '1.24948',
      askPrice: '1.24959',
      lowPrice: '0.65514',
      highPrice: '0.65582',
      category: 'Currency',
    ),
    Instrument(
      name: 'AUDCHF',
      flag: '🇦🇺🇨🇭',
      status: 'Market closed',
      bidPrice: '1.24948',
      askPrice: '1.24959',
      lowPrice: '0.65514',
      highPrice: '0.65582',
      category: 'Currency',
    ),
    // Metals
    Instrument(
      name: 'XAUUSD',
      flag: '🥇',
      status: '01:00:00 H 20.0',
      bidPrice: '3426.588',
      askPrice: '3426.772',
      lowPrice: '3426.0',
      highPrice: '3427.0',
      category: 'Metals',
    ),
    Instrument(
      name: 'XAGUSD',
      flag: '🥈',
      status: '01:00:00 H 33.0',
      bidPrice: '39.419',
      askPrice: '39.442',
      lowPrice: '39.40',
      highPrice: '39.45',
      category: 'Metals',
    ),
    // Indices
    Instrument(
      name: 'AU200',
      flag: '🇦🇺',
      status: '01:00:00 H 26.0',
      bidPrice: '8734.25',
      askPrice: '8736.87',
      lowPrice: '8730.0',
      highPrice: '8740.0',
      category: 'Indices Spot',
    ),
    Instrument(
      name: 'DE40',
      flag: '🇩🇪',
      status: '01:00:00 H 35.0',
      bidPrice: '24157.431',
      askPrice: '24157.776',
      lowPrice: '24150.0',
      highPrice: '24160.0',
      category: 'Indices Spot',
    ),
    Instrument(
      name: 'ES35',
      flag: '🇪🇸',
      status: '01:00:00 H 65.0',
      bidPrice: '14136.54',
      askPrice: '14143.07',
      lowPrice: '14130.0',
      highPrice: '14150.0',
      category: 'Indices Spot',
    ),
    Instrument(
      name: 'EU50',
      flag: '🇪🇺',
      status: '01:00:00 H 25.0',
      bidPrice: '5335.73',
      askPrice: '5338.28',
      lowPrice: '5330.0',
      highPrice: '5340.0',
      category: 'Indices Spot',
    ),
    Instrument(
      name: 'FR40',
      flag: '🇫🇷',
      status: '01:00:00 H 22.0',
      bidPrice: '7818.84',
      askPrice: '7821.09',
      lowPrice: '7815.0',
      highPrice: '7825.0',
      category: 'Indices Spot',
    ),
    Instrument(
      name: 'HK50',
      flag: '🇭🇰',
      status: '01:00:00 H 55.0',
      bidPrice: '25503.35',
      askPrice: '25508.76',
      lowPrice: '25500.0',
      highPrice: '25510.0',
      category: 'Indices Spot',
    ),
  ];

  void _onLoadInstruments(
    LoadInstruments event,
    Emitter<InstrumentsState> emit,
  ) {
    emit(InstrumentsLoading());
    // Filter to show Currency by default
    final currencyInstruments =
        _allInstruments
            .where((instrument) => instrument.category == 'Currency')
            .toList();
    emit(
      InstrumentsLoaded(
        instruments: currencyInstruments,
        currentFilter: 'Currency',
        searchQuery: '',
        isSearching: false,
      ),
    );
  }

  void _onSearchInstruments(
    SearchInstruments event,
    Emitter<InstrumentsState> emit,
  ) {
    if (state is InstrumentsLoaded) {
      final currentState = state as InstrumentsLoaded;
      List<Instrument> filteredInstruments = _allInstruments;

      // First apply category filter
      if (currentState.currentFilter != 'All' &&
          currentState.currentFilter != 'Favorites') {
        filteredInstruments =
            filteredInstruments
                .where(
                  (instrument) =>
                      instrument.category == currentState.currentFilter,
                )
                .toList();
      } else if (currentState.currentFilter == 'Favorites') {
        filteredInstruments =
            filteredInstruments
                .where((instrument) => instrument.isFavorite)
                .toList();
      }

      // Then apply search filter
      if (event.query.isNotEmpty) {
        filteredInstruments =
            filteredInstruments
                .where(
                  (instrument) => instrument.name.toLowerCase().contains(
                    event.query.toLowerCase(),
                  ),
                )
                .toList();
      }

      emit(
        InstrumentsLoaded(
          instruments: filteredInstruments,
          currentFilter: currentState.currentFilter,
          currentSort: currentState.currentSort,
          searchQuery: event.query,
          isSearching: event.query.isNotEmpty,
        ),
      );
    }
  }

  void _onFilterInstruments(
    FilterInstruments event,
    Emitter<InstrumentsState> emit,
  ) {
    if (state is InstrumentsLoaded) {
      final currentState = state as InstrumentsLoaded;
      List<Instrument> filteredInstruments = _allInstruments;

      // Apply category filter
      if (event.filter == 'Favorites') {
        filteredInstruments =
            _allInstruments
                .where((instrument) => instrument.isFavorite)
                .toList();
      } else if (event.filter != 'All') {
        filteredInstruments =
            _allInstruments
                .where((instrument) => instrument.category == event.filter)
                .toList();
      }

      // Apply search filter if there's an active search
      if (currentState.searchQuery.isNotEmpty) {
        filteredInstruments =
            filteredInstruments
                .where(
                  (instrument) => instrument.name.toLowerCase().contains(
                    currentState.searchQuery.toLowerCase(),
                  ),
                )
                .toList();
      }

      emit(
        InstrumentsLoaded(
          instruments: filteredInstruments,
          currentFilter: event.filter,
          currentSort: currentState.currentSort,
          searchQuery: currentState.searchQuery,
          isSearching: currentState.isSearching,
        ),
      );
    }
  }

  void _onSortInstruments(
    SortInstruments event,
    Emitter<InstrumentsState> emit,
  ) {
    if (state is InstrumentsLoaded) {
      final currentState = state as InstrumentsLoaded;
      List<Instrument> sortedInstruments = List.from(currentState.instruments);

      // Simple sorting logic - in real app, you'd sort by actual values
      switch (event.sortBy) {
        case 'Popularity':
          // Keep current order
          break;
        case 'Daily Changes':
          sortedInstruments.sort((a, b) => a.name.compareTo(b.name));
          break;
        case 'Daily gain':
          sortedInstruments.sort((a, b) => b.name.compareTo(a.name));
          break;
        case 'Daily loss':
          sortedInstruments.sort((a, b) => a.name.compareTo(b.name));
          break;
      }

      emit(
        InstrumentsLoaded(
          instruments: sortedInstruments,
          currentFilter: currentState.currentFilter,
          currentSort: event.sortBy,
          searchQuery: currentState.searchQuery,
          isSearching: currentState.isSearching,
        ),
      );
    }
  }

  void _onToggleFavorite(ToggleFavorite event, Emitter<InstrumentsState> emit) {
    if (state is InstrumentsLoaded) {
      final currentState = state as InstrumentsLoaded;
      final updatedInstruments =
          _allInstruments.map((instrument) {
            if (instrument.name == event.instrumentName) {
              return Instrument(
                name: instrument.name,
                flag: instrument.flag,
                status: instrument.status,
                bidPrice: instrument.bidPrice,
                askPrice: instrument.askPrice,
                lowPrice: instrument.lowPrice,
                highPrice: instrument.highPrice,
                isFavorite: !instrument.isFavorite,
                category: instrument.category,
              );
            }
            return instrument;
          }).toList();

      _allInstruments = updatedInstruments;

      emit(
        InstrumentsLoaded(
          instruments: currentState.instruments,
          currentFilter: currentState.currentFilter,
          currentSort: currentState.currentSort,
          searchQuery: currentState.searchQuery,
          isSearching: currentState.isSearching,
        ),
      );
    }
  }
}

class InstrumentsScreen extends StatefulWidget {
  final VoidCallback? onNavigateToChart;

  const InstrumentsScreen({super.key, this.onNavigateToChart});

  @override
  State<InstrumentsScreen> createState() => _InstrumentsScreenState();
}

class _InstrumentsScreenState extends State<InstrumentsScreen> {
  final TextEditingController _searchController = TextEditingController();
  final List<String> _filters = [
    'All',
    'Favorites',
    'Currency',
    'Metals',
    'Indices Spot',
  ];
  final List<String> _sortOptions = [
    'Popularity',
    'Daily Changes',
    'Daily gain',
    'Daily loss',
  ];
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    context.read<InstrumentsBloc>().add(LoadInstruments());

    // Ensure accounts are loaded
    context.read<AccountBloc>().add(const LoadAccounts());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      drawer: const GlobalDrawer(),
      body: Column(
        children: [
          _buildHeader(),
          _buildSearchAndFilters(),
          Expanded(
            child: BlocBuilder<InstrumentsBloc, InstrumentsState>(
              builder: (context, state) {
                if (state is InstrumentsLoading) {
                  return const Center(child: CircularProgressIndicator());
                } else if (state is InstrumentsLoaded) {
                  if (state.instruments.isEmpty) {
                    return _buildNoData();
                  }
                  return _buildInstrumentsList(state.instruments);
                } else if (state is InstrumentsError) {
                  return Center(child: Text(state.message));
                }
                return const SizedBox();
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      child: Row(
        children: [
          if (_isSearching) ...[
            // Back arrow when searching
            GestureDetector(
              onTap: () {
                setState(() {
                  _isSearching = false;
                  _searchController.clear();
                });
                // Clear search and reload with current filter
                context.read<InstrumentsBloc>().add(SearchInstruments(''));
              },
              child: Icon(
                Icons.arrow_back,
                size: 24.h,
                color: AppColors.textGrey,
              ),
            ),
            SizedBox(width: 12.w),
            // Search text field
            Expanded(
              child: TextField(
                controller: _searchController,
                autofocus: true,
                onChanged: (value) {
                  context.read<InstrumentsBloc>().add(SearchInstruments(value));
                },
                textDirection: RTLHelper.textDirection,
                textAlign: RTLHelper.isRTL ? TextAlign.right : TextAlign.left,
                decoration: InputDecoration(
                  hintText: "instruments_search".tr,
                  hintStyle: AppTextStyles.input.copyWith(
                    color: AppColors.textGrey,
                  ),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 8.w),
                ),
              ),
            ),
          ] else ...[
            // Menu icon
            InkWell(
              onTap: () {
                Scaffold.of(context).openDrawer();
              },
              child: SvgPicture.asset(
                "assets/svg/menu.svg",
                height: 24.h,
                width: 24.w,
              ),
            ),
            SizedBox(width: 6.w),
            // Balance and account info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Dynamic Balance Display
                  BlocBuilder<AccountBloc, AccountState>(
                    builder: (context, state) {
                      if (state is AccountLoaded &&
                          state.activeAccount != null) {
                        return Text(
                          '\$${state.activeAccount!.balance.toStringAsFixed(2)}',
                          style: AppTextStyles.heading.copyWith(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w700,
                          ),
                        );
                      }
                      return Text(
                        '\$0.00',
                        style: AppTextStyles.heading.copyWith(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w700,
                        ),
                      );
                    },
                  ),
                  // Dynamic Account Selector
                  GestureDetector(
                    onTap: () {
                      context.read<AccountBloc>().add(
                        const ResetToDefaultAccounts(),
                      );

                      _showAccountSelectionBottomSheet(context);
                    },
                    child: BlocBuilder<AccountBloc, AccountState>(
                      builder: (context, state) {
                        // if (state is AccountLoaded &&
                        //     state.activeAccount != null) {
                        //   return Row(
                        //     children: [
                        //       Container(
                        //         alignment: Alignment.center,
                        //         width: 45.w,
                        //         height: 22.h,
                        //         decoration: BoxDecoration(
                        //           color:
                        //               state.activeAccount!.type == 'REAL'
                        //                   ? AppColors.accent
                        //                   : AppColors.success,
                        //           borderRadius: BorderRadius.circular(12),
                        //         ),
                        //         child: Text(
                        //           state.activeAccount!.type.toUpperCase(),
                        //           style: TextStyle(
                        //             color: Colors.white,
                        //             fontSize: 10.sp,
                        //             fontWeight: FontWeight.w600,
                        //           ),
                        //         ),
                        //       ),
                        //       SizedBox(width: 4.w),
                        //       SizedBox(
                        //         height: 22.h,
                        //         width: 75.w,
                        //         child: Text(
                        //           state.activeAccount!.id,
                        //           textAlign: TextAlign.start,
                        //           style: AppTextStyles.subheading.copyWith(
                        //             fontSize: 12.sp,
                        //             color: AppColors.textGrey,
                        //           ),
                        //         ),
                        //       ),
                        //       Icon(
                        //         Icons.arrow_drop_down,
                        //         size: 16.h,
                        //         color: AppColors.textGrey,
                        //       ),
                        //     ],
                        //   );
                        // }
                        return Row(
                          children: [
                            Container(
                              alignment: Alignment.center,
                              width: 45.w,
                              height: 22.h,
                              decoration: BoxDecoration(
                                color: AppColors.accent,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                "REAL",
                                style: TextStyle(
                                  color: AppColors.textPrimary,
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            SizedBox(width: 4.w),
                            SizedBox(
                              height: 22.h,
                              width: 75.w,
                              child: Text(
                                '035172384',
                                textAlign: TextAlign.start,
                                style: AppTextStyles.subheading.copyWith(
                                  fontSize: 12.sp,
                                  color: AppColors.textGrey,
                                ),
                              ),
                            ),
                            Icon(
                              Icons.arrow_drop_down,
                              size: 16.h,
                              color: AppColors.textGrey,
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            // Search icon
            GestureDetector(
              onTap: () {
                setState(() {
                  _isSearching = true;
                });
              },
              child: SvgPicture.asset(
                "assets/svg/search-normal.svg",
                height: 24.h,
                width: 24.w,
              ),
            ),
            // Debug: Reset accounts button (remove in production)
          ],
        ],
      ),
    );
  }

  Widget _buildSearchAndFilters() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w),
      child: Column(
        children: [
          SizedBox(height: 16.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "instruments_title".tr,
                style: AppTextStyles.heading.copyWith(
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(width: 12.w),
              _buildSortDropdown(),
            ],
          ),
          SizedBox(height: 16.h),
          Row(children: [Expanded(child: _buildFilterButtons())]),
          SizedBox(height: 16.h),
        ],
      ),
    );
  }

  Widget _buildFilterButtons() {
    return BlocBuilder<InstrumentsBloc, InstrumentsState>(
      builder: (context, state) {
        String currentFilter = 'All';
        if (state is InstrumentsLoaded) {
          currentFilter = state.currentFilter;
        }

        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children:
                _filters.map((filter) {
                  final isSelected = filter == currentFilter;
                  return Padding(
                    padding: EdgeInsets.only(right: 8.w),
                    child: GestureDetector(
                      onTap: () {
                        // Clear search when switching filters
                        if (_isSearching) {
                          setState(() {
                            _isSearching = false;
                            _searchController.clear();
                          });
                        }
                        context.read<InstrumentsBloc>().add(
                          FilterInstruments(filter),
                        );
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 16.w,
                          vertical: 8.h,
                        ),
                        decoration: BoxDecoration(
                          color: isSelected ? AppColors.primary : Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color:
                                isSelected
                                    ? AppColors.primary
                                    : AppColors.primary,
                          ),
                        ),
                        child: Text(
                          filter,
                          style: AppTextStyles.input.copyWith(
                            fontSize: 14.sp,
                            height: 22 / 15,
                            color:
                                isSelected
                                    ? AppColors.whiteColor
                                    : AppColors.primary,
                            fontWeight:
                                isSelected ? FontWeight.w600 : FontWeight.w400,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
          ),
        );
      },
    );
  }

  Widget _buildSortDropdown() {
    return BlocBuilder<InstrumentsBloc, InstrumentsState>(
      builder: (context, state) {
        String currentSort = 'Popularity';
        if (state is InstrumentsLoaded) {
          currentSort = state.currentSort;
        }

        return GestureDetector(
          onTap: () {
            _showSortBottomSheet();
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
            decoration: BoxDecoration(
              color: AppColors.primary.withAlpha(45),
              borderRadius: BorderRadius.circular(16),
              // border: Border.all(color: AppColors.border),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'By $currentSort',
                  style: AppTextStyles.input.copyWith(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w400,
                    height: 22 / 15,
                    color: AppColors.primary,
                  ),
                ),
                SizedBox(width: 4.w),
                Icon(
                  Icons.keyboard_arrow_down,
                  size: 16.h,
                  color: AppColors.primary,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildInstrumentsList(List<Instrument> instruments) {
    return ListView.builder(
      padding: EdgeInsets.zero,
      itemCount: instruments.length,
      itemBuilder: (context, index) {
        final instrument = instruments[index];
        return _buildInstrumentItem(instrument);
      },
    );
  }

  Widget _buildInstrumentItem(Instrument instrument) {
    return GestureDetector(
      onTap: () {
        _navigateToChartWithSymbol(instrument.name);
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(
            bottom: BorderSide(
              color: AppColors.border.withOpacity(0.3),
              width: 0.5,
            ),
          ),
        ),
        child: Row(
          children: [
            // Flag and Name
            Expanded(
              flex: 3,
              child: Row(
                children: [
                  // Flags container
                  Container(
                    width: 40.w,
                    height: 24.h,
                    child: Stack(
                      children: [
                        // First flag (left)
                        Positioned(
                          left: 0,
                          child: Text(
                            _getFirstFlag(instrument.flag),
                            style: TextStyle(fontSize: 16.sp),
                          ),
                        ),
                        // Second flag (right, slightly overlapping)
                        Positioned(
                          right: 0,
                          child: Text(
                            _getSecondFlag(instrument.flag),
                            style: TextStyle(fontSize: 16.sp),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _getMarketStatus(instrument.status),
                          style: AppTextStyles.subheading.copyWith(
                            fontSize: 10.sp,
                            color: AppColors.textGrey,
                          ),
                        ),
                        Text(
                          instrument.name,
                          style: AppTextStyles.input.copyWith(
                            fontWeight: FontWeight.w600,
                            fontSize: 16.sp,
                          ),
                        ),
                        if (instrument.heigh != null)
                          Row(
                            children: [
                              Text(
                                instrument.heigh!.replaceFirst(r'S', '+') +
                                    '%' +
                                    '\t',
                                style: AppTextStyles.subheading.copyWith(
                                  fontSize: 10.sp,
                                  color: AppColors.green,
                                ),
                              ),
                              Text(
                                instrument.heigh!,
                                style: AppTextStyles.subheading.copyWith(
                                  fontSize: 10.sp,
                                  color: AppColors.textGrey,
                                ),
                              ),
                            ],
                          ),
                        SizedBox(height: 2.h),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Sell Price (Red)
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    instrument.bidPrice,
                    style: AppTextStyles.input.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 17.sp,
                      color: AppColors.red,
                      height: 22 / 17,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    'L: ${instrument.lowPrice}',
                    style: AppTextStyles.subheading.copyWith(
                      fontSize: 10.sp,
                      color: AppColors.textGrey,
                      height: 22 / 10,
                    ),
                  ),
                ],
              ),
            ),
            // Buy Price (Green)
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    instrument.askPrice,
                    style: AppTextStyles.input.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 17.sp,
                      color: AppColors.success,
                      height: 22 / 17,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    'H: ${instrument.highPrice}',
                    style: AppTextStyles.subheading.copyWith(
                      fontSize: 10.sp,
                      color: AppColors.textGrey,
                      height: 22 / 10,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _navigateToChartWithSymbol(String symbol) {
    print('InstrumentsScreen: Navigating to chart with symbol: $symbol');
    // Set the selected symbol in chart screen
    ChartScreen.setSelectedSymbol(symbol);
    print('InstrumentsScreen: Set selected symbol to: $symbol');

    // Navigate to chart tab using the callback
    if (widget.onNavigateToChart != null) {
      print('InstrumentsScreen: Calling onNavigateToChart callback');
      widget.onNavigateToChart!();
    } else {
      print('InstrumentsScreen: onNavigateToChart callback is null');
    }
  }

  String _getMarketStatus(String status) {
    // Extract time and percentage from status like "01:00:00 H 16.0"
    if (status.contains('H') || status.contains('S')) {
      final parts = status.split(' ');
      if (parts.length >= 3) {
        final time = parts[0];
        final type = parts[1];
        final value = parts[2];

        if (type == 'S') {
          // Show active status with percentage
          return '$time +$value% S:${value.split('.')[0]}.${value.split('.')[1]}';
        } else {
          // Show market closed
          return 'Market closed';
        }
      }
    }
    return 'Market closed';
  }

  String _getFirstFlag(String flag) {
    // Extract first flag from combined flag string
    if (flag.length >= 4) {
      return flag.substring(0, 2);
    }
    return flag;
  }

  String _getSecondFlag(String flag) {
    // Extract second flag from combined flag string
    if (flag.length >= 4) {
      return flag.substring(2, 4);
    }
    return '';
  }

  Widget _buildNoData() {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // No data image/icon
            SvgPicture.asset('assets/svg/no_imge_icon.svg'),

            SizedBox(height: 24.h),
            Text(
              "common_no_data".tr,
              style: AppTextStyles.heading.copyWith(
                fontSize: 13.sp,
                fontWeight: FontWeight.w400,
                color: AppColors.textPrimary,
              ),
              textAlign: TextAlign.center,
            ),
            Text(
              "common_no_data_description".tr,
              style: AppTextStyles.subheading.copyWith(
                color: AppColors.textPrimary,
                fontSize: 13.sp,
                fontWeight: FontWeight.w400,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 32.h),

            // Refresh button
            // ElevatedButton.icon(
            //   onPressed: () {
            //     context.read<InstrumentsBloc>().add(LoadInstruments());
            //   },
            //   icon: Icon(Icons.refresh, size: 20.h),
            //   label: Text("common_refresh".tr),
            //   style: ElevatedButton.styleFrom(
            //     backgroundColor: AppColors.primary,
            //     foregroundColor: Colors.white,
            //     padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
            //     shape: RoundedRectangleBorder(
            //       borderRadius: BorderRadius.circular(12.r),
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoResults() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search_off, size: 64.h, color: AppColors.textGrey),
          SizedBox(height: 16.h),
          Text(
            "instruments_no_search_results".tr,
            textAlign: TextAlign.center,
            style: AppTextStyles.subheading.copyWith(color: AppColors.textGrey),
          ),
        ],
      ),
    );
  }

  void _showSortBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundLight,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(40.r)),
      ),
      builder: (context) {
        return BlocBuilder<InstrumentsBloc, InstrumentsState>(
          builder: (context, state) {
            String currentSort = 'Popularity';
            if (state is InstrumentsLoaded) {
              currentSort = state.currentSort;
            }

            return Container(
              padding: EdgeInsets.symmetric(vertical: 20.w),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 40.w,
                    height: 4.h,
                    decoration: BoxDecoration(
                      color: AppColors.grey,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Text(
                    'Sort by',
                    style: AppTextStyles.heading.copyWith(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  SizedBox(height: 16.h),
                  ..._sortOptions.map((option) {
                    return Column(
                      children: [
                        ListTile(
                          title: Row(
                            children: [
                              Container(
                                width: 24.w,
                                height: 24.h,
                                margin: EdgeInsets.all(8.sp),
                                padding: EdgeInsets.all(2.sp),
                                child: _getSortIcon(option),
                              ),
                              Text(option, style: AppTextStyles.input),
                            ],
                          ),
                          trailing:
                              option == currentSort
                                  ? Icon(Icons.check, color: AppColors.primary)
                                  : null,
                          onTap: () {
                            context.read<InstrumentsBloc>().add(
                              SortInstruments(option),
                            );
                            Navigator.pop(context);
                          },
                        ),
                        Divider(color: AppColors.grey, height: 1.h),
                      ],
                    );
                  }).toList(),
                  SizedBox(height: MediaQuery.of(context).padding.bottom + 0.1),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _getSortIcon(String option) {
    switch (option) {
      case 'Popularity':
        return SvgPicture.asset(
          "assets/svg/Like_Icon.svg",
          height: 22.h,
          width: 24.w,
        );
      case 'Daily Changes':
        return SvgPicture.asset(
          "assets/svg/fire.svg",
          height: 22.h,
          width: 24.w,
        );
      case 'Daily gain':
        return SvgPicture.asset(
          "assets/svg/dayily_gain.svg",
          height: 22.h,
          width: 24.w,
        );

      case 'Daily loss':
        return SvgPicture.asset(
          "assets/svg/dailly_loss.svg",
          height: 22.h,
          width: 24.w,
        );

      default:
        return Icon(Icons.sort, size: 20.h, color: AppColors.textGrey);
    }
  }

  void _showAccountSelectionBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (context) => BlocBuilder<AccountBloc, AccountState>(
            builder: (context, state) {
              // Calculate dynamic height based on number of accounts
              double dynamicHeight;
              if (state is AccountLoaded) {
                if (state.accounts.length <= 2) {
                  // If 2 accounts or fewer, take 1/4 of screen height
                  dynamicHeight = MediaQuery.of(context).size.height * 0.35;
                } else if (state.accounts.length <= 3) {
                  // If 2 accounts or fewer, take 1/4 of screen height
                  dynamicHeight = MediaQuery.of(context).size.height * 0.45;
                } else if (state.accounts.length <= 4) {
                  // If 2 accounts or fewer, take 1/4 of screen height
                  dynamicHeight = MediaQuery.of(context).size.height * 0.55;
                } else {
                  // If more than 3 accounts, take 1/7 of screen height
                  dynamicHeight = MediaQuery.of(context).size.height * 0.65;
                }
              } else {
                // Default height if state is not loaded
                dynamicHeight = MediaQuery.of(context).size.height * 0.3;
              }

              return Container(
                height: dynamicHeight,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20.r),
                    topRight: Radius.circular(20.r),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Handle bar
                    Container(
                      margin: EdgeInsets.only(top: 12.h),
                      width: 40.w,
                      height: 4.h,
                      decoration: BoxDecoration(
                        color: AppColors.grey,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),

                    // Title
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Select Account',
                            style: AppTextStyles.heading.copyWith(
                              fontSize: 18.sp,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          IconButton(
                            onPressed: () => Navigator.pop(context),
                            icon: Icon(Icons.close, color: AppColors.textGrey),
                          ),
                        ],
                      ),
                    ),

                    // Scrollable Account list
                    if (state is AccountLoaded) ...[
                      Expanded(
                        child: ListView.builder(
                          // padding: EdgeInsets.symmetric(horizontal: 16.w),
                          padding: EdgeInsets.zero,
                          itemCount: state.accounts.length,
                          itemBuilder: (context, index) {
                            final account = state.accounts[index];
                            final isActive =
                                state.activeAccount?.id == account.id;
                            return Container(
                              // margin: EdgeInsets.symmetric(vertical: 4.h),
                              child: ListTile(
                                leading: Container(
                                  padding: EdgeInsets.all(8.w),
                                  decoration: BoxDecoration(
                                    color:
                                        account.type == 'REAL'
                                            ? AppColors.primary
                                            : AppColors.success,
                                    borderRadius: BorderRadius.circular(8.r),
                                  ),
                                  child: Icon(
                                    Icons.account_balance_wallet,
                                    color: Colors.white,
                                    size: 20.h,
                                  ),
                                ),
                                title: Row(
                                  children: [
                                    Text(
                                      account.type,
                                      style: AppTextStyles.label.copyWith(
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                    if (isActive) ...[
                                      SizedBox(width: 8.w),
                                      Container(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 6.w,
                                          vertical: 2.h,
                                        ),
                                        decoration: BoxDecoration(
                                          color: AppColors.success,
                                          borderRadius: BorderRadius.circular(
                                            8.r,
                                          ),
                                        ),
                                        child: Text(
                                          'ACTIVE',
                                          style: AppTextStyles.label.copyWith(
                                            fontSize: 8.sp,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'ID: ${account.id}',
                                      style: AppTextStyles.label.copyWith(
                                        fontSize: 12.sp,
                                        color: AppColors.textGrey,
                                      ),
                                    ),
                                    Text(
                                      '\$${account.balance.toStringAsFixed(2)}',
                                      style: AppTextStyles.label.copyWith(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                  ],
                                ),
                                trailing: Radio<String>(
                                  value: account.id,
                                  groupValue: state.activeAccount?.id,
                                  onChanged: (value) {
                                    if (value != null) {
                                      context.read<AccountBloc>().add(
                                        SetActiveAccount(value),
                                      );
                                      Navigator.pop(context);
                                    }
                                  },
                                  activeColor: AppColors.primary,
                                ),
                                onTap: () {
                                  context.read<AccountBloc>().add(
                                    SetActiveAccount(account.id),
                                  );
                                  Navigator.pop(context);
                                },
                                tileColor:
                                    isActive
                                        ? AppColors.primary.withOpacity(0.1)
                                        : null,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.r),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ] else ...[
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.all(20.w),
                          child: Center(child: CircularProgressIndicator()),
                        ),
                      ),
                    ],

                    SizedBox(height: MediaQuery.of(context).padding.bottom),
                  ],
                ),
              );
            },
          ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
