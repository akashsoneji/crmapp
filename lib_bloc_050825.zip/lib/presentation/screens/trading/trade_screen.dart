import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:pipze/core/constants/color.dart';
import 'package:pipze/core/constants/text_styles.dart';
import 'package:pipze/core/services/language_service.dart';
import 'package:pipze/presentation/widgets/global_drawer.dart';
import 'package:pipze/presentation/widgets/account_header.dart';
import 'package:pipze/presentation/blocs/account/account_bloc.dart';
import 'package:pipze/presentation/blocs/account/account_state.dart';
import 'package:pipze/presentation/blocs/account/account_event.dart';
import 'package:pipze/presentation/screens/trading/close_order_details_screen.dart';
import 'package:pipze/presentation/widgets/trade_details_modal.dart';

// Trade Position Model
class TradePosition {
  final String symbol;
  final String flag;
  final String action; // "Buy" or "Sell"
  final double volume;
  final double profitLoss;
  final String entryPrice;
  final String currentPrice;
  final String accountId;
  final String orderId;
  final bool isFavorite;
  final String openTime;
  final String closeTime;
  final String reason;
  final String orderNo;
  final double commission;
  final double swap;
  final String takeProfit;
  final String stopLoss;

  TradePosition({
    required this.symbol,
    required this.flag,
    required this.action,
    required this.volume,
    required this.profitLoss,
    required this.entryPrice,
    required this.currentPrice,
    required this.accountId,
    required this.orderId,
    this.isFavorite = false,
    this.openTime = '',
    this.closeTime = '',
    this.reason = '',
    this.orderNo = '',
    this.commission = 0.0,
    this.swap = 0.0,
    this.takeProfit = '',
    this.stopLoss = '',
  });
}

// History Entry Model
class HistoryEntry {
  final String type; // "Order Closed" or "Order Opened"
  final String operation; // "Manual operation"
  final double profitLoss;
  final String dateTime;
  final String device;
  final String direction;
  final String openPrice;
  final String volume;
  final bool isExpanded;

  HistoryEntry({
    required this.type,
    required this.operation,
    required this.profitLoss,
    required this.dateTime,
    this.device = '',
    this.direction = '',
    this.openPrice = '',
    this.volume = '',
    this.isExpanded = false,
  });
}

class TradeScreen extends StatefulWidget {
  const TradeScreen({super.key});

  @override
  State<TradeScreen> createState() => _TradeScreenState();
}

class _TradeScreenState extends State<TradeScreen> {
  int _selectedTab = 0; // 0: Market, 1: Pending, 2: Close
  Set<String> _selectedInstruments =
      {}; // Changed to Set for multiple selection
  String _selectedDirection = 'All';

  // Sample trade positions data
  final List<TradePosition> _marketPositions = [
    TradePosition(
      symbol: 'EURUSD',
      flag: '🇪🇺🇺🇸',
      action: 'Sell',
      volume: 0.02,
      profitLoss: -8.56,
      entryPrice: '3425.59',
      currentPrice: '3430.23',
      accountId: '035172384',
      orderId: '1',
      openTime: '01.08.2022, 8:20',
      closeTime: '04.08.2022, 5:10',
      reason: 'Take Profit',
      orderNo: '98547235',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '1.8401',
      stopLoss: '-',
    ),
    TradePosition(
      symbol: 'XAUUSD',
      flag: '🇪🇸🇺🇸',
      action: 'Buy',
      volume: 0.02,
      profitLoss: 44.18,
      entryPrice: '1.17464',
      currentPrice: '17456',
      accountId: '035172384',
      orderId: '2',
      openTime: '01.08.2022, 8:20',
      closeTime: '04.08.2022, 5:10',
      reason: 'Take Profit',
      orderNo: '98547236',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '1.8401',
      stopLoss: '-',
    ),
    TradePosition(
      symbol: 'XAUUSD',
      flag: '🇪🇸🇺🇸',
      action: 'Buy',
      volume: 0.02,
      profitLoss: 44.18,
      entryPrice: '1.17464',
      currentPrice: '17456',
      accountId: '035172384',
      orderId: '3',
      openTime: '01.08.2022, 8:20',
      closeTime: '04.08.2022, 5:10',
      reason: 'Take Profit',
      orderNo: '98547237',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '1.8401',
      stopLoss: '-',
    ),
    TradePosition(
      symbol: 'GBPUSD',
      flag: '🇬🇧🇺🇸',
      action: 'Buy',
      volume: 0.01,
      profitLoss: 12.45,
      entryPrice: '1.2850',
      currentPrice: '1.2865',
      accountId: '035172384',
      orderId: '6',
      openTime: '02.08.2022, 9:15',
      closeTime: '05.08.2022, 6:30',
      reason: 'Take Profit',
      orderNo: '98547240',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '1.2870',
      stopLoss: '-',
    ),
    TradePosition(
      symbol: 'USDJPY',
      flag: '🇺🇸🇯🇵',
      action: 'Sell',
      volume: 0.03,
      profitLoss: -5.20,
      entryPrice: '110.50',
      currentPrice: '110.65',
      accountId: '035172384',
      orderId: '7',
      openTime: '03.08.2022, 10:45',
      closeTime: '06.08.2022, 7:20',
      reason: 'Stop Loss',
      orderNo: '98547241',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '-',
      stopLoss: '110.70',
    ),
    TradePosition(
      symbol: 'AUDUSD',
      flag: '🇦🇺🇺🇸',
      action: 'Buy',
      volume: 0.02,
      profitLoss: 8.90,
      entryPrice: '0.7350',
      currentPrice: '0.7365',
      accountId: '035172384',
      orderId: '8',
      openTime: '04.08.2022, 11:30',
      closeTime: '07.08.2022, 8:45',
      reason: 'Take Profit',
      orderNo: '98547242',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '0.7370',
      stopLoss: '-',
    ),
  ];

  final List<TradePosition> _pendingPositions = [];

  // Get all available instruments from the data
  Set<String> get _availableInstruments {
    Set<String> instruments = {};
    instruments.addAll(_marketPositions.map((p) => p.symbol));
    instruments.addAll(_pendingPositions.map((p) => p.symbol));
    instruments.addAll(_closedPositions.map((p) => p.symbol));
    return instruments;
  }

  final List<TradePosition> _closedPositions = [
    TradePosition(
      symbol: 'EURUSD',
      flag: '🇪🇺🇺🇸',
      action: 'Sell',
      volume: 0.02,
      profitLoss: -8.56,
      entryPrice: '3425.59',
      currentPrice: '3430.23',
      accountId: '035172384',
      orderId: '4',
      openTime: '01.08.2022, 8:20',
      closeTime: '04.08.2022, 5:10',
      reason: 'Take Profit',
      orderNo: '98547238',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '1.8401',
      stopLoss: '-',
    ),
    TradePosition(
      symbol: 'EURUSD',
      flag: '🇪🇺🇺🇸',
      action: 'Buy',
      volume: 0.02,
      profitLoss: -0.18,
      entryPrice: '1.17464',
      currentPrice: '17456',
      accountId: '035172384',
      orderId: '5',
      openTime: '01.08.2022, 8:20',
      closeTime: '04.08.2022, 5:10',
      reason: 'Take Profit',
      orderNo: '98547239',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '1.8401',
      stopLoss: '-',
    ),
    TradePosition(
      symbol: 'XAUUSD',
      flag: '🇪🇸🇺🇸',
      action: 'Buy',
      volume: 0.02,
      profitLoss: 44.18,
      entryPrice: '1.17464',
      currentPrice: '17456',
      accountId: '035172384',
      orderId: '6',
      openTime: '01.08.2022, 8:20',
      closeTime: '04.08.2022, 5:10',
      reason: 'Take Profit',
      orderNo: '98547240',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '1.8401',
      stopLoss: '-',
    ),
    TradePosition(
      symbol: 'GBPUSD',
      flag: '🇬🇧🇺🇸',
      action: 'Sell',
      volume: 0.01,
      profitLoss: -15.30,
      entryPrice: '1.2900',
      currentPrice: '1.2915',
      accountId: '035172384',
      orderId: '9',
      openTime: '05.08.2022, 14:20',
      closeTime: '08.08.2022, 11:35',
      reason: 'Stop Loss',
      orderNo: '98547243',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '-',
      stopLoss: '1.2920',
    ),
    TradePosition(
      symbol: 'USDCAD',
      flag: '🇺🇸🇨🇦',
      action: 'Buy',
      volume: 0.02,
      profitLoss: 6.75,
      entryPrice: '1.2500',
      currentPrice: '1.2515',
      accountId: '035172384',
      orderId: '10',
      openTime: '06.08.2022, 16:45',
      closeTime: '09.08.2022, 13:20',
      reason: 'Take Profit',
      orderNo: '98547244',
      commission: 0.1,
      swap: 0.1,
      takeProfit: '1.2520',
      stopLoss: '-',
    ),
  ];

  // History data
  final List<HistoryEntry> _historyEntries = [
    HistoryEntry(
      type: 'Order Closed',
      operation: 'Manual operation',
      profitLoss: 89.54,
      dateTime: '25 jan 2025 • 12:49',
      device: 'Android',
      direction: 'Sell',
      openPrice: '3,408.65',
      volume: '0.03 lots',
      isExpanded: true,
    ),
    HistoryEntry(
      type: 'Order Closed',
      operation: 'Manual operation',
      profitLoss: -8.56,
      dateTime: '25 jan 2025 • 12:49',
      device: 'Android',
      direction: 'Sell',
      openPrice: '3,408.65',
      volume: '0.03 lots',
      isExpanded: false,
    ),
  ];

  @override
  void initState() {
    super.initState();
    // Ensure accounts are loaded
    context.read<AccountBloc>().add(const LoadAccounts());
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: languageService,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: AppColors.backgroundLight,
          drawer: const GlobalDrawer(),
          body: SafeArea(
            child: Column(
              children: [
                // Header
                _buildHeader(),

                // Title
                _buildTitle(),

                // Tabs
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: _buildTabs(),
                ),

                // Floating Profit/Loss Summary
                _buildFloatingSummary(),

                // Filter Buttons
                _buildFilterButtons(),

                // Trade Positions List
                Expanded(child: _buildPositionsList()),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 400;
    final isLargeScreen = screenWidth > 600;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      child: Row(
        children: [
          // Menu icon
          InkWell(
            onTap: () {
              Scaffold.of(context).openDrawer();
            },
            child: SvgPicture.asset(
              "assets/svg/menu.svg",
              height: 24.h,
              width: 24.w,
            ),
          ),
          SizedBox(width: 6.w),
          // Balance and account info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Dynamic Balance Display
                BlocBuilder<AccountBloc, AccountState>(
                  builder: (context, state) {
                    if (state is AccountLoaded && state.activeAccount != null) {
                      return Text(
                        '\$${state.activeAccount!.balance.toStringAsFixed(2)}',
                        style: AppTextStyles.heading.copyWith(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w700,
                        ),
                      );
                    }
                    return Text(
                      '\$0.00',
                      style: AppTextStyles.heading.copyWith(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w700,
                      ),
                    );
                  },
                ),
                // Account selector
                GestureDetector(
                  onTap: () {
                    context.read<AccountBloc>().add(
                      const ResetToDefaultAccounts(),
                    );
                    _showAccountSelectionBottomSheet(context);
                  },
                  child: BlocBuilder<AccountBloc, AccountState>(
                    builder: (context, state) {
                      return Row(
                        children: [
                          Container(
                            alignment: Alignment.center,
                            width: 45.w,
                            height: 22.h,
                            decoration: BoxDecoration(
                              color: AppColors.accent,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              "REAL",
                              style: TextStyle(
                                color: AppColors.textPrimary,
                                fontSize: 10.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          SizedBox(width: 4.w),
                          SizedBox(
                            height: 22.h,
                            width: 75.w,
                            child: Text(
                              '035172384',
                              textAlign: TextAlign.start,
                              style: AppTextStyles.subheading.copyWith(
                                fontSize: 12.sp,
                                color: AppColors.textGrey,
                              ),
                            ),
                          ),
                          Icon(
                            Icons.arrow_drop_down,
                            size: 16.h,
                            color: AppColors.textGrey,
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          // Info and star icons
          SvgPicture.asset(
            "assets/svg/info-circle.svg",
            height: 24.h,
            width: 24.w,
          ),
          SizedBox(width: 8.w),
          Icon(Icons.star_outline, size: 24.h, color: AppColors.textGrey),
          // SvgPicture.asset(
          //   "assets/svg/Like_Icon.svg",
          //   height: 24.h,
          //   width: 24.w,
          // ),
        ],
      ),
    );
  }

  Widget _buildTitle() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 18.w, vertical: 12),
      child: Row(
        children: [
          Text(
            'Trade',
            style: AppTextStyles.heading.copyWith(
              fontSize: 20.sp,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      // margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
      child: Row(
        children: [
          Expanded(child: _buildTab('Market', 0, _getMarketPositionsCount())),
          SizedBox(width: 24.w),
          Expanded(child: _buildTab('Pending', 1, _getPendingPositionsCount())),
          SizedBox(width: 24.w),
          Expanded(child: _buildTab('Close', 2, _getClosedPositionsCount())),
        ],
      ),
    );
  }

  Widget _buildTab(String title, int index, int count) {
    final isSelected = _selectedTab == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedTab = index;
        });
      },
      child: Column(
        spacing: 0,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                title,
                style: AppTextStyles.input.copyWith(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                  color:
                      isSelected ? AppColors.textPrimary : AppColors.textGrey,
                ),
              ),
              if (count > 0) ...[
                SizedBox(width: 8.w),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withAlpha(10),
                    borderRadius: BorderRadius.circular(5.r),
                  ),
                  child: Text(
                    count.toString(),
                    style: AppTextStyles.label.copyWith(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w500,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ],
            ],
          ),
          SizedBox(height: 10.h),
          Container(
            width: double.infinity,
            height: 3.h,
            padding: EdgeInsets.zero,
            decoration: BoxDecoration(
              color: isSelected ? AppColors.primary : Colors.transparent,
              borderRadius: BorderRadius.circular(2.r),
            ),
          ),
        ],
      ),
    );
  }

  int _getMarketPositionsCount() {
    return _marketPositions.length;
  }

  int _getPendingPositionsCount() {
    return _pendingPositions.length;
  }

  int _getClosedPositionsCount() {
    return _closedPositions.length;
  }

  Widget _buildFloatingSummary() {
    final totalProfitLoss = _marketPositions.fold<double>(
      0.0,
      (sum, position) => sum + position.profitLoss,
    );

    return Container(
      margin: EdgeInsets.symmetric(
        horizontal: 16.w,
        vertical: 24.h,
      ).copyWith(bottom: 0),
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        // color: AppColors.primary.withOpacity(0.1),
        color: Color(0xffFBF5FF),
        borderRadius: BorderRadius.circular(12.r),
        // border: Border.all(color: AppColors.primary.withOpacity(0.3), width: 1),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Floating profit: \n\$${totalProfitLoss.toStringAsFixed(2)}',
              style: AppTextStyles.input.copyWith(
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
                color: totalProfitLoss >= 0 ? AppColors.success : AppColors.red,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              _showCloseAllDialog();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xffFBF5FF),
              foregroundColor: Color(0xffFBF5FF),
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.r),
              ),
            ),
            child: Text(
              'Close all',
              style: AppTextStyles.label.copyWith(
                fontSize: 14.sp,
                color: AppColors.primary,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterButtons() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
      child: Row(
        children: [
          _buildFilterButton(
            icon: Icons.sort_by_alpha,
            icon2: 'assets/svg/descending.svg',
            isSVG: true,
            label: '',
            onTap: () => _showSortDialog(),
          ),
          SizedBox(width: 12.w),
          _buildFilterButton(
            icon2: '',
            isSVG: false,
            icon: Icons.keyboard_arrow_down,
            label:
                _selectedInstruments.isEmpty
                    ? 'Instrument'
                    : 'Instrument (${_selectedInstruments.length})',
            onTap: () => _showInstrumentFilter(),
          ),
          SizedBox(width: 12.w),
          _buildFilterButton(
            icon2: '',
            isSVG: false,
            icon: Icons.keyboard_arrow_down,
            label:
                _selectedDirection == 'All' ? 'Direction' : _selectedDirection,
            onTap: () => _showDirectionFilter(),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterButton({
    required IconData icon,
    required String icon2,
    required bool isSVG,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
        decoration: BoxDecoration(
          color: AppColors.cardBackGround,
          borderRadius: BorderRadius.circular(5.r),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (label.isNotEmpty) ...[
              SizedBox(width: 4.w),
              Text(
                label,
                style: AppTextStyles.label.copyWith(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w400,
                  color: AppColors.textPrimary,
                ),
              ),
              SizedBox(width: 4.w),
            ],
            if (isSVG)
              SvgPicture.asset(icon2, height: 20.h, width: 20.w)
            else
              Icon(icon, size: 20.h, color: AppColors.textGrey),
          ],
        ),
      ),
    );
  }

  Widget _buildPositionsList() {
    List<TradePosition> positions = [];

    switch (_selectedTab) {
      case 0:
        positions = _marketPositions;
        break;
      case 1:
        positions = _pendingPositions;
        break;
      case 2:
        positions = _closedPositions;
        break;
    }

    // Filter positions based on selected instruments
    if (_selectedInstruments.isNotEmpty) {
      positions =
          positions
              .where(
                (position) => _selectedInstruments.contains(position.symbol),
              )
              .toList();
    }

    // Filter positions based on selected direction
    if (_selectedDirection != 'All') {
      positions =
          positions
              .where((position) => position.action == _selectedDirection)
              .toList();
    }

    if (positions.isEmpty) {
      if (_selectedTab == 1) {
        // Show pending orders empty state
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Illustration placeholder
              Container(
                width: 120.w,
                height: 120.h,
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(60.r),
                ),
                child: Icon(
                  Icons.pending_actions,
                  size: 60.h,
                  color: AppColors.primary,
                ),
              ),
              SizedBox(height: 24.h),
              Text(
                'You have no pending orders',
                style: AppTextStyles.subheading.copyWith(
                  color: AppColors.textGrey,
                  fontSize: 16.sp,
                ),
              ),
              SizedBox(height: 32.h),
              ElevatedButton(
                onPressed: () {
                  // Navigate to new order screen
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: AppColors.primary,
                  padding: EdgeInsets.symmetric(
                    horizontal: 32.w,
                    vertical: 16.h,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.r),
                    side: BorderSide(color: AppColors.primary),
                  ),
                ),
                child: Text(
                  'New Order',
                  style: AppTextStyles.button.copyWith(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        );
      }
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_outlined, size: 64.h, color: AppColors.textGrey),
            SizedBox(height: 16.h),
            Text(
              'No ${_getTabTitle(_selectedTab)} positions',
              style: AppTextStyles.subheading.copyWith(
                color: AppColors.textGrey,
                fontSize: 16.sp,
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 4.h),
      itemCount: positions.length,
      itemBuilder: (context, index) {
        final position = positions[index];
        return _buildPositionItem(position);
      },
    );
  }

  Widget _buildPositionItem(TradePosition position) {
    return Dismissible(
      key: Key(position.orderId),
      direction: DismissDirection.endToStart,
      background: Container(
        width: MediaQuery.of(context).size.width * 0.3,
        margin: EdgeInsets.only(bottom: 6.h),
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        decoration: BoxDecoration(
          color: AppColors.red,
          borderRadius: BorderRadius.circular(6.r),
        ),
        child: Container(
          width: 100.w,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(Icons.close, color: Colors.white, size: 18.h),
              SizedBox(width: 6.w),
              Text(
                'Close',
                style: AppTextStyles.label.copyWith(
                  color: Colors.white,
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
      confirmDismiss: (direction) async {
        _closePosition(position);
        return false; // Don't dismiss automatically, let the close function handle it
      },
      child: GestureDetector(
        onTap: () {
          if (_selectedTab == 2) {
            // For closed positions, show close order details
            _showCloseOrderDetails(position);
          } else {
            // For market/pending positions, show trade details
            _showTradeDetails(position);
          }
        },
        child: Container(
          margin: EdgeInsets.only(bottom: 6.h),
          padding: EdgeInsets.all(10.w),
          decoration: BoxDecoration(
            color: Colors.white,
            // borderRadius: BorderRadius.circular(6.r),
            border: Border(bottom: BorderSide(color: AppColors.border)),
            // boxShadow: [
            //   BoxShadow(
            //     color: Colors.black.withOpacity(0.04),
            //     blurRadius: 3,
            //     offset: const Offset(0, 1),
            //   ),
            // ],
          ),
          child: Row(
            children: [
              // Left side: Flag and Symbol
              Expanded(
                flex: 3,
                child: Row(
                  children: [
                    // Flag container
                    Container(
                      width: 28.w,
                      height: 18.h,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(3.r),
                        border: Border.all(
                          color: AppColors.border.withOpacity(0.2),
                          width: 0.5,
                        ),
                      ),
                      child: Stack(
                        children: [
                          // First flag (left)
                          Positioned(
                            left: 1,
                            top: 0,
                            child: Text(
                              _getFirstFlag(position.flag),
                              style: TextStyle(
                                fontSize: 10.sp,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                          // Second flag (right, slightly overlapping)
                          Positioned(
                            right: 1,
                            top: 0,
                            child: Text(
                              _getSecondFlag(position.flag),
                              style: TextStyle(
                                fontSize: 10.sp,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 6.w),
                    // Symbol
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            position.symbol,
                            style: AppTextStyles.input.copyWith(
                              fontWeight: FontWeight.w600,
                              fontSize: 13.sp,
                              color: AppColors.textPrimary,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                position.action,
                                style: AppTextStyles.label.copyWith(
                                  fontSize: 11.sp,
                                  fontWeight: FontWeight.w600,
                                  color:
                                      position.action == 'Buy'
                                          ? AppColors.success
                                          : AppColors.red,
                                ),
                              ),
                              SizedBox(height: 1.h),
                              Text(
                                position.volume.toStringAsFixed(2),
                                style: AppTextStyles.subheading.copyWith(
                                  fontSize: 10.sp,
                                  color: AppColors.textGrey,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // Right side: Profit/Loss and Close button
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '\$${position.profitLoss.toStringAsFixed(2)}',
                      style: AppTextStyles.input.copyWith(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.w700,
                        color:
                            position.profitLoss >= 0
                                ? AppColors.success
                                : AppColors.red,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      '${position.entryPrice} → ${position.currentPrice}',
                      style: AppTextStyles.subheading.copyWith(
                        fontSize: 9.sp,
                        color: AppColors.textGrey,
                        fontWeight: FontWeight.w400,
                      ),
                      textAlign: TextAlign.end,
                    ),
                    // Close button (only for market positions)
                    // if (_selectedTab == 0) ...[
                    //   SizedBox(height: 4.h),
                    //   Container(
                    //     padding: EdgeInsets.symmetric(
                    //       horizontal: 8.w,
                    //       vertical: 2.h,
                    //     ),
                    //     decoration: BoxDecoration(
                    //       color: AppColors.red.withOpacity(0.08),
                    //       borderRadius: BorderRadius.circular(3.r),
                    //       border: Border.all(
                    //         color: AppColors.red.withOpacity(0.2),
                    //         width: 0.5,
                    //       ),
                    //     ),
                    //     child: Row(
                    //       mainAxisSize: MainAxisSize.min,
                    //       children: [
                    //         Icon(Icons.close, size: 10.h, color: AppColors.red),
                    //         SizedBox(width: 2.w),
                    //         Text(
                    //           'Close',
                    //           style: AppTextStyles.label.copyWith(
                    //             fontSize: 9.sp,
                    //             fontWeight: FontWeight.w600,
                    //             color: AppColors.red,
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getTabTitle(int tabIndex) {
    switch (tabIndex) {
      case 0:
        return 'Market';
      case 1:
        return 'Pending';
      case 2:
        return 'Closed';
      default:
        return '';
    }
  }

  String _getFirstFlag(String flag) {
    if (flag.length >= 4) {
      return flag.substring(0, 2);
    }
    return flag;
  }

  String _getSecondFlag(String flag) {
    if (flag.length >= 4) {
      return flag.substring(2, 4);
    }
    return '';
  }

  void _showCloseAllDialog() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Close All Positions'),
            content: Text('Are you sure you want to close all open positions?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    _marketPositions.clear();
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.red,
                  foregroundColor: Colors.white,
                ),
                child: Text('Close All'),
              ),
            ],
          ),
    );
  }

  void _closePosition(TradePosition position) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Close Position'),
            content: Text(
              'Are you sure you want to close ${position.symbol} position?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    _marketPositions.removeWhere(
                      (p) => p.orderId == position.orderId,
                    );
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.red,
                  foregroundColor: Colors.white,
                ),
                child: Text('Close'),
              ),
            ],
          ),
    );
  }

  void _showDirectionFilter() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (context) => StatefulBuilder(
            builder:
                (context, setModalState) => Container(
                  height: MediaQuery.of(context).size.height * 0.4,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20.r),
                      topRight: Radius.circular(20.r),
                    ),
                  ),
                  child: Column(
                    children: [
                      // Handle bar
                      Container(
                        margin: EdgeInsets.only(top: 12.h),
                        width: 40.w,
                        height: 4.h,
                        decoration: BoxDecoration(
                          color: AppColors.grey,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),

                      // Title
                      Padding(
                        padding: EdgeInsets.all(16.w),
                        child: Text(
                          'Direction',
                          style: AppTextStyles.heading.copyWith(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),

                      // Options
                      Expanded(
                        child: ListView(
                          padding: EdgeInsets.symmetric(horizontal: 16.w),
                          children: [
                            _buildDirectionOption('All', 'All'),
                            _buildDirectionOption('Buy', 'Buy'),
                            _buildDirectionOption('Sell', 'Sell'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
          ),
    );
  }

  Widget _buildDirectionOption(
    String title,
    String value, [
    StateSetter? setModalState,
  ]) {
    final isSelected = _selectedDirection == value;
    return ListTile(
      title: Text(
        title,
        style: AppTextStyles.input.copyWith(
          fontSize: 16.sp,
          fontWeight: FontWeight.w500,
          color: isSelected ? AppColors.primary : AppColors.textPrimary,
        ),
      ),
      trailing:
          isSelected
              ? Icon(Icons.check, color: AppColors.primary, size: 20.h)
              : null,
      onTap: () {
        setState(() {
          _selectedDirection = value;
        });
        // Update the modal UI immediately
        if (setModalState != null) {
          setModalState(() {});
        }
        Navigator.pop(context);
      },
    );
  }

  void _showSortDialog() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Sort by'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  title: Text('Profit/Loss'),
                  onTap: () {
                    Navigator.pop(context);
                    // Implement sort by profit/loss
                  },
                ),
                ListTile(
                  title: Text('Symbol'),
                  onTap: () {
                    Navigator.pop(context);
                    // Implement sort by symbol
                  },
                ),
                ListTile(
                  title: Text('Volume'),
                  onTap: () {
                    Navigator.pop(context);
                    // Implement sort by volume
                  },
                ),
              ],
            ),
          ),
    );
  }

  void _showInstrumentFilter() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (context) => StatefulBuilder(
            builder:
                (context, setModalState) => Container(
                  height: MediaQuery.of(context).size.height * 0.4,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20.r),
                      topRight: Radius.circular(20.r),
                    ),
                  ),
                  child: Column(
                    children: [
                      // Handle bar
                      Container(
                        margin: EdgeInsets.only(top: 12.h),
                        width: 40.w,
                        height: 4.h,
                        decoration: BoxDecoration(
                          color: AppColors.grey,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),

                      // Title
                      Padding(
                        padding: EdgeInsets.all(16.w),
                        child: Text(
                          'Instrument',
                          style: AppTextStyles.heading.copyWith(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),

                      // Instruments list
                      Expanded(
                        child: ListView(
                          padding: EdgeInsets.symmetric(horizontal: 16.w),
                          children: [
                            ..._availableInstruments
                                .map(
                                  (instrument) => _buildInstrumentOption(
                                    instrument,
                                    instrument,
                                    setModalState,
                                  ),
                                )
                                .toList(),
                          ],
                        ),
                      ),

                      // Confirm button
                      Padding(
                        padding: EdgeInsets.all(16.w),
                        child: SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primary,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(vertical: 16.h),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.r),
                              ),
                            ),
                            child: Text(
                              'Confirm',
                              style: AppTextStyles.button.copyWith(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: MediaQuery.of(context).padding.bottom),
                    ],
                  ),
                ),
          ),
    );
  }

  Widget _buildInstrumentOption(
    String title,
    String value, [
    StateSetter? setModalState,
  ]) {
    final isSelected = _selectedInstruments.contains(value);
    return CheckboxListTile(
      title: Text(
        title,
        style: AppTextStyles.input.copyWith(
          fontSize: 16.sp,
          fontWeight: FontWeight.w500,
          color: isSelected ? AppColors.primary : AppColors.textPrimary,
        ),
      ),
      value: isSelected,
      onChanged: (bool? newValue) {
        setState(() {
          if (newValue!) {
            _selectedInstruments.add(value);
          } else {
            _selectedInstruments.remove(value);
          }
        });
        // Update the modal UI immediately
        if (setModalState != null) {
          setModalState(() {});
        }
      },
      activeColor: AppColors.primary,
      checkColor: Colors.white,
      controlAffinity: ListTileControlAffinity.leading,
    );
  }

  void _showCloseOrderDetails(TradePosition position) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CloseOrderDetailsScreen(position: position),
      ),
    );
  }

  // Trade Details Modal Like on ListTile we tap open dilog with option like close position, modify position, new order, chart
  void _showTradeDetails(TradePosition position) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => TradeDetailsModal(position: position),
    );
  }

  void _showAccountSelectionBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (context) => BlocBuilder<AccountBloc, AccountState>(
            builder: (context, state) {
              double dynamicHeight;
              if (state is AccountLoaded) {
                if (state.accounts.length <= 2) {
                  dynamicHeight = MediaQuery.of(context).size.height * 0.35;
                } else if (state.accounts.length <= 3) {
                  dynamicHeight = MediaQuery.of(context).size.height * 0.45;
                } else if (state.accounts.length <= 4) {
                  dynamicHeight = MediaQuery.of(context).size.height * 0.55;
                } else {
                  dynamicHeight = MediaQuery.of(context).size.height * 0.65;
                }
              } else {
                dynamicHeight = MediaQuery.of(context).size.height * 0.3;
              }

              return Container(
                height: dynamicHeight,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20.r),
                    topRight: Radius.circular(20.r),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 12.h),
                      width: 40.w,
                      height: 4.h,
                      decoration: BoxDecoration(
                        color: AppColors.grey,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Select Account',
                            style: AppTextStyles.heading.copyWith(
                              fontSize: 18.sp,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          IconButton(
                            onPressed: () => Navigator.pop(context),
                            icon: Icon(Icons.close, color: AppColors.textGrey),
                          ),
                        ],
                      ),
                    ),
                    if (state is AccountLoaded) ...[
                      Expanded(
                        child: ListView.builder(
                          padding: EdgeInsets.zero,
                          itemCount: state.accounts.length,
                          itemBuilder: (context, index) {
                            final account = state.accounts[index];
                            final isActive =
                                state.activeAccount?.id == account.id;
                            return Container(
                              child: ListTile(
                                leading: Container(
                                  padding: EdgeInsets.all(8.w),
                                  decoration: BoxDecoration(
                                    color:
                                        account.type == 'REAL'
                                            ? AppColors.primary
                                            : AppColors.success,
                                    borderRadius: BorderRadius.circular(8.r),
                                  ),
                                  child: Icon(
                                    Icons.account_balance_wallet,
                                    color: Colors.white,
                                    size: 20.h,
                                  ),
                                ),
                                title: Row(
                                  children: [
                                    Text(
                                      account.type,
                                      style: AppTextStyles.label.copyWith(
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                    if (isActive) ...[
                                      SizedBox(width: 8.w),
                                      Container(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 6.w,
                                          vertical: 2.h,
                                        ),
                                        decoration: BoxDecoration(
                                          color: AppColors.success,
                                          borderRadius: BorderRadius.circular(
                                            8.r,
                                          ),
                                        ),
                                        child: Text(
                                          'ACTIVE',
                                          style: AppTextStyles.label.copyWith(
                                            fontSize: 8.sp,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'ID: ${account.id}',
                                      style: AppTextStyles.label.copyWith(
                                        fontSize: 12.sp,
                                        color: AppColors.textGrey,
                                      ),
                                    ),
                                    Text(
                                      '\$${account.balance.toStringAsFixed(2)}',
                                      style: AppTextStyles.label.copyWith(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                  ],
                                ),
                                trailing: Radio<String>(
                                  value: account.id,
                                  groupValue: state.activeAccount?.id,
                                  onChanged: (value) {
                                    if (value != null) {
                                      context.read<AccountBloc>().add(
                                        SetActiveAccount(value),
                                      );
                                      Navigator.pop(context);
                                    }
                                  },
                                  activeColor: AppColors.primary,
                                ),
                                onTap: () {
                                  context.read<AccountBloc>().add(
                                    SetActiveAccount(account.id),
                                  );
                                  Navigator.pop(context);
                                },
                                tileColor:
                                    isActive
                                        ? AppColors.primary.withOpacity(0.1)
                                        : null,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.r),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ] else ...[
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.all(20.w),
                          child: Center(child: CircularProgressIndicator()),
                        ),
                      ),
                    ],
                    SizedBox(height: MediaQuery.of(context).padding.bottom),
                  ],
                ),
              );
            },
          ),
    );
  }
}
