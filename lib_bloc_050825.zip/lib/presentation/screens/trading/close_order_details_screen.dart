import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pipze/core/constants/color.dart';
import 'package:pipze/core/constants/text_styles.dart';
import 'package:pipze/presentation/screens/trading/trade_screen.dart';
import 'package:pipze/presentation/screens/trading/history_screen.dart';

class CloseOrderDetailsScreen extends StatelessWidget {
  final TradePosition position;

  const CloseOrderDetailsScreen({super.key, required this.position});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Close Order',
          style: AppTextStyles.heading.copyWith(
            fontSize: 18.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Instrument Information
            _buildInstrumentInfo(),
            SizedBox(height: 24.h),
            
            // Order Details
            _buildOrderDetails(),
            SizedBox(height: 32.h),
            
            // History Button
            _buildHistoryButton(context),
          ],
        ),
      ),
    );
  }

  Widget _buildInstrumentInfo() {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: AppColors.border.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          // Flag and Symbol
          Row(
            children: [
              Container(
                width: 40.w,
                height: 24.h,
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      child: Text(
                        _getFirstFlag(position.flag),
                        style: TextStyle(fontSize: 16.sp),
                      ),
                    ),
                    Positioned(
                      right: 0,
                      child: Text(
                        _getSecondFlag(position.flag),
                        style: TextStyle(fontSize: 16.sp),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 12.w),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    position.symbol,
                    style: AppTextStyles.input.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 16.sp,
                    ),
                  ),
                  Text(
                    '${position.action} ${position.volume.toStringAsFixed(2)}',
                    style: AppTextStyles.subheading.copyWith(
                      fontSize: 12.sp,
                      color: position.action == 'Buy' ? AppColors.success : AppColors.red,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const Spacer(),
          // Profit/Loss
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '\$${position.profitLoss.toStringAsFixed(2)}',
                style: AppTextStyles.input.copyWith(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w700,
                  color: position.profitLoss >= 0 ? AppColors.success : AppColors.red,
                ),
              ),
              Text(
                '${position.entryPrice} → ${position.currentPrice}',
                style: AppTextStyles.subheading.copyWith(
                  fontSize: 12.sp,
                  color: AppColors.textGrey,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOrderDetails() {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: AppColors.border.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          _buildDetailRow('Open Time', position.openTime),
          _buildDetailRow('Close Time', position.closeTime),
          _buildDetailRow('Reason', position.reason),
          _buildDetailRow('Order No.', position.orderNo),
          _buildDetailRow('Commission', '\$${position.commission.toStringAsFixed(1)}'),
          _buildDetailRow('Swap', '\$${position.swap.toStringAsFixed(1)}'),
          _buildDetailRow('TP', position.takeProfit),
          _buildDetailRow('SL', position.stopLoss),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: AppTextStyles.subheading.copyWith(
              fontSize: 14.sp,
              color: AppColors.textGrey,
            ),
          ),
          Text(
            value,
            style: AppTextStyles.input.copyWith(
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => HistoryScreen(),
            ),
          );
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: AppColors.primary,
          padding: EdgeInsets.symmetric(vertical: 16.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
            side: BorderSide(color: AppColors.primary),
          ),
        ),
        child: Text(
          'History',
          style: AppTextStyles.button.copyWith(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  String _getFirstFlag(String flag) {
    if (flag.length >= 4) {
      return flag.substring(0, 2);
    }
    return flag;
  }

  String _getSecondFlag(String flag) {
    if (flag.length >= 4) {
      return flag.substring(2, 4);
    }
    return '';
  }
} 