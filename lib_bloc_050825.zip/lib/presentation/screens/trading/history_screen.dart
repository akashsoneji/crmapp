import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pipze/core/constants/color.dart';
import 'package:pipze/core/constants/text_styles.dart';
import 'package:pipze/presentation/screens/trading/trade_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  // Sample history data
  final List<HistoryEntry> _historyEntries = [
    HistoryEntry(
      type: 'Order Closed',
      operation: 'Manual operation',
      profitLoss: 89.54,
      dateTime: '25 jan 2025 • 12:49',
      device: 'Android',
      direction: 'Sell',
      openPrice: '3,408.65',
      volume: '0.03 lots',
      isExpanded: true,
    ),
    HistoryEntry(
      type: 'Order Closed',
      operation: 'Manual operation',
      profitLoss: -8.56,
      dateTime: '25 jan 2025 • 12:49',
      device: 'Android',
      direction: 'Sell',
      openPrice: '3,408.65',
      volume: '0.03 lots',
      isExpanded: false,
    ),
    HistoryEntry(
      type: 'Order Opened',
      operation: 'Manual operation',
      profitLoss: 0.0,
      dateTime: '25 jan 2025 • 12:49',
      device: 'Android',
      direction: 'Sell',
      openPrice: '3,408.65',
      volume: '0.03 lots',
      isExpanded: false,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'History',
          style: AppTextStyles.heading.copyWith(
            fontSize: 18.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16.w),
        itemCount: _historyEntries.length,
        itemBuilder: (context, index) {
          final entry = _historyEntries[index];
          return _buildHistoryItem(entry, index);
        },
      ),
    );
  }

  Widget _buildHistoryItem(HistoryEntry entry, int index) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: AppColors.border.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          // Main entry row
          ListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
            title: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        entry.type,
                        style: AppTextStyles.input.copyWith(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        entry.operation,
                        style: AppTextStyles.subheading.copyWith(
                          fontSize: 12.sp,
                          color: AppColors.textGrey,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (entry.profitLoss != 0.0)
                      Text(
                        entry.profitLoss > 0 ? '+ \$${entry.profitLoss.toStringAsFixed(2)}' : '\$${entry.profitLoss.toStringAsFixed(2)}',
                        style: AppTextStyles.input.copyWith(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                          color: entry.profitLoss >= 0 ? AppColors.success : AppColors.red,
                        ),
                      ),
                    Text(
                      entry.dateTime,
                      style: AppTextStyles.subheading.copyWith(
                        fontSize: 12.sp,
                        color: AppColors.textGrey,
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 8.w),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _historyEntries[index] = HistoryEntry(
                        type: entry.type,
                        operation: entry.operation,
                        profitLoss: entry.profitLoss,
                        dateTime: entry.dateTime,
                        device: entry.device,
                        direction: entry.direction,
                        openPrice: entry.openPrice,
                        volume: entry.volume,
                        isExpanded: !entry.isExpanded,
                      );
                    });
                  },
                  child: Icon(
                    entry.isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                    color: AppColors.textGrey,
                    size: 20.h,
                  ),
                ),
              ],
            ),
          ),
          
          // Expanded details
          if (entry.isExpanded) ...[
            Divider(height: 1.h, color: AppColors.border.withOpacity(0.3)),
            Padding(
              padding: EdgeInsets.all(16.w),
              child: Column(
                children: [
                  _buildDetailRow('Device', entry.device),
                  _buildDetailRow('Direction', entry.direction),
                  _buildDetailRow('Open Price', entry.openPrice),
                  _buildDetailRow('Volume', entry.volume),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: AppTextStyles.subheading.copyWith(
              fontSize: 14.sp,
              color: AppColors.textGrey,
            ),
          ),
          Text(
            value,
            style: AppTextStyles.input.copyWith(
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
} 