import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/constants/color.dart';
import '../../../core/constants/text_styles.dart';
import '../../../core/services/toast_service.dart';
import '../../widgets/custom_toast.dart';

class ToastDemoScreen extends StatelessWidget {
  const ToastDemoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Custom Toast Demo',
          style: AppTextStyles.heading.copyWith(color: Colors.white),
        ),
        backgroundColor: AppColors.primary,
        elevation: 0,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(height: 20.h),

            // Success Toast
            _buildToastButton(
              title: 'Success Toast',
              subtitle: 'Shows a green success message',
              icon: Icons.check_circle,
              color: AppColors.success,
              onTap: () {
                ContextToastService.showSuccess(
                  context,
                  'Operation completed successfully!',
                  duration: const Duration(seconds: 3),
                );
              },
            ),

            SizedBox(height: 16.h),

            // Error Toast
            _buildToastButton(
              title: 'Error Toast',
              subtitle: 'Shows a red error message',
              icon: Icons.error,
              color: AppColors.error,
              onTap: () {
                ContextToastService.showError(
                  context,
                  'Something went wrong. Please try again.',
                  duration: const Duration(seconds: 4),
                );
              },
            ),

            SizedBox(height: 16.h),

            // Warning Toast
            _buildToastButton(
              title: 'Warning Toast',
              subtitle: 'Shows an orange warning message',
              icon: Icons.warning,
              color: AppColors.warning,
              onTap: () {
                ContextToastService.showWarning(
                  context,
                  'Please check your input before proceeding.',
                  duration: const Duration(seconds: 3),
                );
              },
            ),

            SizedBox(height: 16.h),

            // Info Toast
            _buildToastButton(
              title: 'Info Toast',
              subtitle: 'Shows a blue info message',
              icon: Icons.info,
              color: AppColors.primary,
              onTap: () {
                ContextToastService.showInfo(
                  context,
                  'This is an informational message for you.',
                  duration: const Duration(seconds: 3),
                );
              },
            ),

            SizedBox(height: 16.h),

            // Custom Duration Toast
            _buildToastButton(
              title: 'Long Duration Toast',
              subtitle: 'Shows for 6 seconds',
              icon: Icons.timer,
              color: AppColors.accent,
              onTap: () {
                ContextToastService.showToast(
                  context: context,
                  message: 'This toast will stay visible for 6 seconds',
                  // type: ,
                  duration: const Duration(seconds: 6),
                );
              },
            ),

            SizedBox(height: 16.h),

            // Multiple Toasts
            _buildToastButton(
              title: 'Multiple Toasts',
              subtitle: 'Shows multiple toasts in queue',
              icon: Icons.queue,
              color: AppColors.textGrey,
              onTap: () {
                ContextToastService.showSuccess(
                  context,
                  'First toast - Success!',
                );
                Future.delayed(const Duration(milliseconds: 500), () {
                  ContextToastService.showError(
                    context,
                    'Second toast - Error!',
                  );
                });
                Future.delayed(const Duration(milliseconds: 1000), () {
                  ContextToastService.showWarning(
                    context,
                    'Third toast - Warning!',
                  );
                });
                Future.delayed(const Duration(milliseconds: 1500), () {
                  ContextToastService.showInfo(context, 'Fourth toast - Info!');
                });
              },
            ),

            const Spacer(),

            // Instructions
            Container(
              padding: EdgeInsets.all(16.w),
              decoration: BoxDecoration(
                color: AppColors.secondary,
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'How to use:',
                    style: AppTextStyles.label.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    '• Tap any button to show a custom toast\n'
                    '• Toasts slide down from top with smooth animation\n'
                    '• They wait for the specified duration\n'
                    '• Then slide back up automatically\n'
                    '• You can also tap the X to dismiss manually\n'
                    '• Multiple toasts are queued automatically',
                    style: AppTextStyles.subheading.copyWith(
                      fontSize: 12.sp,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToastButton({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12.r),
          child: Padding(
            padding: EdgeInsets.all(16.w),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Icon(icon, color: color, size: 24.sp),
                ),
                SizedBox(width: 16.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: AppTextStyles.label.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        subtitle,
                        style: AppTextStyles.subheading.copyWith(
                          fontSize: 12.sp,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: AppColors.textGrey,
                  size: 16.sp,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
