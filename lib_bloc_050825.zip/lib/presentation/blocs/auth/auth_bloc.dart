import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pipze/data/repositories/auth_repository.dart';
import 'package:pipze/core/services/secure_storage_service.dart';
import 'dart:convert';
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepository;

  AuthBloc({required this.authRepository}) : super(AuthInitial()) {
    on<LoginRequested>(_onLoginRequested);
    on<SendOTPRequested>(_onSendOTPRequested);
    on<VerifyOTPRequested>(_onVerifyOTPRequested);
    on<ResetPasswordRequested>(_onResetPasswordRequested);
    on<ResendOTPRequested>(_onResendOTPRequested);
    on<RegisterRequested>(_onRegisterRequested);
    on<ResetAuthState>(_onResetAuthState);
    on<LogoutRequested>(_onLogoutRequested);
    on<CheckAuthStatus>(_onCheckAuthStatus);
  }

  Future<void> _onLoginRequested(
    LoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final response = await authRepository.login(
        email: event.email,
        password: event.password,
      );

      print("object of_onLoginRequested ${response.data}");
      print("object of_onLoginRequested ${response.data?.data.token}");
      print("object of_onLoginRequested ${response.data?.data.websocketToken}");
      print("object of_onLoginRequested ${response.data?.data.user.toJson()}");

      if (response.success) {
        // Save login data to secure storage
        try {
          await SecureStorageService.saveLoginData(
            authToken: response.data!.data.token,
            websocketToken: response.data!.data.websocketToken,
            userData: jsonEncode(response.data!.data.user.toJson()),
          );
          print('AuthBloc: Login data saved to secure storage successfully');
        } catch (e) {
          print('AuthBloc: Error saving login data to secure storage: $e');
          // Continue with login even if storage fails
        }

        emit(LoginSuccess(response.data!));
      } else {
        emit(AuthError(response.message ?? 'Login failed'));
      }
    } catch (e, t) {
      print('object of_onLoginRequested ${e.toString()}');
      print('object of_onLoginRequested ${t.toString()}');
      emit(AuthError("Login failed: ${e.toString()}"));
    }
  }

  Future<void> _onSendOTPRequested(
    SendOTPRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final response = await authRepository.sendOTP(email: event.email);

      if (response.success) {
        emit(OTPSent(event.email,response.message!));
      } else {
        emit(AuthError(response.message ?? 'Failed to send OTP'));
      }
    } catch (e) {
      emit(AuthError('Failed to send OTP: ${e.toString()}'));
    }
  }

  Future<void> _onVerifyOTPRequested(
    VerifyOTPRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final response = await authRepository.verifyOTP(
        email: event.email,
        otp: event.otp,
      );

      if (response.success) {
        emit(OTPVerified(email: event.email, otp: event.otp));
      } else {
        emit(AuthError(response.message ?? 'Failed to verify OTP'));
      }
    } catch (e) {
      emit(AuthError('Failed to verify OTP: ${e.toString()}'));
    }
  }

  Future<void> _onResetPasswordRequested(
    ResetPasswordRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final response = await authRepository.resetPassword(
        email: event.email,
        otp: event.otp,
        newPassword: event.newPassword,
      );

      if (response.success) {
        emit(PasswordResetSuccess());
      } else {
        emit(AuthError(response.message ?? 'Failed to reset password'));
      }
    } catch (e) {
      emit(AuthError('Failed to reset password: ${e.toString()}'));
    }
  }

  Future<void> _onResendOTPRequested(
    ResendOTPRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final response = await authRepository.sendOTP(email: event.email);
      if (response.success) {
        emit(OTPSent(event.email,event.message));
      } else {
        emit(AuthError(response.message ?? 'Failed to resend OTP'));
      }
    } catch (e) {
      emit(AuthError('Failed to resend OTP: ${e.toString()}'));
    }
  }

  Future<void> _onRegisterRequested(
    RegisterRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final response = await authRepository.register(
        firstName: event.firstName,
        lastName: event.lastName,
        email: event.email,
        password: event.password,
        mobile: event.mobile,
        otp: event.otp,
        registerEventType: event.registerEventType,
        acceptTerms: event.acceptTerms,
      );

      if (response.success) {
        emit(RegisterSuccess(response.data!));
      } else {
        emit(AuthError(response.message ?? 'Registration failed'));
      }
    } catch (e) {
      emit(AuthError('Registration failed: ${e.toString()}'));
    }
  }

  Future<void> _onLogoutRequested(
    LogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      // Clear all authentication data from secure storage
      await SecureStorageService.clearAuthData();
      print('AuthBloc: Logout successful, auth data cleared');
      emit(AuthInitial());
    } catch (e) {
      print('AuthBloc: Error during logout: $e');
      emit(AuthError('Logout failed: ${e.toString()}'));
    }
  }

  Future<void> _onCheckAuthStatus(
    CheckAuthStatus event,
    Emitter<AuthState> emit,
  ) async {
    try {
      final isLoggedIn = await SecureStorageService.isUserLoggedIn();
      if (isLoggedIn) {
        // Get stored user data
        final userDataString = await SecureStorageService.getUserData();
        if (userDataString != null) {
          try {
            // final userData = jsonDecode(userDataString);
            // You might want to reconstruct the LoginResponseModel here
            // For now, we'll just emit a logged in state
            emit(AuthLoggedIn());
          } catch (e) {
            print('AuthBloc: Error parsing stored user data: $e');
            emit(AuthInitial());
          }
        } else {
          emit(AuthInitial());
        }
      } else {
        emit(AuthInitial());
      }
    } catch (e) {
      print('AuthBloc: Error checking auth status: $e');
      emit(AuthInitial());
    }
  }

  void _onResetAuthState(ResetAuthState event, Emitter<AuthState> emit) {
    emit(AuthInitial());
  }
}
