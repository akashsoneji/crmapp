import 'package:equatable/equatable.dart';
import 'package:pipze/data/models/login_response_model.dart';

abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState {}

class AuthLoading extends AuthState {}

class LoginSuccess extends AuthState {
  final LoginResponseModel loginResponse;

  const LoginSuccess(this.loginResponse);

  @override
  List<Object?> get props => [loginResponse];
}

class OTPSent extends AuthState {
  final String email;
  final String message;

  const OTPSent(this.email,this.message);

  @override
  List<Object?> get props => [email,message];
}

class OTPVerified extends AuthState {
  final String email;
  final String otp;

  const OTPVerified({required this.email, required this.otp});

  @override
  List<Object?> get props => [email, otp];
}

class PasswordResetSuccess extends AuthState {}

class AuthError extends AuthState {
  final String message;

  const AuthError(this.message);

  @override
  List<Object?> get props => [message];
}

class AuthLoggedIn extends AuthState {}

class RegisterSuccess extends AuthState {
  final Map<String, dynamic> data;

  const RegisterSuccess(this.data);

  @override
  List<Object?> get props => [data];
}
