import 'package:equatable/equatable.dart';

abstract class AuthEvent extends Equatable {
  const AuthEvent();

  @override
  List<Object?> get props => [];
}

class LoginRequested extends AuthEvent {
  final String email;
  final String password;

  const LoginRequested({required this.email, required this.password});

  @override
  List<Object?> get props => [email, password];
}

class SendOTPRequested extends AuthEvent {
  final String email;

  const SendOTPRequested(this.email);

  @override
  List<Object?> get props => [email];
}

class VerifyOTPRequested extends AuthEvent {
  final String email;
  final String otp;

  const VerifyOTPRequested({required this.email, required this.otp});

  @override
  List<Object?> get props => [email, otp];
}

class ResetPasswordRequested extends AuthEvent {
  final String email;
  final String otp;
  final String newPassword;

  const ResetPasswordRequested({
    required this.email,
    required this.otp,
    required this.newPassword,
  });

  @override
  List<Object?> get props => [email, otp, newPassword];
}

class ResendOTPRequested extends AuthEvent {
  final String email;
  final String message;
  const ResendOTPRequested(this.email, this.message);

  @override
  List<Object?> get props => [email,message];
}

class ResetAuthState extends AuthEvent {}

class LogoutRequested extends AuthEvent {}

class CheckAuthStatus extends AuthEvent {}

class RegisterRequested extends AuthEvent {
  final String firstName;
  final String lastName;
  final String email;
  final String password;
  final String mobile;
  final String otp;
  final String registerEventType;
  final bool acceptTerms;

  const RegisterRequested({
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.password,
    required this.mobile,
    required this.otp,
    required this.registerEventType,
    required this.acceptTerms,
  });

  @override
  List<Object?> get props => [
    firstName,
    lastName,
    email,
    password,
    mobile,
    otp,
    registerEventType,
    acceptTerms,
  ];
}
