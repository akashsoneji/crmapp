import 'package:equatable/equatable.dart';
import '../../../data/models/account_model.dart';

abstract class AccountState extends Equatable {
  const AccountState();

  @override
  List<Object?> get props => [];
}

class AccountInitial extends AccountState {
  const AccountInitial();
}

class AccountLoading extends AccountState {
  const AccountLoading();
}

class AccountLoaded extends AccountState {
  final List<AccountModel> accounts;
  final AccountModel? activeAccount;

  const AccountLoaded({
    required this.accounts,
    this.activeAccount,
  });

  @override
  List<Object?> get props => [accounts, activeAccount];

  AccountLoaded copyWith({
    List<AccountModel>? accounts,
    AccountModel? activeAccount,
  }) {
    return AccountLoaded(
      accounts: accounts ?? this.accounts,
      activeAccount: activeAccount ?? this.activeAccount,
    );
  }
}

class AccountError extends AccountState {
  final String message;

  const AccountError(this.message);

  @override
  List<Object?> get props => [message];
}

class AccountOperationSuccess extends AccountState {
  final String message;
  final List<AccountModel> accounts;
  final AccountModel? activeAccount;

  const AccountOperationSuccess({
    required this.message,
    required this.accounts,
    this.activeAccount,
  });

  @override
  List<Object?> get props => [message, accounts, activeAccount];
} 