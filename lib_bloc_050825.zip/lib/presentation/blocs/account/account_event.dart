import 'package:equatable/equatable.dart';
import '../../../data/models/account_model.dart';

abstract class AccountEvent extends Equatable {
  const AccountEvent();

  @override
  List<Object?> get props => [];
}

class LoadAccounts extends AccountEvent {
  const LoadAccounts();
}

class SetActiveAccount extends AccountEvent {
  final String accountId;

  const SetActiveAccount(this.accountId);

  @override
  List<Object?> get props => [accountId];
}

class AddAccount extends AccountEvent {
  final AccountModel account;

  const AddAccount(this.account);

  @override
  List<Object?> get props => [account];
}

class UpdateAccount extends AccountEvent {
  final AccountModel account;

  const UpdateAccount(this.account);

  @override
  List<Object?> get props => [account];
}

class DeleteAccount extends AccountEvent {
  final String accountId;

  const DeleteAccount(this.accountId);

  @override
  List<Object?> get props => [accountId];
}

class UpdateAccountBalance extends AccountEvent {
  final String accountId;
  final double newBalance;

  const UpdateAccountBalance(this.accountId, this.newBalance);

  @override
  List<Object?> get props => [accountId, newBalance];
}

class RefreshAccounts extends AccountEvent {
  const RefreshAccounts();
}

class ResetToDefaultAccounts extends AccountEvent {
  const ResetToDefaultAccounts();
}
