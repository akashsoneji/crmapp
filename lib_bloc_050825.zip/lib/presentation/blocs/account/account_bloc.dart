import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../data/repositories/account_repository.dart';
import 'account_event.dart';
import 'account_state.dart';

class AccountBloc extends Bloc<AccountEvent, AccountState> {
  final AccountRepository _accountRepository;

  AccountBloc({required AccountRepository accountRepository})
      : _accountRepository = accountRepository,
        super(const AccountInitial()) {
    on<LoadAccounts>(_onLoadAccounts);
    on<SetActiveAccount>(_onSetActiveAccount);
    on<AddAccount>(_onAddAccount);
    on<UpdateAccount>(_onUpdateAccount);
    on<DeleteAccount>(_onDeleteAccount);
    on<UpdateAccountBalance>(_onUpdateAccountBalance);
    on<RefreshAccounts>(_onRefreshAccounts);
    on<ResetToDefaultAccounts>(_onResetToDefaultAccounts);
  }

  Future<void> _onLoadAccounts(LoadAccounts event, Emitter<AccountState> emit) async {
    try {
      emit(const AccountLoading());
      
      final accounts = await _accountRepository.getAccounts();
      final activeAccount = await _accountRepository.getActiveAccount();
      
      emit(AccountLoaded(
        accounts: accounts,
        activeAccount: activeAccount,
      ));
    } catch (e) {
      emit(AccountError('Failed to load accounts: $e'));
    }
  }

  Future<void> _onSetActiveAccount(SetActiveAccount event, Emitter<AccountState> emit) async {
    try {
      await _accountRepository.setActiveAccount(event.accountId);
      
      final accounts = await _accountRepository.getAccounts();
      final activeAccount = await _accountRepository.getActiveAccount();
      
      emit(AccountOperationSuccess(
        message: 'Account switched successfully',
        accounts: accounts,
        activeAccount: activeAccount,
      ));
      
      // Emit loaded state after success
      emit(AccountLoaded(
        accounts: accounts,
        activeAccount: activeAccount,
      ));
    } catch (e) {
      emit(AccountError('Failed to switch account: $e'));
    }
  }

  Future<void> _onAddAccount(AddAccount event, Emitter<AccountState> emit) async {
    try {
      await _accountRepository.addAccount(event.account);
      
      final accounts = await _accountRepository.getAccounts();
      final activeAccount = await _accountRepository.getActiveAccount();
      
      emit(AccountOperationSuccess(
        message: 'Account added successfully',
        accounts: accounts,
        activeAccount: activeAccount,
      ));
      
      // Emit loaded state after success
      emit(AccountLoaded(
        accounts: accounts,
        activeAccount: activeAccount,
      ));
    } catch (e) {
      emit(AccountError('Failed to add account: $e'));
    }
  }

  Future<void> _onUpdateAccount(UpdateAccount event, Emitter<AccountState> emit) async {
    try {
      await _accountRepository.updateAccount(event.account);
      
      final accounts = await _accountRepository.getAccounts();
      final activeAccount = await _accountRepository.getActiveAccount();
      
      emit(AccountOperationSuccess(
        message: 'Account updated successfully',
        accounts: accounts,
        activeAccount: activeAccount,
      ));
      
      // Emit loaded state after success
      emit(AccountLoaded(
        accounts: accounts,
        activeAccount: activeAccount,
      ));
    } catch (e) {
      emit(AccountError('Failed to update account: $e'));
    }
  }

  Future<void> _onDeleteAccount(DeleteAccount event, Emitter<AccountState> emit) async {
    try {
      await _accountRepository.deleteAccount(event.accountId);
      
      final accounts = await _accountRepository.getAccounts();
      final activeAccount = await _accountRepository.getActiveAccount();
      
      emit(AccountOperationSuccess(
        message: 'Account deleted successfully',
        accounts: accounts,
        activeAccount: activeAccount,
      ));
      
      // Emit loaded state after success
      emit(AccountLoaded(
        accounts: accounts,
        activeAccount: activeAccount,
      ));
    } catch (e) {
      emit(AccountError('Failed to delete account: $e'));
    }
  }

  Future<void> _onUpdateAccountBalance(UpdateAccountBalance event, Emitter<AccountState> emit) async {
    try {
      await _accountRepository.updateAccountBalance(event.accountId, event.newBalance);
      
      final accounts = await _accountRepository.getAccounts();
      final activeAccount = await _accountRepository.getActiveAccount();
      
      emit(AccountOperationSuccess(
        message: 'Balance updated successfully',
        accounts: accounts,
        activeAccount: activeAccount,
      ));
      
      // Emit loaded state after success
      emit(AccountLoaded(
        accounts: accounts,
        activeAccount: activeAccount,
      ));
    } catch (e) {
      emit(AccountError('Failed to update balance: $e'));
    }
  }

  Future<void> _onRefreshAccounts(RefreshAccounts event, Emitter<AccountState> emit) async {
    try {
      final accounts = await _accountRepository.getAccounts();
      final activeAccount = await _accountRepository.getActiveAccount();
      
      emit(AccountLoaded(
        accounts: accounts,
        activeAccount: activeAccount,
      ));
    } catch (e) {
      emit(AccountError('Failed to refresh accounts: $e'));
    }
  }

  Future<void> _onResetToDefaultAccounts(ResetToDefaultAccounts event, Emitter<AccountState> emit) async {
    try {
      await _accountRepository.resetToDefaultAccounts();
      
      final accounts = await _accountRepository.getAccounts();
      final activeAccount = await _accountRepository.getActiveAccount();
      
      emit(AccountOperationSuccess(
        message: 'Accounts reset to default successfully',
        accounts: accounts,
        activeAccount: activeAccount,
      ));
      
      // Emit loaded state after success
      emit(AccountLoaded(
        accounts: accounts,
        activeAccount: activeAccount,
      ));
    } catch (e) {
      emit(AccountError('Failed to reset accounts: $e'));
    }
  }
} 