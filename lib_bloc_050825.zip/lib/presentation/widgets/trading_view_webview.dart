import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../core/utils/webview_utils.dart';

class FixedSizeWebView extends StatefulWidget {
  final String url;

  const FixedSizeWebView({required this.url, super.key});

  @override
  State<FixedSizeWebView> createState() => _FixedSizeWebViewState();
}

class _FixedSizeWebViewState extends State<FixedSizeWebView> {
  late final WebViewController _controller;
  bool _isLoading = true;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _initializeWebView();
  }

  void _initializeWebView() {
    final navigationDelegate = WebViewUtils.getOptimizedNavigationDelegate(
      onPageStarted: () {
        setState(() {
          _isLoading = true;
          _hasError = false;
        });
      },
      onPageFinished: () {
        setState(() {
          _isLoading = false;
        });
      },
      onError: () {
        setState(() {
          _hasError = true;
          _isLoading = false;
        });
      },
    );

    _controller = WebViewUtils.createOptimizedController(
      url: widget.url,
      navigationDelegate: navigationDelegate,
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      height: 490.h,
      child: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            Container(
              width: double.maxFinite,
              height: 490.h,
              color: Colors.white,
              child: const Center(child: CircularProgressIndicator()),
            ),
          if (_hasError)
            Container(
              width: double.maxFinite,
              height: 490.h,
              color: Colors.white,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 48.h, color: Colors.grey),
                    SizedBox(height: 16.h),
                    Text(
                      'Failed to load chart',
                      style: TextStyle(
                        fontSize: 16.sp,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 8.h),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _hasError = false;
                          _isLoading = true;
                        });
                        _initializeWebView();
                      },
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
