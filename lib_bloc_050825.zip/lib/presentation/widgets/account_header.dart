import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../core/constants/color.dart';
import '../../core/constants/text_styles.dart';
import '../blocs/account/account_bloc.dart';
import '../blocs/account/account_state.dart';
import 'account_selector.dart';

class AccountHeader extends StatelessWidget {
  final VoidCallback? onAccountTap;
  final VoidCallback? onDepositTap;
  final VoidCallback? onTradeTap;
  final VoidCallback? onWithdrawTap;
  final VoidCallback? onMoreTap;

  const AccountHeader({
    super.key,
    this.onAccountTap,
    this.onDepositTap,
    this.onTradeTap,
    this.onWithdrawTap,
    this.onMoreTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.primary.withOpacity(0.8)],
        ),
      ),
      child: Column(
        children: [
          // Top row with account selector and balance
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Account Selector
              AccountSelector(showBalance: false, onTap: onAccountTap),

              // Balance Display
              BlocBuilder<AccountBloc, AccountState>(
                builder: (context, state) {
                  if (state is AccountLoaded && state.activeAccount != null) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '\$${state.activeAccount!.balance.toStringAsFixed(2)}',
                          style: AppTextStyles.label.copyWith(
                            fontSize: 24.sp,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          'Balance',
                          style: AppTextStyles.label.copyWith(
                            fontSize: 12.sp,
                            color: Colors.white.withOpacity(0.8),
                          ),
                        ),
                      ],
                    );
                  }
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '\$0.00',
                        style: AppTextStyles.label.copyWith(
                          fontSize: 24.sp,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        'Balance',
                        style: AppTextStyles.label.copyWith(
                          fontSize: 12.sp,
                          color: Colors.white.withOpacity(0.8),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),

          SizedBox(height: 20.h),

          // Action buttons row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildActionButton(
                icon: Icons.account_balance_wallet,
                label: 'Deposit',
                onTap: onDepositTap,
              ),
              _buildActionButton(
                icon: Icons.trending_up,
                label: 'Trade',
                onTap: onTradeTap,
              ),
              _buildActionButton(
                icon: Icons.account_balance,
                label: 'Withdraw',
                onTap: onWithdrawTap,
              ),
              _buildActionButton(
                icon: Icons.more_horiz,
                label: 'More',
                onTap: onMoreTap,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 48.w,
            height: 48.h,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(24.r),
            ),
            child: Icon(icon, color: Colors.white, size: 24.h),
          ),
          SizedBox(height: 8.h),
          Text(
            label,
            style: AppTextStyles.label.copyWith(
              fontSize: 12.sp,
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// Example usage in a dashboard screen
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: Column(
        children: [
          // Account Header with selector
          AccountHeader(
            onAccountTap: () {
              // This will show the account selection dialog
              // The AccountSelector handles this automatically
            },
            onDepositTap: () {
              // Navigate to deposit screen
              print('Navigate to deposit');
            },
            onTradeTap: () {
              // Navigate to trading screen
              Navigator.pushNamed(context, '/trading');
            },
            onWithdrawTap: () {
              // Navigate to withdraw screen
              print('Navigate to withdraw');
            },
            onMoreTap: () {
              // Navigate to more options
              print('Navigate to more options');
            },
          ),

          // Rest of dashboard content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Dashboard Content',
                    style: AppTextStyles.label.copyWith(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 16.h),

                  // Example: Account Management Button
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/account-management');
                    },
                    child: Text('Manage Accounts'),
                  ),

                  SizedBox(height: 16.h),

                  // Example: Current Account Info
                  BlocBuilder<AccountBloc, AccountState>(
                    builder: (context, state) {
                      if (state is AccountLoaded &&
                          state.activeAccount != null) {
                        return Container(
                          padding: EdgeInsets.all(16.w),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12.r),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 4,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Current Account',
                                style: AppTextStyles.label.copyWith(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              SizedBox(height: 8.h),
                              Text(
                                'Type: ${state.activeAccount!.type}',
                                style: AppTextStyles.label.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.textGrey,
                                ),
                              ),
                              Text(
                                'ID: ${state.activeAccount!.id}',
                                style: AppTextStyles.label.copyWith(
                                  fontSize: 14.sp,
                                  color: AppColors.textGrey,
                                ),
                              ),
                              Text(
                                'Balance: \$${state.activeAccount!.balance.toStringAsFixed(2)}',
                                style: AppTextStyles.label.copyWith(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        );
                      }
                      return Container();
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
