import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../core/constants/color.dart';
import '../../core/constants/text_styles.dart';
import '../../data/models/account_model.dart';
import '../blocs/account/account_bloc.dart';
import '../blocs/account/account_event.dart';
import '../blocs/account/account_state.dart';

class AccountSelector extends StatelessWidget {
  final bool showBalance;
  final VoidCallback? onTap;

  const AccountSelector({
    super.key,
    this.showBalance = true,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AccountBloc, AccountState>(
      builder: (context, state) {
        if (state is AccountLoaded && state.activeAccount != null) {
          return _buildAccountSelector(context, state.activeAccount!);
        } else if (state is AccountLoading) {
          return _buildLoadingSelector();
        } else {
          return _buildDefaultSelector();
        }
      },
    );
  }

  Widget _buildAccountSelector(BuildContext context, AccountModel account) {
    return GestureDetector(
      onTap: onTap ?? () => _showAccountSelectionDialog(context),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
        decoration: BoxDecoration(
          color: account.type == 'REAL' 
              ? AppColors.primary.withOpacity(0.1)
              : AppColors.success.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8.r),
          border: Border.all(
            color: account.type == 'REAL' 
                ? AppColors.primary.withOpacity(0.3)
                : AppColors.success.withOpacity(0.3),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: account.type == 'REAL' 
                    ? AppColors.primary 
                    : AppColors.success,
                borderRadius: BorderRadius.circular(4.r),
              ),
              child: Icon(
                Icons.account_balance_wallet,
                color: Colors.white,
                size: 12.h,
              ),
            ),
            SizedBox(width: 8.w),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  account.type,
                  style: AppTextStyles.label.copyWith(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                    color: account.type == 'REAL' 
                        ? AppColors.primary 
                        : AppColors.success,
                  ),
                ),
                if (showBalance)
                  Text(
                    '\$${account.balance.toStringAsFixed(2)}',
                    style: AppTextStyles.label.copyWith(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textPrimary,
                    ),
                  ),
              ],
            ),
            SizedBox(width: 4.w),
            Icon(
              Icons.keyboard_arrow_down,
              size: 16.h,
              color: AppColors.textGrey,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingSelector() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 12.w,
            height: 12.h,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(AppColors.primary),
            ),
          ),
          SizedBox(width: 8.w),
          Text(
            'Loading...',
            style: AppTextStyles.label.copyWith(
              fontSize: 12.sp,
              color: AppColors.textGrey,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDefaultSelector() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.account_balance_wallet,
            size: 12.h,
            color: AppColors.textGrey,
          ),
          SizedBox(width: 8.w),
          Text(
            'No Account',
            style: AppTextStyles.label.copyWith(
              fontSize: 12.sp,
              color: AppColors.textGrey,
            ),
          ),
          SizedBox(width: 4.w),
          Icon(
            Icons.keyboard_arrow_down,
            size: 16.h,
            color: AppColors.textGrey,
          ),
        ],
      ),
    );
  }

  void _showAccountSelectionDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const AccountSelectionDialog(),
    );
  }
}

class AccountSelectionDialog extends StatelessWidget {
  const AccountSelectionDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AccountBloc, AccountState>(
      builder: (context, state) {
        if (state is AccountLoaded) {
          return AlertDialog(
            title: Text(
              'Select Account',
              style: AppTextStyles.label.copyWith(
                fontSize: 18.sp,
                fontWeight: FontWeight.w700,
              ),
            ),
            content: SizedBox(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: state.accounts.map((account) {
                  final isActive = state.activeAccount?.id == account.id;
                  return _buildAccountOption(context, account, isActive);
                }).toList(),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('Cancel'),
              ),
            ],
          );
        }
        return AlertDialog(
          title: Text('Loading...'),
          content: Center(child: CircularProgressIndicator()),
        );
      },
    );
  }

  Widget _buildAccountOption(BuildContext context, AccountModel account, bool isActive) {
    return Container(
      margin: EdgeInsets.only(bottom: 8.h),
      child: ListTile(
        leading: Container(
          padding: EdgeInsets.all(8.w),
          decoration: BoxDecoration(
            color: account.type == 'REAL' 
                ? AppColors.primary 
                : AppColors.success,
            borderRadius: BorderRadius.circular(8.r),
          ),
          child: Icon(
            Icons.account_balance_wallet,
            color: Colors.white,
            size: 16.h,
          ),
        ),
        title: Row(
          children: [
            Text(
              account.type,
              style: AppTextStyles.label.copyWith(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
            if (isActive) ...[
              SizedBox(width: 8.w),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                decoration: BoxDecoration(
                  color: AppColors.success,
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Text(
                  'ACTIVE',
                  style: AppTextStyles.label.copyWith(
                    fontSize: 8.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ID: ${account.id}',
              style: AppTextStyles.label.copyWith(
                fontSize: 12.sp,
                color: AppColors.textGrey,
              ),
            ),
            Text(
              '\$${account.balance.toStringAsFixed(2)}',
              style: AppTextStyles.label.copyWith(
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
          ],
        ),
        trailing: isActive 
            ? Icon(Icons.check_circle, color: AppColors.success)
            : null,
        onTap: isActive 
            ? null 
            : () {
                context.read<AccountBloc>().add(SetActiveAccount(account.id));
                Navigator.of(context).pop();
              },
        tileColor: isActive 
            ? AppColors.primary.withOpacity(0.1)
            : null,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.r),
        ),
      ),
    );
  }
} 