import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TradingViewAdvancedCharts extends StatefulWidget {
  final String symbol;
  final String interval;
  final double width;
  final double height;
  final String? libraryPath; // Path to TradingView library files

  const TradingViewAdvancedCharts({
    super.key,
    required this.symbol,
    required this.interval,
    this.width = 372,
    this.height = 500,
    this.libraryPath,
  });

  @override
  State<TradingViewAdvancedCharts> createState() =>
      _TradingViewAdvancedChartsState();
}

class _TradingViewAdvancedChartsState extends State<TradingViewAdvancedCharts> {
  late WebViewController _controller;
  bool _isLoading = true;
  bool _isError = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading progress
          },
          onPageStarted: (String url) {
            setState(() {
              _isLoading = true;
              _isError = false;
            });
          },
          onPageFinished: (String url) {
            setState(() {
              _isLoading = false;
            });
          },
          onWebResourceError: (WebResourceError error) {
            setState(() {
              _isError = true;
              _isLoading = false;
            });
          },
        ),
      )
      ..loadHtmlString(_getTradingViewHTML());
  }

  String _getTradingViewHTML() {
    return '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>TradingView Advanced Charts</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            overflow: hidden;
        }
        #tv_chart_container {
            width: ${widget.width}px;
            height: ${widget.height}px;
            position: relative;
        }
        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            color: #666;
        }
        .error {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            color: #ff4444;
            text-align: center;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div id="tv_chart_container">
        <div class="loading">Loading TradingView Chart...</div>
    </div>

    <script type="text/javascript" src="https://unpkg.com/lightweight-charts/dist/lightweight-charts.standalone.production.js"></script>
    <script type="text/javascript">
        // TradingView Advanced Charts Configuration
        const chart = LightweightCharts.createChart(document.getElementById('tv_chart_container'), {
            width: ${widget.width},
            height: ${widget.height},
            layout: {
                background: { color: '#ffffff' },
                textColor: '#333',
            },
            grid: {
                vertLines: { color: '#f0f0f0' },
                horzLines: { color: '#f0f0f0' },
            },
            crosshair: {
                mode: LightweightCharts.CrosshairMode.Normal,
            },
            rightPriceScale: {
                borderColor: '#ddd',
            },
            timeScale: {
                borderColor: '#ddd',
                timeVisible: true,
                secondsVisible: true,
            },
            // Mobile-specific settings
            handleScroll: {
                mouseWheel: false,
                pressedMouseMove: false,
                horzTouchDrag: true,
                vertTouchDrag: true,
            },
            handleScale: {
                axisPressedMouseMove: false,
                mouseWheel: false,
                pinch: true,
            },
        });

        // Create candlestick series
        const candleSeries = chart.addCandlestickSeries({
            upColor: '#26a69a',
            downColor: '#ef5350',
            borderDownColor: '#ef5350',
            borderUpColor: '#26a69a',
            wickDownColor: '#ef5350',
            wickUpColor: '#26a69a',
        });

        // Sample data for ${widget.symbol}
        const data = [
            { time: '2024-01-01', open: 1.2490, high: 1.2510, low: 1.2480, close: 1.2500 },
            { time: '2024-01-02', open: 1.2500, high: 1.2520, low: 1.2490, close: 1.2510 },
            { time: '2024-01-03', open: 1.2510, high: 1.2530, low: 1.2500, close: 1.2520 },
            { time: '2024-01-04', open: 1.2520, high: 1.2540, low: 1.2510, close: 1.2530 },
            { time: '2024-01-05', open: 1.2530, high: 1.2550, low: 1.2520, close: 1.2540 },
            { time: '2024-01-06', open: 1.2540, high: 1.2560, low: 1.2530, close: 1.2550 },
            { time: '2024-01-07', open: 1.2550, high: 1.2570, low: 1.2540, close: 1.2560 },
            { time: '2024-01-08', open: 1.2560, high: 1.2580, low: 1.2550, close: 1.2570 },
            { time: '2024-01-09', open: 1.2570, high: 1.2590, low: 1.2560, close: 1.2580 },
            { time: '2024-01-10', open: 1.2580, high: 1.2600, low: 1.2570, close: 1.2590 },
        ];

        candleSeries.setData(data);

        // Add volume series
        const volumeSeries = chart.addHistogramSeries({
            color: '#26a69a',
            priceFormat: {
                type: 'volume',
            },
            priceScaleId: '',
            scaleMargins: {
                top: 0.8,
                bottom: 0,
            },
        });

        const volumeData = [
            { time: '2024-01-01', value: 1000, color: '#26a69a' },
            { time: '2024-01-02', value: 1200, color: '#26a69a' },
            { time: '2024-01-03', value: 1100, color: '#ef5350' },
            { time: '2024-01-04', value: 1300, color: '#26a69a' },
            { time: '2024-01-05', value: 1400, color: '#26a69a' },
            { time: '2024-01-06', value: 1250, color: '#ef5350' },
            { time: '2024-01-07', value: 1350, color: '#26a69a' },
            { time: '2024-01-08', value: 1450, color: '#26a69a' },
            { time: '2024-01-09', value: 1150, color: '#ef5350' },
            { time: '2024-01-10', value: 1550, color: '#26a69a' },
        ];

        volumeSeries.setData(volumeData);

        // Mobile-specific touch handling
        chart.applyOptions({
            handleScroll: {
                horzTouchDrag: true,
                vertTouchDrag: true,
                mouseWheel: false,
                pressedMouseMove: false,
            },
            handleScale: {
                axisPressedMouseMove: false,
                mouseWheel: false,
                pinch: true,
            },
        });

        // Real-time data simulation
        let currentTime = new Date();
        setInterval(() => {
            currentTime.setSeconds(currentTime.getSeconds() + 1);
            const lastCandle = data[data.length - 1];
            const newCandle = {
                time: currentTime.toISOString().split('T')[0],
                open: lastCandle.close,
                high: lastCandle.close + Math.random() * 0.002,
                low: lastCandle.close - Math.random() * 0.002,
                close: lastCandle.close + (Math.random() - 0.5) * 0.001,
            };
            
            candleSeries.update(newCandle);
            
            const newVolume = {
                time: currentTime.toISOString().split('T')[0],
                value: 1000 + Math.random() * 500,
                color: newCandle.close > newCandle.open ? '#26a69a' : '#ef5350',
            };
            
            volumeSeries.update(newVolume);
        }, 1000);

        // Remove loading message
        document.querySelector('.loading').style.display = 'none';

        // Handle window resize
        window.addEventListener('resize', () => {
            chart.applyOptions({
                width: ${widget.width},
                height: ${widget.height},
            });
        });
    </script>
</body>
</html>
    ''';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width.w,
      height: widget.height.h,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8.r),
        color: Colors.white,
      ),
      child: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            Container(
              width: widget.width.w,
              height: widget.height.h,
              color: Colors.white,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                    ),
                    SizedBox(height: 16.h),
                    Text(
                      'Loading TradingView Chart...',
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (_isError)
            Container(
              width: widget.width.w,
              height: widget.height.h,
              color: Colors.white,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 48.h, color: Colors.red),
                    SizedBox(height: 16.h),
                    Text(
                      'Failed to load chart',
                      style: TextStyle(
                        fontSize: 16.sp,
                        color: Colors.red,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      'Please check your internet connection',
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 16.h),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _isError = false;
                          _isLoading = true;
                        });
                        _controller.reload();
                      },
                      child: Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
