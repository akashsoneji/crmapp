import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:intl/intl.dart';
import 'dart:math';
import 'dart:async';
import '../../../data/services/market_data_service.dart';

class SimpleChartWidget extends StatefulWidget {
  final String symbol;
  final String interval;
  final double width;
  final double height;

  const SimpleChartWidget({
    super.key,
    required this.symbol,
    required this.interval,
    this.width = 372,
    this.height = 500,
  });

  @override
  State<SimpleChartWidget> createState() => _SimpleChartWidgetState();
}

class _SimpleChartWidgetState extends State<SimpleChartWidget> {
  List<ChartData> _chartData = [];
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _generateChartData();
    _startRealTimeUpdates();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _generateChartData() async {
    try {
      final candles = await MarketDataService.getCandlestickData(
        widget.symbol,
        widget.interval,
        50,
      );

      if (mounted) {
        setState(() {
          _chartData =
              candles
                  .map(
                    (candle) => ChartData(
                      time: candle['time'],
                      open: candle['open'],
                      high: candle['high'],
                      low: candle['low'],
                      close: candle['close'],
                      volume: candle['volume'],
                    ),
                  )
                  .toList();
        });
      }
    } catch (e) {
      print('Error loading chart data: $e');
      // Fallback to simulated data
      _generateSimulatedData();
    }
  }

  void _generateSimulatedData() {
    final random = Random();
    final now = DateTime.now();
    _chartData.clear();

    for (int i = 50; i >= 0; i--) {
      final time = now.subtract(Duration(seconds: i));
      final basePrice = 1.2490 + (random.nextDouble() - 0.5) * 0.002;

      _chartData.add(
        ChartData(
          time: time,
          open: basePrice,
          high: basePrice + random.nextDouble() * 0.001,
          low: basePrice - random.nextDouble() * 0.001,
          close: basePrice + (random.nextDouble() - 0.5) * 0.0005,
          volume: 1000 + random.nextDouble() * 500,
        ),
      );
    }
  }

  void _startRealTimeUpdates() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          _addNewDataPoint();
        });
      }
    });
  }

  void _addNewDataPoint() {
    if (_chartData.isEmpty) return;

    final random = Random();
    final lastData = _chartData.last;
    final newTime = DateTime.now();
    final basePrice = lastData.close;

    final newData = ChartData(
      time: newTime,
      open: basePrice,
      high: basePrice + random.nextDouble() * 0.001,
      low: basePrice - random.nextDouble() * 0.001,
      close: basePrice + (random.nextDouble() - 0.5) * 0.0005,
      volume: 1000 + random.nextDouble() * 500,
    );

    _chartData.add(newData);

    // Keep only last 50 data points
    if (_chartData.length > 50) {
      _chartData.removeAt(0);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: widget.height.h,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8.r),
        color: Colors.white,
      ),
      child: Column(
        children: [
          // Chart Header
          Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(8.r),
                topRight: Radius.circular(8.r),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${widget.symbol} - ${widget.interval}',
                  style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade700,
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(4.r),
                  ),
                  child: Text(
                    'Live',
                    style: TextStyle(
                      fontSize: 10.sp,
                      color: Colors.blue.shade700,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Chart
          Expanded(
            child:
                _chartData.isEmpty
                    ? Center(child: CircularProgressIndicator())
                    : SfCartesianChart(
                      margin: EdgeInsets.only(
                        left: 8.w,
                        right: 16.w,
                        top: 8.h,
                        bottom: 8.h,
                      ),
                      primaryXAxis: DateTimeAxis(
                        dateFormat: DateFormat('HH:mm:ss'),
                        majorGridLines: MajorGridLines(width: 0),
                        intervalType: DateTimeIntervalType.seconds,
                        interval: 10,
                        labelStyle: TextStyle(fontSize: 10.sp),
                      ),
                      primaryYAxis: NumericAxis(
                        numberFormat: NumberFormat('#,##0.00000'),
                        majorGridLines: MajorGridLines(
                          width: 1,
                          color: Colors.grey.shade200,
                        ),
                        labelStyle: TextStyle(fontSize: 10.sp),
                        plotOffset: 20,
                      ),
                      series: <CartesianSeries>[
                        // Candlestick Series
                        CandleSeries<ChartData, DateTime>(
                          dataSource: _chartData,
                          xValueMapper: (ChartData data, _) => data.time,
                          lowValueMapper: (ChartData data, _) => data.low,
                          highValueMapper: (ChartData data, _) => data.high,
                          openValueMapper: (ChartData data, _) => data.open,
                          closeValueMapper: (ChartData data, _) => data.close,
                          bearColor: Colors.red.shade400,
                          bullColor: Colors.green.shade400,
                        ),
                        // Volume Series
                        ColumnSeries<ChartData, DateTime>(
                          dataSource: _chartData,
                          xValueMapper: (ChartData data, _) => data.time,
                          yValueMapper: (ChartData data, _) => data.volume,
                          color: Colors.blue.shade200.withOpacity(0.6),
                          width: 0.8,
                        ),
                      ],
                      zoomPanBehavior: ZoomPanBehavior(
                        enablePinching: true,
                        enablePanning: true,
                        enableMouseWheelZooming: true,
                      ),
                    ),
          ),
        ],
      ),
    );
  }
}

class ChartData {
  final DateTime time;
  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;

  ChartData({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });
}
