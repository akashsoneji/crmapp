import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pipze/core/constants/color.dart';
import 'package:pipze/core/constants/text_styles.dart';
import 'package:pipze/presentation/screens/trading/trade_screen.dart';

class TradeDetailsModal extends StatelessWidget {
  final TradePosition position;

  const TradeDetailsModal({super.key, required this.position});

  @override
  Widget build(BuildContext context) {
    return Container(
      height:
          MediaQuery.of(context).size.height * 0.4 +
          MediaQuery.of(context).padding.bottom,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.r),
          topRight: Radius.circular(20.r),
        ),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            margin: EdgeInsets.only(top: 12.h),
            width: 40.w,
            height: 4.h,
            decoration: BoxDecoration(
              color: AppColors.grey,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Position details
          Padding(
            padding: EdgeInsets.all(10.w).copyWith(bottom: 5.w),
            child: _buildPositionDetails(),
          ),

          Divider(height: 1.h, color: AppColors.border.withOpacity(0.3)),

          // Action options
          Expanded(child: _buildActionOptions(context)),
        ],
      ),
    );
  }

  Widget _buildPositionDetails() {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: AppColors.backgroundLight,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Row(
        children: [
          // Flag and Symbol
          Row(
            children: [
              Container(
                width: 40.w,
                height: 24.h,
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      child: Text(
                        _getFirstFlag(position.flag),
                        style: TextStyle(fontSize: 16.sp),
                      ),
                    ),
                    Positioned(
                      right: 0,
                      child: Text(
                        _getSecondFlag(position.flag),
                        style: TextStyle(fontSize: 16.sp),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 12.w),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    position.symbol,
                    style: AppTextStyles.input.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 16.sp,
                    ),
                  ),
                  Text(
                    '${position.action} ${position.volume.toStringAsFixed(2)}',
                    style: AppTextStyles.subheading.copyWith(
                      fontSize: 12.sp,
                      color:
                          position.action == 'Buy'
                              ? AppColors.success
                              : AppColors.red,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const Spacer(),
          // Profit/Loss
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '\$${position.profitLoss.toStringAsFixed(2)}',
                style: AppTextStyles.input.copyWith(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w700,
                  color:
                      position.profitLoss >= 0
                          ? AppColors.success
                          : AppColors.red,
                ),
              ),
              Text(
                '${position.entryPrice} → ${position.currentPrice}',
                style: AppTextStyles.subheading.copyWith(
                  fontSize: 12.sp,
                  color: AppColors.textGrey,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionOptions(BuildContext context) {
    final actions = <Map<String, dynamic>>[
      {'icon': Icons.close, 'title': 'Close Position', 'color': AppColors.red},
      {
        'icon': Icons.edit,
        'title': 'Modify Position',
        'color': AppColors.primary,
      },
      {'icon': Icons.add, 'title': 'New Order', 'color': AppColors.success},
      {'icon': Icons.show_chart, 'title': 'Chart', 'color': AppColors.primary},
    ];

    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: 16.w),
      itemCount: actions.length,
      itemBuilder: (context, index) {
        final action = actions[index];
        return ListTile(
          title: Text(
            action['title'] as String,
            style: AppTextStyles.input.copyWith(
              fontSize: 14.sp,
              fontWeight: FontWeight.w400,
            ),
          ),
          onTap: () {
            Navigator.pop(context);
            _handleAction(context, action['title'] as String);
          },
        );
      },
    );
  }

  void _handleAction(BuildContext context, String action) {
    switch (action) {
      case 'Close Position':
        // Handle close position
        break;
      case 'Modify Position':
        // Handle modify position
        break;
      case 'New Order':
        // Handle new order
        break;
      case 'Chart':
        // Handle chart navigation
        break;
    }
  }

  String _getFirstFlag(String flag) {
    if (flag.length >= 4) {
      return flag.substring(0, 2);
    }
    return flag;
  }

  String _getSecondFlag(String flag) {
    if (flag.length >= 4) {
      return flag.substring(2, 4);
    }
    return '';
  }
}
