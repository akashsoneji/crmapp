import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../core/constants/color.dart';
import '../../core/constants/text_styles.dart';
import '../../data/models/candle_data_model.dart';

class TradingViewChart extends StatefulWidget {
  final List<CandleDataModel> data;
  final String chartType;
  final String symbol;
  final String timeframe;
  final bool showVolume;
  final bool showGrid;
  final bool showPriceLabels;
  final bool showTimeLabels;
  final Function(String)? onTimeframeChanged;
  final Function(String)? onChartTypeChanged;

  const TradingViewChart({
    super.key,
    required this.data,
    this.chartType = 'Candlestick',
    this.symbol = 'EURUSD',
    this.timeframe = '15m',
    this.showVolume = true,
    this.showGrid = true,
    this.showPriceLabels = true,
    this.showTimeLabels = true,
    this.onTimeframeChanged,
    this.onChartTypeChanged,
  });

  @override
  State<TradingViewChart> createState() => _TradingViewChartState();
}

class _TradingViewChartState extends State<TradingViewChart> {
  double scale = 1.0;
  Offset offset = Offset.zero;
  Offset? _startingFocalPoint;

  Offset? _previousOffset;
  double? _previousScale;
  bool isZoomed = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          // Chart Header
          _buildChartHeader(),

          // Chart Area
          Expanded(child: _buildChartArea()),

          // Chart Footer
          if (widget.showTimeLabels) _buildChartFooter(),
        ],
      ),
    );
  }

  Widget _buildChartHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: AppColors.backgroundLight,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(8.r),
          topRight: Radius.circular(8.r),
        ),
      ),
      child: Row(
        children: [
          // Symbol and Timeframe
          Expanded(
            child: Row(
              children: [
                Text(
                  widget.symbol,
                  style: AppTextStyles.label.copyWith(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                SizedBox(width: 8.w),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4.r),
                  ),
                  child: Text(
                    widget.timeframe,
                    style: AppTextStyles.label.copyWith(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Chart Controls
          Row(
            children: [
              // Chart Type Selector
              _buildDropdownButton(
                value: widget.chartType,
                items: ['Candlestick', 'Line', 'Bar', 'Area', 'Heikin-Ashi'],
                onChanged: (value) {
                  widget.onChartTypeChanged?.call(value!);
                },
                icon: Icons.show_chart,
              ),

              SizedBox(width: 8.w),

              // Timeframe Selector
              _buildDropdownButton(
                value: widget.timeframe,
                items: ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'],
                onChanged: (value) {
                  widget.onTimeframeChanged?.call(value!);
                },
                icon: Icons.access_time,
              ),

              SizedBox(width: 8.w),

              // Zoom Controls
              _buildZoomControls(),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownButton({
    required String value,
    required List<String> items,
    required Function(String?)? onChanged,
    required IconData icon,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(4.r),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16.h, color: AppColors.textGrey),
          SizedBox(width: 4.w),
          DropdownButton<String>(
            value: value,
            underline: Container(),
            style: AppTextStyles.label.copyWith(
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
            ),
            items:
                items.map((String item) {
                  return DropdownMenuItem<String>(
                    value: item,
                    child: Text(item),
                  );
                }).toList(),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildZoomControls() {
    return Row(
      children: [
        _buildZoomButton(Icons.zoom_in, () {
          setState(() {
            scale = (scale * 1.2).clamp(0.5, 5.0);
            isZoomed = scale != 1.0;
          });
        }),
        SizedBox(width: 4.w),
        _buildZoomButton(Icons.zoom_out, () {
          setState(() {
            scale = (scale / 1.2).clamp(0.5, 5.0);
            isZoomed = scale != 1.0;
          });
        }),
        if (isZoomed) ...[
          SizedBox(width: 4.w),
          _buildZoomButton(Icons.refresh, () {
            setState(() {
              scale = 1.0;
              offset = Offset.zero;
              isZoomed = false;
            });
          }),
        ],
      ],
    );
  }

  Widget _buildZoomButton(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28.w,
        height: 28.h,
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.1),
          borderRadius: BorderRadius.circular(4.r),
        ),
        child: Icon(icon, size: 16.h, color: AppColors.primary),
      ),
    );
  }

  Widget _buildChartArea() {
    if (widget.data.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.show_chart,
              size: 48.h,
              color: AppColors.textGrey.withOpacity(0.5),
            ),
            SizedBox(height: 16.h),
            Text(
              'No data available',
              style: AppTextStyles.label.copyWith(color: AppColors.textGrey),
            ),
          ],
        ),
      );
    }

    return GestureDetector(
      onScaleStart: (details) {
        _startingFocalPoint = details.focalPoint;
        _previousOffset = offset;
        _previousScale = scale;
      },
      onScaleUpdate: (details) {
        setState(() {
          scale = (_previousScale ?? 1.0) * details.scale;
          scale = scale.clamp(0.5, 5.0);

          final Offset normalizedOffset =
              details.focalPoint - _startingFocalPoint!;
          offset = _previousOffset! + normalizedOffset;
          isZoomed = scale != 1.0 || offset != Offset.zero;
        });
      },
      onScaleEnd: (details) {
        _startingFocalPoint = null;
        _previousOffset = null;
        _previousScale = null;
      },
      child: Transform(
        transform:
            Matrix4.identity()
              ..translate(offset.dx, offset.dy)
              ..scale(scale),
        child: CustomPaint(
          painter: TradingViewChartPainter(
            data: widget.data,
            chartType: widget.chartType,
            showVolume: widget.showVolume,
            showGrid: widget.showGrid,
          ),
          size: Size.infinite,
        ),
      ),
    );
  }

  Widget _buildChartFooter() {
    if (widget.data.isEmpty) return Container();

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: AppColors.backgroundLight,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(8.r),
          bottomRight: Radius.circular(8.r),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            _formatTime(widget.data.first.timestamp),
            style: AppTextStyles.label.copyWith(
              fontSize: 10.sp,
              color: AppColors.textGrey,
            ),
          ),
          Text(
            _formatTime(widget.data[widget.data.length ~/ 2].timestamp),
            style: AppTextStyles.label.copyWith(
              fontSize: 10.sp,
              color: AppColors.textGrey,
            ),
          ),
          Text(
            _formatTime(widget.data.last.timestamp),
            style: AppTextStyles.label.copyWith(
              fontSize: 10.sp,
              color: AppColors.textGrey,
            ),
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime timestamp) {
    return '${timestamp.hour.toString().padLeft(2, '0')}:${timestamp.minute.toString().padLeft(2, '0')}';
  }
}

class TradingViewChartPainter extends CustomPainter {
  final List<CandleDataModel> data;
  final String chartType;
  final bool showVolume;
  final bool showGrid;

  TradingViewChartPainter({
    required this.data,
    required this.chartType,
    required this.showVolume,
    required this.showGrid,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (data.isEmpty) return;

    final maxPrice = data.map((e) => e.high).reduce((a, b) => a > b ? a : b);
    final minPrice = data.map((e) => e.low).reduce((a, b) => a < b ? a : b);
    final priceRange = maxPrice - minPrice;
    final maxVolume = data
        .map((e) => e.volume.toDouble())
        .reduce((a, b) => a > b ? a : b);

    // Draw grid
    if (showGrid) {
      _drawGrid(canvas, size, maxPrice, minPrice, priceRange);
    }

    // Draw price labels
    _drawPriceLabels(canvas, size, maxPrice, minPrice, priceRange);

    // Draw chart based on type
    switch (chartType) {
      case 'Candlestick':
        _drawCandlesticks(canvas, size, maxPrice, minPrice, priceRange);
        break;
      case 'Line':
        _drawLineChart(canvas, size, maxPrice, minPrice, priceRange);
        break;
      case 'Bar':
        _drawBarChart(canvas, size, maxPrice, minPrice, priceRange);
        break;
      case 'Area':
        _drawAreaChart(canvas, size, maxPrice, minPrice, priceRange);
        break;
      case 'Heikin-Ashi':
        _drawHeikinAshi(canvas, size, maxPrice, minPrice, priceRange);
        break;
    }

    // Draw volume
    if (showVolume) {
      _drawVolume(canvas, size, maxVolume);
    }
  }

  void _drawGrid(
    Canvas canvas,
    Size size,
    double maxPrice,
    double minPrice,
    double priceRange,
  ) {
    final paint =
        Paint()
          ..color = AppColors.border.withOpacity(0.2)
          ..strokeWidth = 0.5;

    // Horizontal grid lines
    for (int i = 1; i < 5; i++) {
      final y = (size.height / 5) * i;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    // Vertical grid lines
    for (int i = 1; i < 5; i++) {
      final x = (size.width / 5) * i;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
  }

  void _drawPriceLabels(
    Canvas canvas,
    Size size,
    double maxPrice,
    double minPrice,
    double priceRange,
  ) {
    final textPainter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.right,
    );

    for (int i = 0; i <= 5; i++) {
      final price = maxPrice - (priceRange / 5) * i;
      final y = (size.height / 5) * i;

      textPainter.text = TextSpan(
        text: price.toStringAsFixed(5),
        style: TextStyle(
          fontSize: 10,
          color: AppColors.textGrey,
          fontWeight: FontWeight.w500,
        ),
      );

      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(size.width - textPainter.width - 8, y - textPainter.height / 2),
      );
    }
  }

  void _drawCandlesticks(
    Canvas canvas,
    Size size,
    double maxPrice,
    double minPrice,
    double priceRange,
  ) {
    final candleWidth = size.width / data.length;
    final paint =
        Paint()
          ..strokeWidth = 1.5
          ..style = PaintingStyle.stroke;

    for (int i = 0; i < data.length; i++) {
      final candle = data[i];
      final x = i * candleWidth + candleWidth / 2;
      final isGreen = candle.isBullish;

      paint.color = isGreen ? AppColors.success : AppColors.error;

      // Calculate Y positions
      final highY =
          size.height - ((candle.high - minPrice) / priceRange * size.height);
      final lowY =
          size.height - ((candle.low - minPrice) / priceRange * size.height);
      final openY =
          size.height - ((candle.open - minPrice) / priceRange * size.height);
      final closeY =
          size.height - ((candle.close - minPrice) / priceRange * size.height);

      // Draw wick
      canvas.drawLine(Offset(x, highY), Offset(x, lowY), paint);

      // Draw body
      paint.style = PaintingStyle.fill;
      final bodyTop = isGreen ? closeY : openY;
      final bodyBottom = isGreen ? openY : closeY;
      final bodyHeight = (bodyBottom - bodyTop).abs();

      if (bodyHeight > 0) {
        canvas.drawRect(Rect.fromLTWH(x - 2, bodyTop, 4, bodyHeight), paint);
      }

      paint.style = PaintingStyle.stroke;
    }
  }

  void _drawLineChart(
    Canvas canvas,
    Size size,
    double maxPrice,
    double minPrice,
    double priceRange,
  ) {
    final paint =
        Paint()
          ..color = AppColors.primary
          ..strokeWidth = 2
          ..style = PaintingStyle.stroke;

    final path = Path();
    bool firstPoint = true;

    for (int i = 0; i < data.length; i++) {
      final candle = data[i];
      final x = i * (size.width / data.length) + (size.width / data.length) / 2;
      final y =
          size.height - ((candle.close - minPrice) / priceRange * size.height);

      if (firstPoint) {
        path.moveTo(x, y);
        firstPoint = false;
      } else {
        path.lineTo(x, y);
      }
    }

    canvas.drawPath(path, paint);
  }

  void _drawBarChart(
    Canvas canvas,
    Size size,
    double maxPrice,
    double minPrice,
    double priceRange,
  ) {
    final barWidth = size.width / data.length;
    final paint =
        Paint()
          ..strokeWidth = 2
          ..style = PaintingStyle.stroke;

    for (int i = 0; i < data.length; i++) {
      final candle = data[i];
      final x = i * barWidth + barWidth / 2;
      final isGreen = candle.isBullish;

      paint.color = isGreen ? AppColors.success : AppColors.error;

      final highY =
          size.height - ((candle.high - minPrice) / priceRange * size.height);
      final lowY =
          size.height - ((candle.low - minPrice) / priceRange * size.height);

      // Draw high-low line
      canvas.drawLine(Offset(x, highY), Offset(x, lowY), paint);

      // Draw open-close bar
      final openY =
          size.height - ((candle.open - minPrice) / priceRange * size.height);
      final closeY =
          size.height - ((candle.close - minPrice) / priceRange * size.height);

      paint.style = PaintingStyle.fill;
      final barTop = isGreen ? closeY : openY;
      final barBottom = isGreen ? openY : closeY;
      final barHeight = (barBottom - barTop).abs();

      if (barHeight > 0) {
        canvas.drawRect(Rect.fromLTWH(x - 1, barTop, 2, barHeight), paint);
      }

      paint.style = PaintingStyle.stroke;
    }
  }

  void _drawAreaChart(
    Canvas canvas,
    Size size,
    double maxPrice,
    double minPrice,
    double priceRange,
  ) {
    final paint =
        Paint()
          ..color = AppColors.primary.withOpacity(0.3)
          ..style = PaintingStyle.fill;

    final path = Path();
    path.moveTo(0, size.height);

    for (int i = 0; i < data.length; i++) {
      final candle = data[i];
      final x = i * (size.width / data.length) + (size.width / data.length) / 2;
      final y =
          size.height - ((candle.close - minPrice) / priceRange * size.height);
      path.lineTo(x, y);
    }

    path.lineTo(size.width, size.height);
    path.close();
    canvas.drawPath(path, paint);
  }

  void _drawHeikinAshi(
    Canvas canvas,
    Size size,
    double maxPrice,
    double minPrice,
    double priceRange,
  ) {
    final candleWidth = size.width / data.length;
    final paint =
        Paint()
          ..strokeWidth = 1.5
          ..style = PaintingStyle.stroke;

    for (int i = 0; i < data.length; i++) {
      final candle = data[i];
      final x = i * candleWidth + candleWidth / 2;

      // Heikin-Ashi calculation
      final haClose =
          (candle.open + candle.high + candle.low + candle.close) / 4;
      final haOpen =
          i == 0
              ? (candle.open + candle.close) / 2
              : (data[i - 1].open + data[i - 1].close) / 2;
      final haHigh = [
        candle.high,
        haOpen,
        haClose,
      ].reduce((a, b) => a > b ? a : b);
      final haLow = [
        candle.low,
        haOpen,
        haClose,
      ].reduce((a, b) => a < b ? a : b);

      final isGreen = haClose >= haOpen;
      paint.color = isGreen ? AppColors.success : AppColors.error;

      // Calculate Y positions
      final highY =
          size.height - ((haHigh - minPrice) / priceRange * size.height);
      final lowY =
          size.height - ((haLow - minPrice) / priceRange * size.height);
      final openY =
          size.height - ((haOpen - minPrice) / priceRange * size.height);
      final closeY =
          size.height - ((haClose - minPrice) / priceRange * size.height);

      // Draw wick
      canvas.drawLine(Offset(x, highY), Offset(x, lowY), paint);

      // Draw body
      paint.style = PaintingStyle.fill;
      final bodyTop = isGreen ? closeY : openY;
      final bodyBottom = isGreen ? openY : closeY;
      final bodyHeight = (bodyBottom - bodyTop).abs();

      if (bodyHeight > 0) {
        canvas.drawRect(Rect.fromLTWH(x - 2, bodyTop, 4, bodyHeight), paint);
      }

      paint.style = PaintingStyle.stroke;
    }
  }

  void _drawVolume(Canvas canvas, Size size, double maxVolume) {
    final volumeHeight = size.height * 0.2;
    final volumeY = size.height - volumeHeight;
    final barWidth = size.width / data.length;

    final paint = Paint()..style = PaintingStyle.fill;

    for (int i = 0; i < data.length; i++) {
      final candle = data[i];
      final volume = candle.volume.toDouble();
      final barHeight = (volume / maxVolume) * volumeHeight;
      final x = i * barWidth + barWidth * 0.1;
      final y = size.height - barHeight;

      paint.color =
          candle.isBullish
              ? AppColors.success.withOpacity(0.6)
              : AppColors.error.withOpacity(0.6);

      canvas.drawRect(Rect.fromLTWH(x, y, barWidth * 0.8, barHeight), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
