import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TradingViewChartingLibrary extends StatefulWidget {
  final String symbol;
  final String interval;
  final double width;
  final double height;
  final String? libraryPath;

  const TradingViewChartingLibrary({
    super.key,
    required this.symbol,
    required this.interval,
    this.width = 372,
    this.height = 500,
    this.libraryPath,
  });

  @override
  State<TradingViewChartingLibrary> createState() =>
      _TradingViewChartingLibraryState();
}

class _TradingViewChartingLibraryState
    extends State<TradingViewChartingLibrary> {
  InAppWebViewController? _webViewController;
  bool _isLoading = true;
  bool _isError = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: widget.height.h,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8.r),
        color: Colors.white,
      ),
      child: Stack(
        children: [
          InAppWebView(
            initialData: InAppWebViewInitialData(
              data: _getTradingViewHTML(),
              mimeType: 'text/html',
              encoding: 'utf-8',
            ),
            initialOptions: InAppWebViewGroupOptions(
              crossPlatform: InAppWebViewOptions(
                useShouldOverrideUrlLoading: true,
                mediaPlaybackRequiresUserGesture: false,
                useOnLoadResource: true,
                javaScriptEnabled: true,
                cacheEnabled: true,
                clearCache: false,
                disableHorizontalScroll: true,
                disableVerticalScroll: true,
                disableContextMenu: true,
                supportZoom: false,
              ),
              android: AndroidInAppWebViewOptions(
                useHybridComposition: true,
                mixedContentMode:
                    AndroidMixedContentMode.MIXED_CONTENT_ALWAYS_ALLOW,
                overScrollMode: AndroidOverScrollMode.OVER_SCROLL_NEVER,
                displayZoomControls: false,
                builtInZoomControls: false,
              ),
              ios: IOSInAppWebViewOptions(
                allowsInlineMediaPlayback: true,
                allowsBackForwardNavigationGestures: false,
                allowsLinkPreview: false,
              ),
            ),
            onWebViewCreated: (controller) {
              _webViewController = controller;
            },
            onLoadStart: (controller, url) {
              setState(() {
                _isLoading = true;
                _isError = false;
              });
            },
            onLoadStop: (controller, url) {
              setState(() {
                _isLoading = false;
              });
            },
            onLoadError: (controller, url, code, message) {
              setState(() {
                _isError = true;
                _isLoading = false;
              });
            },
            onConsoleMessage: (controller, consoleMessage) {
              print('TradingView Console: ${consoleMessage.message}');
            },
          ),
          if (_isLoading)
            Container(
              width: double.infinity,
              height: widget.height.h,
              color: Colors.white,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                    ),
                    SizedBox(height: 16.h),
                    Text(
                      'Loading TradingView Chart...',
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (_isError)
            Container(
              width: double.infinity,
              height: widget.height.h,
              color: Colors.white,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 48.h, color: Colors.red),
                    SizedBox(height: 16.h),
                    Text(
                      'Failed to load chart',
                      style: TextStyle(
                        fontSize: 16.sp,
                        color: Colors.red,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      'Please check your internet connection',
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 16.h),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _isError = false;
                          _isLoading = true;
                        });
                        _webViewController?.reload();
                      },
                      child: Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  String _getTradingViewHTML() {
    return '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>TradingView Chart</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            overflow: hidden;
        }
        #chart_container {
            width: 100%;
            height: ${widget.height}px;
            position: relative;
        }
        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            color: #666;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div id="chart_container">
        <div class="loading">Loading TradingView Chart...</div>
    </div>

    <script src="https://unpkg.com/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js"></script>
    <script>
        function createChart() {
            try {
                const container = document.getElementById('chart_container');
                const chart = LightweightCharts.createChart(container, {
                    width: container.offsetWidth,
                    height: ${widget.height},
                    layout: {
                        background: { color: '#ffffff' },
                        textColor: '#333',
                    },
                    grid: {
                        vertLines: { color: '#f0f0f0' },
                        horzLines: { color: '#f0f0f0' },
                    },
                    crosshair: {
                        mode: LightweightCharts.CrosshairMode.Normal,
                    },
                    rightPriceScale: {
                        borderColor: '#ddd',
                    },
                    timeScale: {
                        borderColor: '#ddd',
                        timeVisible: true,
                        secondsVisible: false,
                    },
                    handleScroll: {
                        mouseWheel: false,
                        pressedMouseMove: false,
                        horzTouchDrag: true,
                        vertTouchDrag: true,
                    },
                    handleScale: {
                        axisPressedMouseMove: false,
                        mouseWheel: false,
                        pinch: true,
                    },
                });

                const candleSeries = chart.addCandlestickSeries({
                    upColor: '#26a69a',
                    downColor: '#ef5350',
                    borderDownColor: '#ef5350',
                    borderUpColor: '#26a69a',
                    wickDownColor: '#ef5350',
                    wickUpColor: '#26a69a',
                });

                // Generate realistic data for ${widget.symbol}
                const data = [];
                const now = new Date();
                let basePrice = 1.2490;
                
                for (let i = 50; i >= 0; i--) {
                    const time = new Date(now.getTime() - i * 60000); // 1 minute intervals
                    const open = basePrice + (Math.random() - 0.5) * 0.001;
                    const high = open + Math.random() * 0.002;
                    const low = open - Math.random() * 0.002;
                    const close = open + (Math.random() - 0.5) * 0.001;
                    
                    data.push({
                        time: Math.floor(time.getTime() / 1000),
                        open: open,
                        high: high,
                        low: low,
                        close: close,
                    });
                    
                    basePrice = close;
                }

                candleSeries.setData(data);

                // Add volume series
                const volumeSeries = chart.addHistogramSeries({
                    color: '#26a69a',
                    priceFormat: {
                        type: 'volume',
                    },
                    priceScaleId: '',
                    scaleMargins: {
                        top: 0.8,
                        bottom: 0,
                    },
                });

                const volumeData = data.map(item => ({
                    time: item.time,
                    value: 1000 + Math.random() * 1000,
                    color: item.close > item.open ? '#26a69a' : '#ef5350',
                }));

                volumeSeries.setData(volumeData);

                // Real-time updates
                setInterval(() => {
                    const lastCandle = data[data.length - 1];
                    const newTime = Math.floor(Date.now() / 1000);
                    const newOpen = lastCandle.close;
                    const newHigh = newOpen + Math.random() * 0.002;
                    const newLow = newOpen - Math.random() * 0.002;
                    const newClose = newOpen + (Math.random() - 0.5) * 0.001;
                    
                    const newCandle = {
                        time: newTime,
                        open: newOpen,
                        high: newHigh,
                        low: newLow,
                        close: newClose,
                    };
                    
                    candleSeries.update(newCandle);
                    
                    const newVolume = {
                        time: newTime,
                        value: 1000 + Math.random() * 1000,
                        color: newClose > newOpen ? '#26a69a' : '#ef5350',
                    };
                    
                    volumeSeries.update(newVolume);
                    
                    data.push(newCandle);
                    if (data.length > 100) {
                        data.shift();
                    }
                }, 1000);

                // Remove loading message
                document.querySelector('.loading').style.display = 'none';
                
                // Handle resize
                window.addEventListener('resize', () => {
                    chart.applyOptions({
                        width: container.offsetWidth,
                        height: ${widget.height},
                    });
                });
                
            } catch (error) {
                console.error('Chart creation error:', error);
                document.querySelector('.loading').innerHTML = 'Error creating chart: ' + error.message;
            }
        }

        // Wait for library to load
        if (typeof LightweightCharts !== 'undefined') {
            createChart();
        } else {
            // Check every 100ms for library to load
            const checkInterval = setInterval(() => {
                if (typeof LightweightCharts !== 'undefined') {
                    clearInterval(checkInterval);
                    createChart();
                }
            }, 100);
            
            // Fallback after 10 seconds
            setTimeout(() => {
                clearInterval(checkInterval);
                if (typeof LightweightCharts === 'undefined') {
                    document.querySelector('.loading').innerHTML = 'Chart library failed to load. Please check your internet connection.';
                }
            }, 10000);
        }
    </script>
</body>
</html>
    ''';
  }
}
