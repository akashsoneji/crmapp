import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:pipze/core/constants/color.dart';
import 'package:pipze/core/constants/text_styles.dart';
import 'package:pipze/core/services/language_service.dart';
import 'package:pipze/core/services/toast_service.dart';
import 'package:pipze/core/services/secure_storage_service.dart';
import 'package:pipze/core/utils/rtl_helper.dart';
import 'package:pipze/presentation/blocs/auth/auth_bloc.dart';
import 'package:pipze/presentation/blocs/auth/auth_event.dart';
import 'package:pipze/presentation/screens/settings/language_selector_screen.dart';
import 'package:pipze/presentation/screens/getstart/get_started_screen.dart';

import '../screens/getstart/login_screen.dart';

class GlobalDrawer extends StatelessWidget {
  const GlobalDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: languageService,
      builder: (context, child) {
        return Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [_buildDrawerHeader(), _buildDrawerItems(context)],
          ),
        );
      },
    );
  }

  Widget _buildDrawerHeader() {
    return DrawerHeader(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.primary.withOpacity(0.8)],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 30.r,
            backgroundColor: Colors.white,
            child: Icon(Icons.person, size: 40.h, color: AppColors.primary),
          ),
          SizedBox(height: 10.h),
          Text(
            "app_name".tr,
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            "drawer_subtitle".tr,
            style: TextStyle(
              color: Colors.white.withOpacity(0.8),
              fontSize: 14.sp,
            ),
          ),
          SizedBox(height: 8.h),
        ],
      ),
    );
  }

  Widget _buildDrawerItems(BuildContext context) {
    return Column(
      children: [
        // Account Section
        _buildSectionTitle('Account'),
        RTLHelper.rtlListTile(
          title: "Profile",
          leading: RTLHelper.rtlIcon(Icons.person, color: AppColors.primary),
          onTap: () {
            Navigator.pop(context);
            // Navigate to profile
          },
        ),
        RTLHelper.rtlListTile(
          title: "Account Settings",
          leading: RTLHelper.rtlIcon(
            Icons.account_circle,
            color: AppColors.primary,
          ),
          onTap: () {
            Navigator.pop(context);
            // Navigate to account settings
          },
        ),
        RTLHelper.rtlListTile(
          title: "Security Settings",
          leading: RTLHelper.rtlIcon(Icons.security, color: AppColors.primary),
          onTap: () {
            Navigator.pop(context);
            // Navigate to security settings
          },
        ),

        Divider(height: 1.h),

        // Trading Section
        _buildSectionTitle('Trading'),
        RTLHelper.rtlListTile(
          title: "Transaction History",
          leading: RTLHelper.rtlIcon(Icons.history, color: AppColors.primary),
          onTap: () {
            Navigator.pop(context);
            // Navigate to transaction history
          },
        ),
        RTLHelper.rtlListTile(
          title: "Documents",
          leading: RTLHelper.rtlIcon(
            Icons.description,
            color: AppColors.primary,
          ),
          onTap: () {
            Navigator.pop(context);
            // Navigate to documents
          },
        ),
        RTLHelper.rtlListTile(
          title: "more_price_alerts".tr,
          leading: RTLHelper.rtlIcon(
            Icons.notifications,
            color: AppColors.primary,
          ),
          onTap: () {
            Navigator.pop(context);
            // Navigate to price alerts
          },
        ),
        RTLHelper.rtlListTile(
          title: "more_economic_calendar".tr,
          leading: RTLHelper.rtlIcon(
            Icons.calendar_today,
            color: AppColors.primary,
          ),
          onTap: () {
            Navigator.pop(context);
            // Navigate to economic calendar
          },
        ),
        RTLHelper.rtlListTile(
          title: "more_market_news".tr,
          leading: RTLHelper.rtlIcon(Icons.article, color: AppColors.primary),
          onTap: () {
            Navigator.pop(context);
            // Navigate to market news
          },
        ),
        RTLHelper.rtlListTile(
          title: "more_trading_signals".tr,
          leading: RTLHelper.rtlIcon(
            Icons.trending_up,
            color: AppColors.primary,
          ),
          onTap: () {
            Navigator.pop(context);
            // Navigate to trading signals
          },
        ),

        Divider(height: 1.h),

        // Settings Section
        _buildSectionTitle('Settings'),
        RTLHelper.rtlListTile(
          title: "settings_language".tr,
          subtitle: languageService.currentLanguageName,
          leading: RTLHelper.rtlIcon(Icons.language, color: AppColors.primary),
          onTap: () {
            Navigator.pop(context);
            _showLanguageSelector(context);
          },
        ),
        RTLHelper.rtlListTile(
          title: "settings_notifications".tr,
          leading: RTLHelper.rtlIcon(
            Icons.notifications_active,
            color: AppColors.primary,
          ),
          onTap: () {
            Navigator.pop(context);
            // Navigate to notifications settings
          },
        ),
        RTLHelper.rtlListTile(
          title: "settings_theme".tr,
          leading: RTLHelper.rtlIcon(Icons.palette, color: AppColors.primary),
          onTap: () {
            Navigator.pop(context);
            // Navigate to theme settings
          },
        ),

        Divider(height: 1.h),

        // Support Section
        _buildSectionTitle('Support'),
        RTLHelper.rtlListTile(
          title: "settings_help".tr,
          leading: RTLHelper.rtlIcon(Icons.help, color: AppColors.primary),
          onTap: () {
            Navigator.pop(context);
            // Navigate to help
          },
        ),
        RTLHelper.rtlListTile(
          title: "Contact Support",
          leading: RTLHelper.rtlIcon(
            Icons.support_agent,
            color: AppColors.primary,
          ),
          onTap: () {
            Navigator.pop(context);
            // Navigate to contact support
          },
        ),
        RTLHelper.rtlListTile(
          title: "settings_about".tr,
          leading: RTLHelper.rtlIcon(Icons.info, color: AppColors.primary),
          onTap: () {
            Navigator.pop(context);
            // Navigate to about
          },
        ),

        Divider(height: 1.h),

        // Logout Section
        RTLHelper.rtlListTile(
          title: "more_logout".tr,
          leading: RTLHelper.rtlIcon(Icons.logout, color: AppColors.error),
          onTap: () {
            Navigator.pop(context);
            _showLogoutDialog(context);
          },
        ),

        SizedBox(height: 20.h),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      child: Text(
        title,
        style: AppTextStyles.subheading.copyWith(
          fontSize: 12.sp,
          fontWeight: FontWeight.w600,
          color: AppColors.textGrey,
        ),
      ),
    );
  }

  void _showLanguageSelector(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const LanguageSelectorScreen()),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Logout'),
            content: Text('Are you sure you want to logout?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
              TextButton(
                onPressed: () async {
                  // Navigator.pop(context);
                  await SecureStorageService.clearAuthData();
                  // Handle logout logic here
                  context.read<AuthBloc>().add(LogoutRequested());

                  // Show logout success message
                  ContextToastService.showSuccess(
                    context,
                    'Logged out successfully',
                    duration: const Duration(seconds: 2),
                  );

                  // Navigate to get started screen
                  // Future.delayed(const Duration(seconds: 1), () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => LoginScreen()),
                    (route) => false,
                  );

                  // Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen())
                  //
                  // );
                  // });
                },
                child: Text('Logout', style: TextStyle(color: AppColors.error)),
              ),
            ],
          ),
    );
  }
}
