import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pipze/core/constants/color.dart';
import 'package:pipze/core/constants/text_styles.dart';
import 'package:pipze/core/services/price_alert_service.dart';

class PriceAlertDialog extends StatefulWidget {
  final String symbol;
  final double currentPrice;

  const PriceAlertDialog({
    super.key,
    required this.symbol,
    required this.currentPrice,
  });

  @override
  State<PriceAlertDialog> createState() => _PriceAlertDialogState();
}

class _PriceAlertDialogState extends State<PriceAlertDialog> {
  late TextEditingController _priceController;
  late double _targetPrice;
  final bool _isAbove = true; // true for above, false for below
  bool _isLoading = false;
  final FocusNode _priceFocusNode = FocusNode();
  bool _hasPermission = false;

  @override
  void initState() {
    super.initState();
    _targetPrice = widget.currentPrice;
    _priceController = TextEditingController(
      text: _targetPrice.toStringAsFixed(5),
    );
    _checkPermission();
  }

  @override
  void dispose() {
    _priceController.dispose();
    _priceFocusNode.dispose();
    super.dispose();
  }

  Future<void> _checkPermission() async {
    final hasPermission = await PriceAlertService().hasNotificationPermission();
    setState(() {
      _hasPermission = hasPermission;
    });
  }

  void _incrementPrice() {
    setState(() {
      _targetPrice += 0.00001;
      _priceController.text = _targetPrice.toStringAsFixed(5);
    });
  }

  void _decrementPrice() {
    setState(() {
      _targetPrice -= 0.00001;
      _priceController.text = _targetPrice.toStringAsFixed(5);
    });
  }

  void _onPriceChanged(String value) {
    final newPrice = double.tryParse(value);
    if (newPrice != null && newPrice > 0) {
      setState(() {
        _targetPrice = newPrice;
      });
    }
  }

  double _calculatePriceChange() {
    return ((_targetPrice - widget.currentPrice) / widget.currentPrice) * 100;
  }

  void _closeDialog() {
    Navigator.of(context).pop();
  }

  Future<void> _testNotification() async {
    await PriceAlertService().testNotification();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Test notification sent!'),
        backgroundColor: AppColors.success,
      ),
    );
  }

  Future<void> _requestPermission() async {
    final granted = await PriceAlertService().requestPermissions();
    setState(() {
      _hasPermission = granted;
    });
    if (granted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Notification permission granted!'),
          backgroundColor: AppColors.success,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Notification permission denied'),
          backgroundColor: AppColors.error,
        ),
      );
    }
  }

  Future<void> _setAlert() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    try {
      await PriceAlertService().createPriceAlert(
        symbol: widget.symbol,
        targetPrice: _targetPrice,
        isAbove: _isAbove,
      );

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Price alert set for ${widget.symbol}'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to set alert: $e'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 400;
    final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.only(bottom: keyboardHeight),
      child: DraggableScrollableSheet(
        initialChildSize: 0.5,
        minChildSize: 0.4,
        maxChildSize: 0.9, // Increased max size to accommodate keyboard
        builder: (context, scrollController) {
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.r),
                topRight: Radius.circular(20.r),
              ),
            ),
            child: Column(
              children: [
                // Handle bar
                Container(
                  margin: EdgeInsets.only(top: 12.h),
                  width: 40.w,
                  height: 4.h,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2.r),
                  ),
                ),

                // Header with close button
                Padding(
                  padding: EdgeInsets.all(isSmallScreen ? 16.w : 20.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'New price alert',
                        style: AppTextStyles.label.copyWith(
                          fontSize: isSmallScreen ? 18.sp : 20.sp,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Row(
                        children: [
                          Container(
                            width: isSmallScreen ? 24.w : 28.w,
                            height: isSmallScreen ? 24.h : 28.h,
                            decoration: BoxDecoration(
                              color: AppColors.grey.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.help_outline,
                              size: isSmallScreen ? 16.h : 18.h,
                              color: AppColors.textGrey,
                            ),
                          ),
                          SizedBox(width: 12.w),
                          GestureDetector(
                            onTap: _closeDialog,
                            child: Container(
                              width: isSmallScreen ? 24.w : 28.w,
                              height: isSmallScreen ? 24.h : 28.h,
                              decoration: BoxDecoration(
                                color: AppColors.grey.withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.close,
                                size: isSmallScreen ? 16.h : 18.h,
                                color: AppColors.textGrey,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Permission Status
                if (!_hasPermission)
                  Container(
                    margin: EdgeInsets.symmetric(
                      horizontal: isSmallScreen ? 16.w : 20.w,
                    ),
                    padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(
                      color: AppColors.error.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8.r),
                      border: Border.all(
                        color: AppColors.error.withOpacity(0.3),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.warning, color: AppColors.error, size: 20.h),
                        SizedBox(width: 8.w),
                        Expanded(
                          child: Text(
                            'Notification permission required',
                            style: AppTextStyles.label.copyWith(
                              fontSize: 14.sp,
                              color: AppColors.error,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: _requestPermission,
                          child: Text(
                            'Grant',
                            style: AppTextStyles.label.copyWith(
                              fontSize: 14.sp,
                              color: AppColors.primary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                // Content
                Expanded(
                  child: SingleChildScrollView(
                    controller: scrollController,
                    padding: EdgeInsets.symmetric(
                      horizontal: isSmallScreen ? 16.w : 20.w,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Price Input Section
                        Text(
                          'Price',
                          style: AppTextStyles.label.copyWith(
                            fontSize: isSmallScreen ? 14.sp : 16.sp,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        SizedBox(height: 12.h),

                        // Price Input Container
                        Container(
                          width: double.infinity,
                          height: isSmallScreen ? 60.h : 70.h,
                          decoration: BoxDecoration(
                            color: Colors.grey[50],
                            borderRadius: BorderRadius.circular(12.r),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Row(
                            children: [
                              // Minus Button
                              SizedBox(
                                width: isSmallScreen ? 50.w : 60.w,
                                child: IconButton(
                                  onPressed: _decrementPrice,
                                  icon: Icon(
                                    Icons.remove,
                                    size: isSmallScreen ? 20.h : 24.h,
                                    color: AppColors.textGrey,
                                  ),
                                ),
                              ),

                              // Price Text Field
                              Expanded(
                                child: TextField(
                                  controller: _priceController,
                                  focusNode: _priceFocusNode,
                                  keyboardType: TextInputType.numberWithOptions(
                                    decimal: true,
                                  ),
                                  textAlign: TextAlign.center,
                                  style: AppTextStyles.label.copyWith(
                                    fontSize: isSmallScreen ? 18.sp : 20.sp,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.textPrimary,
                                  ),
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    errorBorder: InputBorder.none,
                                    focusedErrorBorder: InputBorder.none,
                                    disabledBorder: InputBorder.none,
                                    contentPadding: EdgeInsets.zero,
                                    isDense: true,
                                  ),
                                  onChanged: _onPriceChanged,
                                ),
                              ),

                              // Plus Button
                              SizedBox(
                                width: isSmallScreen ? 50.w : 60.w,
                                child: IconButton(
                                  onPressed: _incrementPrice,
                                  icon: Icon(
                                    Icons.add,
                                    size: isSmallScreen ? 20.h : 24.h,
                                    color: AppColors.primary,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 20.h),

                        // Price Details
                        Container(
                          padding: EdgeInsets.all(isSmallScreen ? 16.w : 20.w),
                          decoration: BoxDecoration(
                            color: AppColors.grey.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          child: Column(
                            children: [
                              // Price Change
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Price change',
                                    style: AppTextStyles.label.copyWith(
                                      fontSize: isSmallScreen ? 14.sp : 16.sp,
                                      color: AppColors.textGrey,
                                    ),
                                  ),
                                  Text(
                                    '${_calculatePriceChange().toStringAsFixed(2)}%',
                                    style: AppTextStyles.label.copyWith(
                                      fontSize: isSmallScreen ? 14.sp : 16.sp,
                                      fontWeight: FontWeight.w600,
                                      color:
                                          _calculatePriceChange() >= 0
                                              ? AppColors.success
                                              : AppColors.error,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 12.h),

                              // Current Bid Price
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Current bid price',
                                    style: AppTextStyles.label.copyWith(
                                      fontSize: isSmallScreen ? 14.sp : 16.sp,
                                      color: AppColors.textGrey,
                                    ),
                                  ),
                                  Text(
                                    widget.currentPrice.toStringAsFixed(5),
                                    style: AppTextStyles.label.copyWith(
                                      fontSize: isSmallScreen ? 14.sp : 16.sp,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.textPrimary,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 20.h),

                        // Test Notification Button
                        SizedBox(
                          width: double.infinity,
                          height: isSmallScreen ? 40.h : 45.h,
                          child: OutlinedButton(
                            onPressed: _testNotification,
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: AppColors.primary),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.r),
                              ),
                            ),
                            child: Text(
                              'Test Notification',
                              style: AppTextStyles.button.copyWith(
                                fontSize: isSmallScreen ? 14.sp : 16.sp,
                                fontWeight: FontWeight.w600,
                                color: AppColors.primary,
                              ),
                            ),
                          ),
                        ),

                        SizedBox(height: 20.h),

                        // Set Alert Button
                        SizedBox(
                          width: double.infinity,
                          height: isSmallScreen ? 50.h : 56.h,
                          child: ElevatedButton(
                            onPressed: _isLoading ? null : _setAlert,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primary,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.r),
                              ),
                              elevation: 0,
                            ),
                            child:
                                _isLoading
                                    ? SizedBox(
                                      width: isSmallScreen ? 20.w : 24.w,
                                      height: isSmallScreen ? 20.h : 24.h,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                              Colors.white,
                                            ),
                                      ),
                                    )
                                    : Text(
                                      'Set alert',
                                      style: AppTextStyles.button.copyWith(
                                        fontSize: isSmallScreen ? 16.sp : 18.sp,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white,
                                      ),
                                    ),
                          ),
                        ),

                        SizedBox(height: 20.h),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
