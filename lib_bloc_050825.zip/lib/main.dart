import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'core/constants/color.dart';
import 'core/services/language_service.dart';
import 'core/services/price_alert_service.dart';
import 'core/services/secure_storage_service.dart';
import 'data/repositories/account_repository.dart';
import 'data/repositories/auth_repository.dart';
import 'presentation/blocs/account/account_bloc.dart';
import 'presentation/blocs/auth/auth_bloc.dart';
import 'presentation/blocs/auth/auth_event.dart';
import 'presentation/screens/splash/splash_screen.dart';
import 'presentation/screens/trading/instruments_screen.dart';
import 'routes/app_router.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize services
  await PriceAlertService().initialize();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(
        375,
        812,
      ), // match your Figma base size (width x height)
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MultiBlocProvider(
          providers: [
            BlocProvider<AuthBloc>(
              create:
                  (context) => AuthBloc(authRepository: AuthRepositoryImpl()),
            ),
            BlocProvider<InstrumentsBloc>(
              create: (context) => InstrumentsBloc(),
            ),
            BlocProvider<AccountBloc>(
              create:
                  (context) =>
                      AccountBloc(accountRepository: AccountRepositoryImpl()),
            ),
          ],
          child: ListenableBuilder(
            listenable: languageService,
            builder: (context, child) {
              final isRTL = languageService.isRTL;

              return Directionality(
                textDirection: isRTL ? TextDirection.rtl : TextDirection.ltr,
                child: MaterialApp(
                  navigatorKey: navigatorKey,
                  title: languageService.tr('app_name'),
                  debugShowCheckedModeBanner: false,
                  locale: languageService.locale,
                  theme: ThemeData(
                    // scaffoldBackgroundColor: AppColors.backgroundLight,
                    primaryColor: AppColors.primary,
                    // RTL-aware theme configuration
                    // appBarTheme: AppBarTheme(
                    //   backgroundColor: AppColors.primary,
                    //   // foregroundColor: Colors.white,
                    //   elevation: 0,
                    //   centerTitle: true,
                    //   titleTextStyle: TextStyle(
                    //     color: Colors.black,
                    //     fontSize: 18.sp,
                    //     fontWeight: FontWeight.w600,
                    //   ),
                    // ),
                    // RTL-aware input decoration theme
                    inputDecorationTheme: InputDecorationTheme(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: AppColors.primary,
                          width: 2,
                        ),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: AppColors.error),
                      ),
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                        vertical: 14.h,
                      ),
                      // RTL-aware label alignment
                      alignLabelWithHint: true,
                      floatingLabelAlignment:
                          isRTL
                              ? FloatingLabelAlignment.start
                              : FloatingLabelAlignment.start,
                    ),
                    // RTL-aware elevated button theme
                    elevatedButtonTheme: ElevatedButtonThemeData(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.symmetric(vertical: 16.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                      ),
                    ),
                    // RTL-aware card theme
                    cardTheme: CardThemeData(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      margin: EdgeInsets.symmetric(vertical: 8.h),
                    ),
                    // RTL-aware list tile theme
                    listTileTheme: ListTileThemeData(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16.w),
                      minLeadingWidth: 0,
                      leadingAndTrailingTextStyle: TextStyle(
                        fontSize: 14.sp,
                        color: AppColors.textGrey,
                      ),
                    ),
                    // RTL-aware drawer theme
                    drawerTheme: DrawerThemeData(
                      backgroundColor: Colors.white,
                      elevation: 16,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(20.r),
                          bottomRight: Radius.circular(20.r),
                        ),
                      ),
                    ),
                    // RTL-aware bottom navigation theme
                    bottomNavigationBarTheme: BottomNavigationBarThemeData(
                      backgroundColor: Colors.white,
                      selectedItemColor: AppColors.primary,
                      unselectedItemColor: AppColors.textGrey,
                      type: BottomNavigationBarType.fixed,
                      elevation: 8,
                    ),
                  ),
                  onGenerateRoute: AppRouter.generateRoute,
                  home: child,
                ),
              );
            },
          ),
        );
      },
      child: const SplashScreen(), // or your root screen
    );
  }
}
