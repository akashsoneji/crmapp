import 'package:flutter/material.dart';
import 'package:pipze/presentation/screens/getstart/login_screen.dart';
import 'package:pipze/presentation/screens/splash/splash_screen.dart';
import '../presentation/screens/onboarding/create_account_screen.dart';
import '../presentation/screens/onboarding/legal_documents_screen.dart';
import '../presentation/screens/onboarding/privacy_policy_screen.dart';
import '../presentation/screens/onboarding/account_created_screen.dart';
import '../presentation/screens/auth/forgot_password_screen.dart';
import '../presentation/screens/auth/verify_code_screen.dart';
import '../presentation/screens/auth/create_new_password_screen.dart';
import '../presentation/screens/trading/trading_main_screen.dart';
import '../presentation/screens/demo/toast_demo_screen.dart';
import '../presentation/screens/settings/language_selector_screen.dart';
import '../presentation/screens/settings/account_management_screen.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case '/login':
        return MaterialPageRoute(builder: (_) => const LoginScreen());
      case '/create-account':
        return MaterialPageRoute(builder: (_) => const CreateAccountScreen());
      case '/legal-documents':
        return MaterialPageRoute(builder: (_) => const LegalDocumentsScreen(registrationData: {},));
      case '/privacy-policy':
        return MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen());
      case '/account-created':
        return MaterialPageRoute(builder: (_) => const AccountCreatedScreen());
      case '/forgot-password':
        return MaterialPageRoute(builder: (_) => const ForgotPasswordScreen());
      case '/verify-code':
        return MaterialPageRoute(
          builder: (_) => const VerifyCodeScreen(email: ''),
        );
      case '/create-new-password':
        return MaterialPageRoute(
          builder: (_) => const CreateNewPasswordScreen(),
        );
      case '/trading':
        return MaterialPageRoute(builder: (_) => const TradingMainScreen());
      case '/toast-demo':
        return MaterialPageRoute(builder: (_) => const ToastDemoScreen());
      case '/language-selector':
        return MaterialPageRoute(
          builder: (_) => const LanguageSelectorScreen(),
        );
      case '/account-management':
        return MaterialPageRoute(
          builder: (_) => const AccountManagementScreen(),
        );
      default:
        return MaterialPageRoute(builder: (_) => const CreateAccountScreen());
    }
  }
}
