import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:crm_app/constants/color.dart';
import 'package:crm_app/constants/text_styles.dart';
import 'package:crm_app/controllers/trading_controller.dart';
import 'package:crm_app/controllers/chart_socket_controller.dart';
import 'package:crm_app/controllers/account_controller.dart';
import 'package:crm_app/widgets/fixed_size_webview.dart';
import 'package:crm_app/widgets/custom_toast.dart';
import 'package:crm_app/utils/precision_helper.dart';
import 'package:crm_app/models/order_types.dart';
import 'package:crm_app/services/trading_websocket_service.dart';
import 'package:crm_app/routes/app_pages.dart';
import 'pending_order_content.dart';
import 'dart:async';

class PendingOrderScreen extends StatefulWidget {
  final String? symbol;
  final Function(int?)?
  onNavigateToTrade; // Optional tab parameter: null = Market (0), or specify tab index

  const PendingOrderScreen({super.key, this.symbol, this.onNavigateToTrade});

  @override
  State<PendingOrderScreen> createState() => _PendingOrderScreenState();
}

class _PendingOrderScreenState extends State<PendingOrderScreen> {
  // Controllers
  late final ChartSocketController chartSocketController;
  late final AccountController accountController;
  late final TradingController tradingController;

  // Order type selection (0: Sell Limit/Sell Stop, 1: Buy Limit/Buy Stop)
  // Default to 1 (Buy Limit) to match dropdown default
  final ValueNotifier<int> _selectedPendingOrderType = ValueNotifier(1);

  // Selected order type from dropdown (Buy Limit, Sell Limit, Buy Stop, Sell Stop)
  final ValueNotifier<String> _selectedOrderType = ValueNotifier('Buy Limit');

  // Price and distance
  final ValueNotifier<double> _limitPrice = ValueNotifier(1.15505);
  final ValueNotifier<double> _openPrice = ValueNotifier(1.15505);
  final ValueNotifier<double> _distance = ValueNotifier(0.0);

  // Toggle states
  final ValueNotifier<bool> _whenPriceIsEnabled = ValueNotifier(true);
  final ValueNotifier<bool> _takeProfitEnabled = ValueNotifier(false);
  final ValueNotifier<bool> _stopLossEnabled = ValueNotifier(false);

  // TP/SL prices
  final ValueNotifier<double> _takeProfitPrice = ValueNotifier(0.0);
  final ValueNotifier<double> _stopLossPrice = ValueNotifier(0.0);

  // Text controllers
  late TextEditingController _takeProfitController;
  late TextEditingController _stopLossController;
  late TextEditingController _limitPriceController;

  // Chart toggle
  bool showChart = false;

  // Selected symbol
  String selectedSymbol = 'EURUSD';

  // Volume
  double volume = 0.01;

  // Stream subscription
  StreamSubscription<Map<String, dynamic>>? _priceStreamSubscription;

  // Loading state to prevent multiple clicks
  bool _isPlacingOrder = false;

  @override
  void initState() {
    super.initState();

    // Initialize controllers
    chartSocketController = Get.find<ChartSocketController>();
    accountController = Get.find<AccountController>();
    tradingController = Get.find<TradingController>();

    // Initialize text controllers
    _takeProfitController = TextEditingController();
    _stopLossController = TextEditingController();
    _limitPriceController = TextEditingController();

    // Set symbol
    if (widget.symbol != null) {
      selectedSymbol = widget.symbol!;
      chartSocketController.changeSymbol(selectedSymbol);
    } else {
      // Try to get current symbol, default to EURUSD
      final currentSymbol = chartSocketController.currentSymbol.value;
      if (currentSymbol.isNotEmpty) {
        selectedSymbol = currentSymbol;
      }
    }

    // Initialize prices from chart socket
    _initializePrices();

    // Listen to price updates
    _listenToPriceUpdates();
  }

  void _initializePrices() {
    final bid = chartSocketController.getBidPrice() ?? 1.15505;
    final ask = chartSocketController.getAskPrice() ?? 1.15510;

    // Set initial prices based on selected order type
    if (_selectedPendingOrderType.value == 0) {
      // Sell Limit - use bid price
      _limitPrice.value = bid;
      _openPrice.value = bid;
    } else {
      // Buy Limit - use ask price
      _limitPrice.value = ask;
      _openPrice.value = ask;
    }

    _limitPriceController.text = _limitPrice.value.toString();
  }

  void _listenToPriceUpdates() {
    _priceStreamSubscription = chartSocketController.priceStream.listen((
      priceData,
    ) {
      if (mounted) {
        final bid = chartSocketController.getBidPrice();
        final ask = chartSocketController.getAskPrice();

        if (bid != null && ask != null) {
          // Update prices based on selected order type
          if (_selectedPendingOrderType.value == 0) {
            // Sell Limit
            _openPrice.value = bid;
          } else {
            // Buy Limit
            _openPrice.value = ask;
          }
        }
      }
    });
  }

  Future<void> _placePendingOrder() async {
    // Prevent multiple clicks - set loading state immediately
    if (_isPlacingOrder) return;

    setState(() {
      _isPlacingOrder = true;
    });

    try {
      final activeAccount = accountController.activeMT5Account;
      if (activeAccount == null) {
        CustomToastService.showError(
          title: 'Error',
          message: 'No active account found',
        );
        return;
      }

      // Set current symbol
      tradingController.setCurrentSymbol(selectedSymbol);

      // Determine order type from dropdown selection
      OrderType orderType;
      final selectedOrderTypeStr = _selectedOrderType.value;

      switch (selectedOrderTypeStr) {
        case 'Buy Limit':
          orderType = OrderType.buyLimit;
          break;
        case 'Sell Limit':
          orderType = OrderType.sellLimit;
          break;
        default:
          // Fallback to Buy Limit if somehow invalid
          orderType = OrderType.buyLimit;
          break;
      }

      // Get decimal digits from price data
      final priceData = chartSocketController.getCurrentPrice();
      final decimals =
          priceData != null && priceData.containsKey('digits')
              ? (int.tryParse(priceData['digits'].toString()) ?? 5)
              : 5;

      // Format values properly
      final volumeStr = volume.toString();

      final limitPriceControllerValue = _limitPriceController.text.trim();
      final limitPriceFromController =
          limitPriceControllerValue.isNotEmpty
              ? double.tryParse(limitPriceControllerValue)
              : null;

      // All dropdown order types (Buy Limit, Sell Limit) require a price
      final requiresPrice =
          selectedOrderTypeStr == 'Buy Limit' ||
          selectedOrderTypeStr == 'Sell Limit';

      final price =
          requiresPrice
              ? PrecisionHelper.formatPrice(
                PrecisionHelper.parseDouble(
                  (limitPriceFromController != null &&
                          limitPriceFromController > 0)
                      ? limitPriceControllerValue
                      : _limitPrice.value.toString(),
                  decimals: decimals,
                ),
                decimals: decimals,
              )
              : null;

      final takeProfit =
          _takeProfitEnabled.value
              ? PrecisionHelper.formatPrice(
                PrecisionHelper.parseDouble(
                  _takeProfitPrice.value.toString(),
                  decimals: decimals,
                ),
                decimals: decimals,
              )
              : null;

      final stopLoss =
          _stopLossEnabled.value
              ? PrecisionHelper.formatPrice(
                PrecisionHelper.parseDouble(
                  _stopLossPrice.value.toString(),
                  decimals: decimals,
                ),
                decimals: decimals,
              )
              : null;

      // Place the order using TradingController
      final success = await tradingController.placeTradeOrder(
        symbol: selectedSymbol,
        volume: volumeStr,
        orderType: orderType,
        price: price,
        takeProfit: takeProfit,
        stopLoss: stopLoss,
        mt5Account: activeAccount.metaAccountNumber,
      );

      if (success) {
        // Store the navigation callback before closing the screen
        final navigateCallback = widget.onNavigateToTrade;

        // Close the pending order screen first
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        } else {
          Get.back();
        }

        // Construct minimal order data from available context
        // Since TradingController.placeTradeOrder() only returns boolean,
        // we construct order data from the placement context
        final orderData = {
          'status': true,
          'message': 'Order placed successfully',
          'data': {
            'order_id': null, // Will be populated by WebSocket
            'position_id': null, // Will be populated by WebSocket
            'price': price,
          },
        };

        // Navigate to order confirmation screen with tab index 1 (Pending tab)
        Get.toNamed(
          Routes.ORDER_CONFIRMATION,
          arguments: {
            'orderData': orderData,
            'symbol': selectedSymbol,
            'orderType': orderType.value.toString(),
            'volume': volume,
            'price': price != null ? double.tryParse(price) : null,
            'executionPrice': price,
            'positionId': null,
            'orderId': null,
            'tabIndex': 1, // Pending tab
            'onNavigateToTrade': navigateCallback,
            'isPlacing': false,
          },
        );

        // After 30ms, navigate to trade screen with Pending tab
        await Future.delayed(const Duration(milliseconds: 30));

        if (navigateCallback != null) {
          // Pass tab index 1 (Pending) to show the newly placed order
          navigateCallback(1);
        }

        // Pre-connect WebSocket in background (non-blocking, fire and forget)
        // This ensures instant pending order updates when user switches to Pending tab
        if (Get.isRegistered<TradingWebSocketService>()) {
          final wsService = Get.find<TradingWebSocketService>();
          wsService.ensurePendingOrdersConnection().catchError((e) {
            if (kDebugMode) {
              print(
                'Pending Order Screen: Error ensuring pending orders connection: $e',
              );
            }
          });
        }

        // Return immediately
        return;
      } else {
        CustomToastService.showError(
          title: 'Error',
          message:
              tradingController.errorMessage.isNotEmpty
                  ? tradingController.errorMessage
                  : 'Failed to place order',
        );
      }
    } catch (e) {
      CustomToastService.showError(
        title: 'Error',
        message: 'Failed to place order: $e',
      );
    } finally {
      // Always re-enable button after order placement completes
      if (mounted) {
        setState(() {
          _isPlacingOrder = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _priceStreamSubscription?.cancel();
    _takeProfitController.dispose();
    _stopLossController.dispose();
    _limitPriceController.dispose();
    _selectedPendingOrderType.dispose();
    _selectedOrderType.dispose();
    _limitPrice.dispose();
    _openPrice.dispose();
    _distance.dispose();
    _whenPriceIsEnabled.dispose();
    _takeProfitEnabled.dispose();
    _stopLossEnabled.dispose();
    _takeProfitPrice.dispose();
    _stopLossPrice.dispose();
    super.dispose();
  }

  /// Get the flag SVG path based on the instrument symbol
  String _getFlagPath(String symbol) {
    String cleanSymbol =
        symbol.contains('.')
            ? symbol.substring(0, symbol.lastIndexOf('.'))
            : symbol;
    return 'assets/svg/flags/${cleanSymbol.toLowerCase()}.svg';
  }

  /// Check if asset exists by trying to load it
  Future<String?> _checkAssetExists(String assetPath) async {
    try {
      await DefaultAssetBundle.of(context).load(assetPath);
      return assetPath;
    } catch (e) {
      return null;
    }
  }

  /// Build flag icon widget with error handling
  Widget _buildFlagIcon(String symbol, {double? size}) {
    final flagSize = size ?? 24.h;
    final containerSize = flagSize + 16.h;
    final iconSize = flagSize;
    final flagPath = _getFlagPath(symbol);

    return FutureBuilder<String?>(
      future: _checkAssetExists(flagPath),
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data != null) {
          return Container(
            width: containerSize,
            height: containerSize,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Padding(
              padding: EdgeInsets.all(4.w),
              child: SvgPicture.asset(
                flagPath,
                width: iconSize,
                height: iconSize,
                fit: BoxFit.cover,
              ),
            ),
          );
        }
        return _buildFallbackFlag(flagSize, containerSize, iconSize);
      },
    );
  }

  /// Build fallback flag image widget
  Widget _buildFallbackFlag(
    double flagSize,
    double containerSize,
    double iconSize,
  ) {
    return Container(
      width: containerSize,
      height: containerSize,
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4.r),
          child: Image.asset(
            'assets/image/noflag.jpeg',
            width: iconSize,
            height: iconSize,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                width: iconSize,
                height: iconSize,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(4.r),
                ),
                child: Image.asset(
                  'assets/image/no_flag_icon.png',
                  width: iconSize,
                  height: iconSize,
                  fit: BoxFit.cover,
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  // Helper method to get symbol without .c suffix
  String get _displaySymbol => selectedSymbol.replaceFirst('.c', '');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        backgroundColor: Colors.white,
        scrolledUnderElevation: 0,
        elevation: 0,
        toolbarHeight: 72.h,
        centerTitle: false,
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: SvgPicture.asset(
            'assets/svg/trade/arro_back.svg',
            width: 256.w,
            height: 30.h,
          ),
        ),
        titleSpacing: 0,
        title: ValueListenableBuilder<String>(
          valueListenable: _selectedOrderType,
          builder: (context, orderType, child) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _buildFlagIcon(selectedSymbol, size: 20.h),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Pending Order',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTextStyles.heading.copyWith(
                              fontSize: 18.sp,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            '$orderType $_displaySymbol',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTextStyles.label.copyWith(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w400,
                              color: AppColors.textGrey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
        actions: [SizedBox(width: 16.w)],
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Column(
              children: [
                // Current Prices (Bid/Ask) - Above Chart
                Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 16.w,
                    vertical: 12.h,
                  ),
                  child: _buildCurrentPrices(),
                ),

                // Chart Section
                _buildChartSection(),

                // Main Content
                Expanded(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.all(16.w),
                    child: PendingOrderContent(
                      selectedPendingOrderType: _selectedPendingOrderType,
                      selectedOrderType: _selectedOrderType,
                      limitPrice: _limitPrice,
                      openPrice: _openPrice,
                      distance: _distance,
                      whenPriceIsEnabled: _whenPriceIsEnabled,
                      takeProfitEnabled: _takeProfitEnabled,
                      stopLossEnabled: _stopLossEnabled,
                      takeProfitPrice: _takeProfitPrice,
                      stopLossPrice: _stopLossPrice,
                      takeProfitController: _takeProfitController,
                      stopLossController: _stopLossController,
                      limitPriceController: _limitPriceController,
                      onPlaceOrder: _placePendingOrder,
                      selectedSymbol: selectedSymbol,
                      isLoading: _isPlacingOrder,
                      onVolumeChanged: (newVolume) {
                        setState(() {
                          volume = newVolume;
                        });
                      },
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildCurrentPrices() {
    return Container(
      padding: EdgeInsets.all(5.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Bid Price (from Chart Socket)
          Column(
            children: [
              Text(
                'Bid',
                style: AppTextStyles.label.copyWith(
                  fontSize: 10.sp,
                  color: AppColors.textGrey,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 2.h),
              Obx(() {
                final bid = chartSocketController.getBidPrice() ?? 0.0;
                return Text(
                  bid.toString(),
                  style: AppTextStyles.heading.copyWith(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w700,
                    color: AppColors.error,
                  ),
                );
              }),
            ],
          ),
          Container(width: 2.w, height: 30.h, color: AppColors.border),
          // Ask Price (from Chart Socket)
          Column(
            children: [
              Text(
                'Ask',
                style: AppTextStyles.label.copyWith(
                  fontSize: 10.sp,
                  color: AppColors.textGrey,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 2.h),
              Obx(() {
                final ask = chartSocketController.getAskPrice() ?? 0.0;
                return Text(
                  ask.toString(),
                  style: AppTextStyles.heading.copyWith(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                );
              }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildChartSection() {
    return Container(
      height: showChart ? MediaQuery.of(context).size.height * 0.4 : 64.h,
      child: Column(
        children: [
          // Chart Header with Toggle
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 8.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Chart',
                  style: AppTextStyles.label.copyWith(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                Row(
                  children: [
                    // Chart On/Off Toggle
                    Transform.scale(
                      scale: 0.9,
                      child: Switch(
                        value: showChart,
                        onChanged: (value) {
                          setState(() {
                            showChart = value;
                          });
                        },
                        activeColor: AppColors.primary,
                        activeTrackColor: AppColors.primary.withOpacity(0.3),
                        inactiveThumbColor: AppColors.whiteColor,
                        inactiveTrackColor: AppColors.icongrey.withAlpha(55),
                        trackOutlineColor: WidgetStateProperty.all(
                          Colors.transparent,
                        ),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Chart WebView (only when chart is enabled)
          if (showChart)
            Expanded(
              child: FixedSizeWebView(
                key: ValueKey(
                  selectedSymbol,
                ), // Force update when symbol changes
                symbol: selectedSymbol.replaceFirst('.c', ''),
                url: '',
              ),
            ),
        ],
      ),
    );
  }
}
