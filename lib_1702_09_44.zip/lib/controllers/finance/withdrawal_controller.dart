// WithdrawalMethodDetailResponse model
import 'dart:convert';
import 'dart:io';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:http/http.dart' as http;

import '../../constants/api_const.dart';
import '../../models/mt5_account.dart';
import '../../services/api_service.dart';
import '../../services/secure_storage_service.dart';

class WithdrawalMethodDetailResponse {
  final bool? status;
  final String? message;
  final WithdrawalMethodDetailData? data;

  WithdrawalMethodDetailResponse({this.status, this.message, this.data});

  factory WithdrawalMethodDetailResponse.fromJson(Map<String, dynamic> json) {
    return WithdrawalMethodDetailResponse(
      status: json['status'],
      message: json['message'],
      data:
          json['data'] != null
              ? WithdrawalMethodDetailData.fromJson(json['data'])
              : null,
    );
  }
}

class WithdrawalMethodDetailData {
  final WithdrawalMethod? withdrawalMethod;
  final List<dynamic>? userWithdrawalMethods;
  final List<MT5Account>? userMT5Accounts;
  final Wallet? wallet;
  final IbAccount? ibaccount;

  WithdrawalMethodDetailData({
    this.withdrawalMethod,
    this.userWithdrawalMethods,
    this.userMT5Accounts,
    this.wallet,
    this.ibaccount,
  });

  factory WithdrawalMethodDetailData.fromJson(Map<String, dynamic> json) {
    return WithdrawalMethodDetailData(
      withdrawalMethod:
          json['withdrawalMethod'] != null
              ? WithdrawalMethod.fromJson(json['withdrawalMethod'])
              : null,
      userWithdrawalMethods: json['userWithdrawalMethods'] ?? [],
      userMT5Accounts:
          json['userMT5Accounts'] != null && json['userMT5Accounts'] is List
              ? List<MT5Account>.from(
                json['userMT5Accounts'].map((x) => MT5Account.fromJson(x)),
              )
              : [],
      wallet: json['wallet'] != null ? Wallet.fromJson(json['wallet']) : null,
      ibaccount:
          json['ibaccount'] != null && json['ibaccount'] is Map<String, dynamic>
              ? IbAccount.fromJson(json['ibaccount'])
              : null,
    );
  }
}

class Wallet {
  final int? id;
  final String? walletId;
  final String? walletStatus;
  final String? walletBalance;

  Wallet({this.id, this.walletId, this.walletStatus, this.walletBalance});

  factory Wallet.fromJson(Map<String, dynamic> json) {
    return Wallet(
      id:
          json['id'] is int
              ? json['id']
              : int.tryParse(json['id']?.toString() ?? ''),
      walletId: json['wallet_id']?.toString(),
      walletStatus: json['wallet_status']?.toString(),
      walletBalance: json['wallet_balance']?.toString(),
    );
  }
}

class IbAccount {
  final int? id;
  final String? promotionTool;
  final String? status;

  IbAccount({this.id, this.promotionTool, this.status});

  factory IbAccount.fromJson(Map<String, dynamic> json) {
    return IbAccount(
      id:
          json['id'] is int
              ? json['id']
              : int.tryParse(json['id']?.toString() ?? ''),
      promotionTool: json['promotion_tool']?.toString(),
      status: json['status']?.toString(),
    );
  }
}

// WithdrawalMethodResponse model
class WithdrawalMethodResponse {
  final bool status;
  final String message;
  final List<WithdrawalMethod> data;

  WithdrawalMethodResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory WithdrawalMethodResponse.fromJson(Map<String, dynamic> json) {
    return WithdrawalMethodResponse(
      status: json['status'] ?? false,
      message: json['message'] ?? '',
      data:
          (json['data'] as List<dynamic>?)
              ?.map((e) => WithdrawalMethod.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() => {
    'status': status,
    'message': message,
    'data': data.map((e) => e.toJson()).toList(),
  };
}

// WithdrawalMethod model
class WithdrawalMethod {
  final int? id;
  final String? methodName;
  final String? methodSlug;
  final String? averageLabel;
  final String? uptoLabel;
  final String? minLimit;
  final String? maxLimit;
  final String? fees;
  final String? status;
  final int? updatedBy;
  final String? role;
  final String? icon;
  final String? createdAt;
  final String? updatedAt;
  final String? deletedAt;

  WithdrawalMethod({
    this.id,
    this.methodName,
    this.methodSlug,
    this.averageLabel,
    this.uptoLabel,
    this.minLimit,
    this.maxLimit,
    this.fees,
    this.status,
    this.updatedBy,
    this.role,
    this.icon,
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
  });

  factory WithdrawalMethod.fromJson(Map<String, dynamic> json) {
    return WithdrawalMethod(
      id:
          json['id'] is int
              ? json['id']
              : int.tryParse(json['id']?.toString() ?? ''),
      methodName: json['method_name']?.toString(),
      methodSlug: json['method_slug']?.toString(),
      averageLabel: json['average_label']?.toString(),
      uptoLabel: json['upto_label']?.toString(),
      minLimit: json['min_limit']?.toString(),
      maxLimit: json['max_limit']?.toString(),
      fees: json['fees']?.toString(),
      status: json['status']?.toString(),
      updatedBy:
          json['updated_by'] is int
              ? json['updated_by']
              : int.tryParse(json['updated_by']?.toString() ?? ''),
      role: json['role']?.toString(),
      icon: json['icon']?.toString(),
      createdAt: json['created_at']?.toString(),
      updatedAt: json['updated_at']?.toString(),
      deletedAt: json['deleted_at']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'method_name': methodName,
    'method_slug': methodSlug,
    'average_label': averageLabel,
    'upto_label': uptoLabel,
    'min_limit': minLimit,
    'max_limit': maxLimit,
    'fees': fees,
    'status': status,
    'updated_by': updatedBy,
    'role': role,
    'icon': icon,
    'created_at': createdAt,
    'updated_at': updatedAt,
    'deleted_at': deletedAt,
  };
}

class WithdrawalController extends GetxController {
  final _isLoading = false.obs;
  final errorMessage = ''.obs; // Made public for reactive listening
  final successMessage = ''.obs; // Made public for reactive listening

  bool get isLoading => _isLoading.value;

  var withdrawalMethods = <WithdrawalMethod>[].obs;
  final selectedAccount = Rxn<String>();
  final selectedBankAccount = Rxn<String>();
  final selectedCryptoAccount = Rxn<String>();
  final withdrawalAmount = ''.obs;
  final selectedPaymentMethod = ''.obs;
  final selectedWithdrawalMethod =
      Rxn<
        WithdrawalMethod
      >(); // Add this to hold the complete withdrawal method object
  String? _preselectedAccountNumber; // Store preselected account number
  final isOtpSent = false.obs;
  final isOtpLoading = false.obs;

  var userMT5Accounts = <MT5Account>[].obs;
  var wallet = Rxn<Wallet>();
  var ibAccount = Rxn<IbAccount>();
  var withdrawalMethodDetail = Rxn<WithdrawalMethodDetailResponse>();

  // Flag to show "no data" view when API returns status: false with message
  final showNoDataView = false.obs;
  final noDataMessage = ''.obs;

  // Flag to track if we've received the initial response (prevents flash of form)
  final hasReceivedInitialResponse = false.obs;

  @override
  void onInit() {
    super.onInit();
    // Initialize flags
    hasReceivedInitialResponse.value = false;
    showNoDataView.value = false;
    fetchWithdrawalAccounts();
  }

  Future<void> fetchWithdrawalAccounts() async {
    try {
      _setLoading(true);
      _clearError();

      final token = await SecureStorageService.getAuthToken();
      final response = await ApiService.get(
        endpoint: ApiConstants.withdrawalRequest,
        token: token,
      );

      if (response.success && response.data != null) {
        final data = response.data;
        final withdrawalMethodResponse = WithdrawalMethodResponse.fromJson(
          data,
        );
        if (withdrawalMethodResponse.status &&
            withdrawalMethodResponse.data.isNotEmpty) {
          withdrawalMethods.assignAll(withdrawalMethodResponse.data);

          print("Loaded ${withdrawalMethods.length} withdrawal methods");

          // Auto-select the first withdrawal method and load its details
          final firstMethod = withdrawalMethodResponse.data.first;
          selectedPaymentMethod.value = firstMethod.methodName ?? '';
          selectedWithdrawalMethod.value =
              firstMethod; // Set the complete withdrawal method object
          print(
            "Auto-selected method: ${firstMethod.methodName} with slug: ${firstMethod.methodSlug}",
          );

          if (firstMethod.methodSlug != null) {
            fetchWithdrawalMethodDetails(
              firstMethod.methodSlug!,
              preselectedAccountNumber: _preselectedAccountNumber,
            );
          }
        } else {
          errorMessage.value =
              withdrawalMethodResponse.message.isNotEmpty
                  ? withdrawalMethodResponse.message
                  : "Something went wrong";
          Get.back();
        }
      } else {
        errorMessage.value = response.message ?? "Something went wrong";
        Get.back();
      }
    } catch (e) {
      errorMessage.value = "Error while fetching withdrawal methods: $e";
      Get.back();
    } finally {
      _setLoading(false);
    }
  }

  // Method to set preselected account number (called from screen)
  void setPreselectedAccountNumber(String? accountNumber) {
    _preselectedAccountNumber = accountNumber;
    print(
      "WithdrawalController: Set preselected account number: \"$accountNumber\"",
    );
  }

  Future<void> fetchWithdrawalMethodDetails(
    String slug, {
    String? preselectedAccountNumber,
  }) async {
    // Use the passed parameter or fall back to stored value
    final accountNumberToUse =
        preselectedAccountNumber ?? _preselectedAccountNumber;
    print(
      "WithdrawalController: fetchWithdrawalMethodDetails called with slug: $slug, preselectedAccountNumber: \"$preselectedAccountNumber\", stored: \"$_preselectedAccountNumber\", using: \"$accountNumberToUse\"",
    );
    try {
      _setLoading(true);
      _clearError();

      // Reset flags initially
      showNoDataView.value = false;
      noDataMessage.value = '';
      hasReceivedInitialResponse.value = false;

      // Clear selected crypto and bank accounts when method changes
      selectedCryptoAccount.value = null;
      selectedBankAccount.value = null;

      final token = await SecureStorageService.getAuthToken();
      final response = await ApiService.get(
        endpoint: "${ApiConstants.withdrawalMethods}$slug",
        token: token,
      );

      print("response is on withdraelae Controller-->${response.data}");
      print("response.success: ${response.success}");
      print("userMT5Accounts length: ${userMT5Accounts.length}");
      print("wallet data: ${wallet.value?.walletBalance}");

      // Process response and set all state BEFORE setting loading to false
      bool shouldShowNoData = false;
      String noDataMsg = '';

      // First, check if response is successful and has valid data
      if (response.success && response.data != null) {
        try {
          final data = WithdrawalMethodDetailResponse.fromJson(response.data);
          if (data.status == true) {
            // Success - hide no data view and show form
            print("Success - hiding no data view, showing form");
            shouldShowNoData = false;
            noDataMsg = '';

            withdrawalMethodDetail.value = data;
            userMT5Accounts.assignAll(data.data?.userMT5Accounts ?? []);
            wallet.value = data.data?.wallet;
            ibAccount.value = data.data?.ibaccount;

            print(
              "After loading - userMT5Accounts length: ${userMT5Accounts.length}",
            );
            print(
              "After loading - wallet balance: ${wallet.value?.walletBalance}",
            );

            // Auto-select account if preselectedAccountNumber is provided
            final accountNumberToUse =
                preselectedAccountNumber ?? _preselectedAccountNumber;
            if (accountNumberToUse != null && accountNumberToUse.isNotEmpty) {
              // Normalize preselected account number
              final normalizedPreselected =
                  accountNumberToUse.toString().trim();
              print(
                "WithdrawalController: Attempting to pre-select account: \"$normalizedPreselected\"",
              );
              print(
                "WithdrawalController: Starting to search through ${userMT5Accounts.length} accounts...",
              );

              // Try to find matching MT5 account
              MT5Account? matchingAccount;
              try {
                final matchingAccounts =
                    userMT5Accounts.where((account) {
                      final accountNumber =
                          account.metaAccountNumber.toString();
                      if (accountNumber.isEmpty) {
                        print(
                          "WithdrawalController: Account has empty metaAccountNumber",
                        );
                        return false;
                      }

                      // Normalize both sides for comparison
                      final normalizedAccount = accountNumber.trim();

                      // Log each comparison attempt
                      print(
                        'WithdrawalController: Comparing list account "$normalizedAccount" (${account.metaAccountNumber.runtimeType}) with preselected "$normalizedPreselected"',
                      );

                      // Try multiple comparison methods
                      final isExactMatch =
                          normalizedAccount == normalizedPreselected;
                      final accountInt = int.tryParse(normalizedAccount);
                      final preselectedInt = int.tryParse(
                        normalizedPreselected,
                      );
                      final isIntMatch =
                          accountInt != null &&
                          preselectedInt != null &&
                          accountInt == preselectedInt;

                      final isMatch = isExactMatch || isIntMatch;

                      if (isMatch) {
                        print(
                          'WithdrawalController: ✅ MATCH FOUND! Account "$normalizedAccount" matches preselected "$normalizedPreselected"',
                        );
                      } else {
                        print(
                          'WithdrawalController: ❌ No match - "$normalizedAccount" != "$normalizedPreselected" (exact: $isExactMatch, int: $isIntMatch)',
                        );
                      }

                      return isMatch;
                    }).toList();

                if (matchingAccounts.isNotEmpty) {
                  matchingAccount = matchingAccounts.first;
                  final matchedAccountNumber =
                      matchingAccount.metaAccountNumber.toString().trim();
                  print(
                    "WithdrawalController: ✅ Successfully matched preselected account: $matchedAccountNumber",
                  );
                  print(
                    "WithdrawalController: Found ${matchingAccounts.length} matching account(s), using first match",
                  );
                } else {
                  print(
                    'WithdrawalController: ❌ No match found for "$normalizedPreselected"',
                  );
                  print(
                    'WithdrawalController: Available account numbers were: ${userMT5Accounts.map((a) => a.metaAccountNumber.toString().trim()).join(", ")}',
                  );
                }
              } catch (e) {
                print(
                  "WithdrawalController: Error during account matching: $e",
                );
              }

              if (matchingAccount != null) {
                selectedAccount.value = matchingAccount.metaAccountNumber;
                print(
                  "WithdrawalController: ✅ Set selectedAccount.value to: ${matchingAccount.metaAccountNumber}",
                );
              } else {
                // Check if it matches wallet ID
                if (wallet.value != null && wallet.value!.walletId != null) {
                  final walletId = wallet.value!.walletId!.trim();
                  if (walletId == normalizedPreselected) {
                    selectedAccount.value = wallet.value!.walletId;
                    print(
                      "WithdrawalController: ✅ Pre-selected wallet: ${wallet.value!.walletId}",
                    );
                  } else {
                    print(
                      "WithdrawalController: ⚠️ Account \"$normalizedPreselected\" not found in available accounts or wallet",
                    );
                    print("WithdrawalController: Wallet ID is: \"$walletId\"");
                    // Don't set selectedAccount if no match found - let it remain unselected
                    // or fall through to default selection below
                  }
                } else {
                  print(
                    "WithdrawalController: ⚠️ Account \"$normalizedPreselected\" not found in available accounts (no wallet available)",
                  );
                  // Don't set selectedAccount if no match found
                }
              }
            } else {
              // If no preselected account, select first available account (existing behavior)
              if (userMT5Accounts.isNotEmpty) {
                selectedAccount.value = userMT5Accounts.first.metaAccountNumber;
                print(
                  "WithdrawalController: Auto-selected first MT5 account: ${userMT5Accounts.first.metaAccountNumber}",
                );
              } else if (wallet.value != null &&
                  wallet.value!.walletId != null &&
                  wallet.value!.walletId!.isNotEmpty) {
                selectedAccount.value = wallet.value!.walletId;
                print(
                  "WithdrawalController: Auto-selected wallet: ${wallet.value!.walletId}",
                );
              }
            }
          } else {
            // API returned status: false - show no data view with message
            print("Status false - showing no data view: ${data.message}");
            shouldShowNoData = true;
            noDataMsg = data.message ?? "Something went wrong";
            errorMessage.value = data.message ?? "Something went wrong";
            // Clear account data
            userMT5Accounts.clear();
            wallet.value = null;
            ibAccount.value = null;
            withdrawalMethodDetail.value = null;
            // DO NOT call Get.back() - stay on screen and show message
          }
        } catch (parseError) {
          print("JSON parsing error: $parseError");
          errorMessage.value = "Error parsing response data";
          // If parsing fails, don't show no data view, just show error toast
          shouldShowNoData = false;
        }
      } else {
        // Response not successful - this handles 403 and other error status codes
        // For 403 with status: false, ApiService._parseApiResponse returns ApiResponse.error()
        // with message containing the API message, but data might be null

        // Check if response.data exists and contains status: false
        Map<String, dynamic>? responseData;
        bool hasStatusFalse = false;

        if (response.data != null) {
          if (response.data is Map<String, dynamic>) {
            responseData = response.data as Map<String, dynamic>;
            hasStatusFalse = responseData['status'] == false;
          }
        }

        // If we have a message from the API (which ApiService extracts from the response),
        // and either:
        // 1. response.data has status: false, OR
        // 2. The message indicates a verification/requirement error
        // Then show the no data view
        if (response.message != null && response.message!.isNotEmpty) {
          final message = response.message!.toLowerCase();
          final isVerificationError =
              message.contains('kyc') ||
              message.contains('verification') ||
              message.contains('required') ||
              message.contains('not allowed') ||
              message.contains('cannot');

          if (hasStatusFalse || isVerificationError) {
            // Show no data view with message from API
            print("Showing no data view with message: ${response.message}");
            shouldShowNoData = true;
            noDataMsg = response.message ?? "Something went wrong";
            errorMessage.value = response.message ?? "Something went wrong";
            // Clear account data
            userMT5Accounts.clear();
            wallet.value = null;
            ibAccount.value = null;
            withdrawalMethodDetail.value = null;
            // DO NOT call Get.back() - stay on screen and show message
          } else {
            // Other errors - error message will be shown automatically
            print("Response not successful, message: ${response.message}");
            errorMessage.value = response.message ?? "Something went wrong";
            // Don't show no data view for other errors
            shouldShowNoData = false;
          }
        } else {
          // No message - don't show no data view
          shouldShowNoData = false;
        }
      }

      // Set all state values BEFORE setting loading to false
      // This ensures UI updates happen atomically
      showNoDataView.value = shouldShowNoData;
      noDataMessage.value = noDataMsg;
      hasReceivedInitialResponse.value = true;
    } catch (e, t) {
      print(" erorore is on withdraelae Controller-->$t");
      errorMessage.value = "Error while fetching withdrawal method details: $e";
      // DO NOT call Get.back() - error message will be shown automatically
      // Don't show no data view for exceptions
      showNoDataView.value = false;
      hasReceivedInitialResponse.value = true;
    } finally {
      // Set loading to false AFTER all state is updated
      _setLoading(false);
    }
  }

  Future<void> submitWithdrawal() async {
    try {
      isOtpLoading.value = true;
      _clearError();

      final token = await SecureStorageService.getAuthToken();
      final response = await ApiService.get(
        endpoint: ApiConstants.withdrawalSendOTPRequest,
        token: token,
        queryParameters: {
          "account_number": selectedAccount.value ?? '',
          "amount":
              withdrawalAmount.value
                  .replaceFirst('\$', "")
                  .replaceFirst(' ', "")
                  .trim(),
          "withdrawalMethod": selectedPaymentMethod.value,
        },
      );

      if (response.success && response.data != null) {
        final data = response.data;

        // Check if data is a Map (object) and has status field
        if (data is Map<String, dynamic> && data.containsKey('status')) {
          if (data['status'] == true) {
            successMessage.value = data['message'] ?? "OTP sent successfully";
            // Set OTP sent flag to show OTP input field
            isOtpSent.value = true;
          } else {
            errorMessage.value = data['message'] ?? "Failed to send OTP";
          }
        } else {
          // Handle case where data is empty array or unexpected format
          errorMessage.value = "Invalid response format";
        }
      } else {
        errorMessage.value = response.message ?? "Something went wrong";
      }
    } catch (e) {
      errorMessage.value = "Error while submitting withdrawal: $e";
    } finally {
      isOtpLoading.value = false;
    }
  }

  // Add withdrawal method (Bank, UPI, Crypto, Local) - Updated to match KYC controller logic
  Future<void> addWithdrawalMethod({
    required String withdrawalMethod, // bank, upi, crypto, local
    required String currency, // USD, INR, etc.
    required String otp,
    required String relationship,
    String? bankHolderName,
    String? bankName,
    String? bankAccountNo,
    String? confirmBankAccountNo,
    String? ifscIban,
    String? bankSwiftCode,
    String? upiHolderName,
    String? upiAddress,
    String? cryptoHolderName,
    String? cryptoAddress,
    String? localHolderName,
    String? proofImagePath, // Path to image file
  }) async {
    try {
      _setLoading(true);
      _clearError();

      final token = await SecureStorageService.getAuthToken();

      // Build request parameters using the same logic as KYC controller
      Map<String, dynamic> requestParams = _buildWithdrawalMethodParams(
        withdrawalMethod: withdrawalMethod,
        currency: currency,
        otp: otp,
        relationship: relationship,
        bankHolderName: bankHolderName,
        bankName: bankName,
        bankAccountNo: bankAccountNo,
        confirmBankAccountNo: confirmBankAccountNo,
        ifscIban: ifscIban,
        bankSwiftCode: bankSwiftCode,
        upiHolderName: upiHolderName,
        upiAddress: upiAddress,
        cryptoHolderName: cryptoHolderName,
        cryptoAddress: cryptoAddress,
        localHolderName: localHolderName,
        proofImagePath: proofImagePath,
      );

      // Use the same approach as KYC controller - always use multipart/form-data
      ApiResponse response;
      if (withdrawalMethod.toLowerCase() == 'local' ||
          proofImagePath == null ||
          proofImagePath.isEmpty) {
        // For local method, use postForm (multipart without file)
        response = await ApiService.postForm(
          endpoint: ApiConstants.withdrawalRequest,
          token: token,
          formData: requestParams,
        );
      } else {
        // For methods requiring file upload, use custom multipart method
        response = await _uploadWithdrawalMethodFile(
          endpoint: ApiConstants.withdrawalRequest,
          token: token,
          file: File(proofImagePath),
          formData: requestParams,
          fileFieldName: _getFileFieldName(withdrawalMethod),
        );
      }

      if (response.success && response.data != null) {
        final data = response.data;

        if (data is Map<String, dynamic> && data.containsKey('status')) {
          if (data['status'] == true) {
            successMessage.value =
                data['message'] ?? "Withdrawal method added successfully";
            // Refresh withdrawal methods list
            await fetchWithdrawalAccounts();
            Get.back();
          } else {
            errorMessage.value =
                data['message'] ?? "Failed to add withdrawal method";
          }
        } else {
          errorMessage.value = "Invalid response format";
        }
      } else {
        errorMessage.value = response.message ?? "Something went wrong";
      }
    } catch (e) {
      errorMessage.value = "Error while adding withdrawal method: $e";
    } finally {
      _setLoading(false);
    }
  }

  // Get OTP for withdrawal method addition
  Future<void> sendWithdrawalMethodOTP() async {
    try {
      isOtpLoading.value = true;
      _clearError();

      final token = await SecureStorageService.getAuthToken();
      final response = await ApiService.get(
        endpoint:
            ApiConstants
                .withdrawalSendOTPRequest, // GET /api/user/withdrawal/sendOTP
        token: token,
      );

      if (response.success && response.data != null) {
        final data = response.data;

        if (data is Map<String, dynamic> && data.containsKey('status')) {
          if (data['status'] == true) {
            isOtpSent.value = true;
            successMessage.value = data['message'] ?? "OTP sent successfully";
          } else {
            errorMessage.value = data['message'] ?? "Failed to send OTP";
          }
        } else {
          errorMessage.value = "Invalid response format";
        }
      } else {
        errorMessage.value = response.message ?? "Something went wrong";
      }
    } catch (e) {
      errorMessage.value = "Error while sending OTP: $e";
    } finally {
      isOtpLoading.value = false;
    }
  }

  // Helper method to get the correct file field name based on withdrawal method
  String _getFileFieldName(String withdrawalMethod) {
    // Use the same field name as KYC controller
    return 'deposit_proof';
  }

  // Build withdrawal method request parameters - Based on KYC controller logic
  Map<String, dynamic> _buildWithdrawalMethodParams({
    required String withdrawalMethod,
    required String currency,
    required String otp,
    required String relationship,
    String? bankHolderName,
    String? bankName,
    String? bankAccountNo,
    String? confirmBankAccountNo,
    String? ifscIban,
    String? bankSwiftCode,
    String? upiHolderName,
    String? upiAddress,
    String? cryptoHolderName,
    String? cryptoAddress,
    String? localHolderName,
    String? proofImagePath,
  }) {
    final params = <String, dynamic>{};

    // Add conditional parameters based on withdrawal method
    if (withdrawalMethod.toLowerCase() == "bank") {
      params.addAll({
        "ifsc_iban": ifscIban ?? '',
        "bank_name": bankName ?? '',
        "bank_holder_name": bankHolderName ?? '',
        "bank_account_no": bankAccountNo ?? '',
        "confirm_bank_account_no": confirmBankAccountNo ?? '',
        "swift_code": bankSwiftCode ?? '',
        "optradio": "IFSC", // Default to IFSC
      });
    } else if (withdrawalMethod.toLowerCase() == "crypto") {
      params.addAll({
        "crypto_holder_name": cryptoHolderName ?? '',
        "crypto_address": cryptoAddress ?? '',
      });
    } else if (withdrawalMethod.toLowerCase() == "upi") {
      params.addAll({
        "upi_holder_name": upiHolderName ?? '',
        "upi_address": upiAddress ?? '',
      });
    } else if (withdrawalMethod.toLowerCase() == "local") {
      params.addAll({"local_holder_name": localHolderName ?? ''});
    }

    // Add common parameters - matching KYC controller structure
    params.addAll({
      "withdrawal_method": withdrawalMethod.toLowerCase(),
      "selectedMethod":
          withdrawalMethod.toLowerCase(), // Must match withdrawal_method
      "currency": currency,
      "belogns_to":
          "", // Note: keeping the typo as it appears in KYC controller
      "relationship": relationship,
      "holder_name":
          bankHolderName ??
          upiHolderName ??
          cryptoHolderName ??
          localHolderName ??
          '',
      "otp": otp,
    });

    // Add proof file path if provided
    if (proofImagePath != null && proofImagePath.isNotEmpty) {
      params['deposit_proof'] = proofImagePath;
    }

    return params;
  }

  // Custom method for uploading withdrawal method files with correct field names
  Future<ApiResponse> _uploadWithdrawalMethodFile({
    required String endpoint,
    required File file,
    required Map<String, dynamic> formData,
    required String fileFieldName,
    String? token,
  }) async {
    try {
      // If no token provided, try to get from secure storage
      String? authToken = token;
      if (authToken == null) {
        authToken = await SecureStorageService.getAuthToken();
      }

      final headers = {
        'Accept': 'application/json',
        if (authToken != null && authToken.isNotEmpty)
          'Authorization': 'Bearer $authToken',
      };

      final uri = Uri.parse('${ApiConstants.baseUrl}$endpoint');
      final request =
          http.MultipartRequest('POST', uri)
            ..headers.addAll(headers)
            ..fields.addAll(
              formData.map((key, value) => MapEntry(key, value.toString())),
            );

      // Check if file exists and is readable
      if (!await file.exists()) {
        throw Exception('File does not exist: ${file.path}');
      }

      final fileSize = await file.length();
      if (fileSize == 0) {
        throw Exception('File is empty: ${file.path}');
      }

      // Add file with the correct field name for withdrawal methods
      request.files.add(
        await http.MultipartFile.fromPath(
          fileFieldName, // Use the correct field name (bank_proof_img, upi_proof_img, etc.)
          file.path,
        ),
      );

      final streamedResponse = await request.send().timeout(
        Duration(seconds: 30),
      );
      final response = await http.Response.fromStream(streamedResponse);

      // Check for 401 status code
      if (response.statusCode == 401) {
        return ApiResponse(success: false, message: 'Unauthorized', data: null);
      }

      // Parse response
      try {
        final responseData = jsonDecode(response.body);
        return ApiResponse(
          success: response.statusCode >= 200 && response.statusCode < 300,
          message: responseData['message'] ?? 'Request completed',
          data: responseData,
        );
      } catch (e) {
        return ApiResponse(
          success: false,
          message: 'Invalid response format: $e',
          data: null,
        );
      }
    } catch (e) {
      return ApiResponse(
        success: false,
        message: 'Upload failed: $e',
        data: null,
      );
    }
  }

  Future<void> submitWithdrawalWithOtp(String otp) async {
    try {
      _setLoading(true);
      _clearError();

      final token = await SecureStorageService.getAuthToken();
      final response = await ApiService.post(
        endpoint: ApiConstants.withdrawalSubmitRequest,
        token: token,
        data: {
          // "withdrawal_method_id":
          // selectedWithdrawalMethod.value?.methodName ?? 1,
          "amount": withdrawalAmount.value,
          "currency": "USD",
          "otp": otp,
          "mt5_account_id": selectedAccount.value ?? '',
        },
      );

      if (response.success && response.data != null) {
        final data = response.data;

        // Check if data is a Map (object) and has status field
        if (data is Map<String, dynamic> && data.containsKey('status')) {
          if (data['status'] == true) {
            successMessage.value =
                data['message'] ?? "Withdrawal submitted successfully";
            // Reset OTP sent flag
            isOtpSent.value = false;
            // Wait a bit for the toast to be visible before navigating back
            Future.delayed(const Duration(milliseconds: 1500), () {
              Get.back();
            });
          } else {
            errorMessage.value = data['message'] ?? "Withdrawal failed";
          }
        } else {
          // Handle case where data is empty array or unexpected format
          // Also check if status and message are at root level (alternative response format)
          if (data is Map<String, dynamic>) {
            // Try to get status and message from root level
            final rootStatus = data['status'];
            final rootMessage = data['message'];

            if (rootStatus == true && rootMessage != null) {
              successMessage.value = rootMessage;
              isOtpSent.value = false;
              // Wait a bit for the toast to be visible before navigating back
              Future.delayed(const Duration(milliseconds: 1500), () {
                Get.back();
              });
            } else {
              errorMessage.value = "Invalid response format";
            }
          } else {
            errorMessage.value = "Invalid response format";
          }
        }
      } else {
        errorMessage.value = response.message ?? "Something went wrong";
      }
    } catch (e) {
      errorMessage.value = "Error while submitting withdrawal: $e";
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool loading) {
    _isLoading.value = loading;
  }

  void _clearError() {
    errorMessage.value = '';
  }

  void clearMessages() {
    errorMessage.value = '';
    successMessage.value = '';
  }
}
