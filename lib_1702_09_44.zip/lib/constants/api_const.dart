import 'package:crm_app/flavor_config.dart';

class ApiConstants {
  // static const String baseUrl = 'https://my.app.com/api/';
  static String baseUrl = FlavorConfig.instance.apiBaseUrl;
  // static const String socketUrl = 'wss://my.app.com:8080';
  static String socketUrl = FlavorConfig.instance.websocketUrl;

  static const String ajax = 'user/';

  static const String login = '${ajax}login';
  static const String forgotPassword = '${ajax}password/email';
  static const String sendOTP = '${ajax}send-otp';
  static const String verifyOTP = '${ajax}verify-otp';
  static const String resetPassword = '${ajax}reset-password';

  // Password reset OTP flow endpoints
  static const String requestPasswordResetOTP = '${ajax}password/forgot';
  static const String verifyPasswordResetOTP = '${ajax}password/verify-otp';
  static const String resetPasswordWithOTP = '${ajax}password/reset';
  static const String deleteAccount = '${ajax}settings/delete-account';
  static const String changePassword = '${ajax}mt5accounts/changepassword';
  static const String changeLeverage = '${ajax}mt5accounts/changeleverage';
  static const String changeUserPassword = '${ajax}settings/change-password';
  static const String register = '${ajax}register';
  static const String dashboard = '${ajax}dashboard';
  static const String profile = '${ajax}settings/profile';
  static const String getMT5Accounts = '${ajax}mt5accounts/get';
  static const String createMT5Account = '${ajax}mt5accounts/create';
  static const String topupDemoAccount = '${ajax}mt5accounts/setbalance';
  static const String syncMT5Accounts = '${ajax}mt5accounts/mt5AccountSync';
  static const String placeOrder = '${ajax}trade/new-order';
  static const String closePositionByPositionId =
      '${ajax}trade/closePositionByPositionId';
  static const String cancelPendingOrder = '${ajax}trade/cancel-pending-order';
  static const String closePendingOrder = '${ajax}trade/closePendingOrder';
  static const String modifyPendingOrder = '${ajax}trade/modify-pending-order';
  static const String closePositions = '${ajax}trade/closePositions';
  static const String updateTPSL = '${ajax}trade/update-tp-sl';
  static const String tradeHistory = '${ajax}trade/tradehistory';
  static const String getInstruments = '${ajax}instruments';
  static const String logout = '${ajax}logout';
  static const String depositList = '${ajax}deposit';
  static const String depositRequest = '${ajax}deposit/depositrequest';
  static const String realPlanDetails = '${ajax}mt5accounts/plandetails';
  static const String getTransactions = '${ajax}transactions';
  static const String depositProofProxy = '${ajax}deposit-proof-proxy/';
  static const String changePrimaryAccount =
      '${ajax}mt5accounts/changePrimaryAccount';

  // Dropdown APIs
  static const String getCountryDropdown = '${ajax}settings/getCountryDropdown';
  static const String getStateDropdown = '${ajax}settings/getStateDropdown';
  static const String getCityDropdown = '${ajax}settings/getCityDropdown';

  // KYC APIs
  static const String kycUpload = '${ajax}kyc/documents/upload';
  static const String kycStatus = '${ajax}kyc';
  static const String getWalletData = '${ajax}internaltransfer';
  static const String currencyList = '${ajax}utility/currency-list';
  static const String withdrawalRequest = '${ajax}withdrawal';
  static const String withdrawalSendOTPRequest = '${ajax}withdrawal/sendOTP';
  static const String withdrawalSubmitRequest =
      '${ajax}withdrawal/withdrawalrequest';
  static const String checkBalance = '${ajax}withdrawal/checkbalance';
  static const String internalTransferRequest =
      '${ajax}internaltransfer/request';
  static const String withdrawalMethods =
      '${ajax}withdrawal/withdrawal-method/';
  static const String bankWithdrawalList =
      '${ajax}withdrawal/getUserWithdrawalMethods';

  // IB (Introducing Broker) APIs
  static const String ibStatus = '${ajax}ib/status';
  static const String ibApplication = '${ajax}ib/application';
  static const String ibDashboard = '${ajax}ib/dashboard';
  static const String ibClients = '${ajax}ib/clients';
  static const String ibSubIbs = '${ajax}ib/sub-ibs';
  static const String ibTradeHistory = '${ajax}ib/trade-history';
  static const String ibStats = '${ajax}ib/stats';
  static const String ibSubIbStructure = '${ajax}ib/sub-ib-structure/';
  static const String ibSubIbSubIbs = '${ajax}ib/sub-ib-sub-ibs/';
  static const String ibSubIbStats = '${ajax}ib/sub-ib-stats/';
  static const String ibStructure = '${ajax}ib/structure';
  static const String ibSubIbApprovalRequests =
      '${ajax}ib/sub-ib-approval-requests';
  // Web-style IB requests list (datatable)
  static const String ibRequestList = '${ajax}ib/ib-request-list';
  static const String ibTrackVisit = '${ajax}ib/track-visit';
  static const String ibCommissionGroups = '${ajax}ib/commission-groups';
  static const String ibManage = '${ajax}ib/manage';

  // App Status APIs
  static const String appVersionCheck = 'app/version-check';

  // // Profile APIs
  // static const String profileUpdate = '${ajax}profile_update.php';
  // static const String getProfile = '${ajax}profile';
}

// struct APIConstant {
    
//     // NEW API
//     static let BaseUrl                          = "https://my.app.com/"
//     static let API                              =  BaseUrl + "api/"
//     static var SocketURL                        = "wss://my.app.com:8080"
            
//     static let AjaxTiles                        = API + "user/"
        
//     static let LoginAPI                         = AjaxTiles + "login"
//     static let RegisterAPI                      = AjaxTiles + "register"
//     static let ForgotPasswordAPI                = AjaxTiles + "password/email"
//     static let ResetPasswordAPI                 = AjaxTiles + "settings/change-password"
//     static let DashBoardAPI                     = AjaxTiles + "dashboard"
//     static let LogoutAPI                        = AjaxTiles + "logout"
//     static let deleteAccountAPI                 = AjaxTiles + "settings/delete-account"
    
//     static let ProfileAPI                       = AjaxTiles + "settings/profile"
//     static let GetCountryAPI                    = AjaxTiles + "settings/getCountryDropdown"
//     static let GetStateAPI                      = AjaxTiles + "settings/getStateDropdown"
//     static let GetCityAPI                       = AjaxTiles + "settings/getCityDropdown"
    
//     static let KYCStatusAPI                     = AjaxTiles + "kyc"
//     static let GetImageFromSlugAPI              = AjaxTiles + "kyc/documents/viewDocument/"
//     static let KYCUploadAPI                     = AjaxTiles + "kyc/documents/upload"
    
//     static let GetMT5Account                    = AjaxTiles + "mt5accounts/get"
//     static let GetMT5LivePackagesAPI            = AjaxTiles + "mt5accounts/plandetails"
//     static let CreatetMT5AccountAPI             = AjaxTiles + "mt5accounts/create"
//     static let UpdateMT5AccountLevarageAPI      = AjaxTiles + "mt5accounts/changeleverage"
//     static let UpdateMT5AccountPasswordAPI      = AjaxTiles + "mt5accounts/changepassword"
//     static let changePrimaryAccountMT5API       = AjaxTiles + "mt5accounts/changePrimaryAccount"
//     static let setDemoAccountBalanceAPI         = AjaxTiles + "mt5accounts/setbalance"

    
//     static let GetInternalTransferAPI           = AjaxTiles + "internaltransfer"
//     static let InternalTransferAPI              = AjaxTiles + "internaltransfer/request"
//     static let TransactionHistoryAPI            = AjaxTiles + "transactions"
    
//     static let DepositTypeAPI                   = AjaxTiles + "deposit"
//     static let DepositAmountAPI                 = AjaxTiles + "deposit/depositrequest"
    
//     static let withdrawalListApi                = AjaxTiles + "withdrawal"
//     static let getWithdrawalByIDAPI             = AjaxTiles + "withdrawal/withdrawal-method/"
//     static let WithdrawalRequestAPI             = AjaxTiles + "withdrawal/withdrawalrequest"
//     static let GetUserWithdrawalMethodsAPI      = AjaxTiles + "withdrawal/getUserWithdrawalMethods"
//     static let getOTPAPI                        = AjaxTiles + "withdrawal/sendOTP"
//     static let CheckBalanceAPI                  = AjaxTiles + "withdrawal/checkbalance"

//     static let GetWalletDetailAPI               = AjaxTiles + "wallet"
    
//     static let BonusAPI                         = AjaxTiles + "bonus"
//     static let BonusClaimListAPI                = AjaxTiles + "bonus/bonusClaimList"
//     static let DepositBonusClaimAPI             = AjaxTiles + "bonus/bonusClaim"
    
//     static let GetCurrencyListAPI               = AjaxTiles + "utility/currency-list"
//     static let CheckIFSCCodeAPI                 = AjaxTiles + "utility/ifsc-code"
//     static let CurrencyRatesAPI                 = AjaxTiles + "utility/currency-rates"
    
    
//     static let ChartAPI                         = BaseUrl + "user/chart/"

//     static let Trade                            = AjaxTiles + "trade/"
    
    
//     static let TradingAPI                      = Trade + "new-order"
//     static let ClosePositionAPI                = Trade + "closePositionByPositionId"

//     static let DeletePendingOrderAPI            = Trade + "closePendingOrder"
//     static let GetScriptDetailsAPI              = Trade + "getSymbolDetails"

//     static let GetTradeHistoryAPI              = Trade + "tradehistory"
//     static let getSymbolAPI                     = Trade + "symbols" // NEW API
    
    
//     // OLD API
    
//     static let RegisterValidationAPI            = AjaxTiles + "register_validation.php"
//     static let LoginWithGoogleAPI               = AjaxTiles + "login_with_google.php"
//     static let AccountListAPI                   = AjaxTiles + "account_list.php"
//     static let CommonAPI                        = AjaxTiles + "common_api.php"
//     static let AddDepositAPI                    = AjaxTiles + "add_deposit.php"
//     static let AppConfigAPI                     = AjaxTiles + "app_config.php"


        
//     static let RemoveKYCAPI                     = AjaxTiles + "kyc_remove_image.php"
    
//     static let GetUserPrefrenceAPI              = AjaxTiles + "get_user_prefrence.php"

//     static let SpinWheelClaimAPI                = AjaxTiles + "spin_wheel_claim.php"
//     static let UpdateProfileAPI                 = AjaxTiles + "profile_update.php"
//     static let GetSocketAPI                     = AjaxTiles + "get_socket_url.php"

//     static let TradeAndWinAPI                   = AjaxTiles + "trade_and_win.php"

//     static let IBApplicationStatusAPI           = AjaxTiles + "ib_application_status.php"
//     static let AddIBApplicationAPI              = AjaxTiles + "add_ibapplication.php"
//     static let GetDashboardAPI                  = AjaxTiles + "get_dashboard.php"
    
    
//     static let PartnershipRequestManageAPI      = AjaxTiles + "partnership_request_manage.php"
//     static let StructuresManageAPI              = AjaxTiles + "structures_manage.php"
//     static let MyTradersAPI                     = AjaxTiles + "my_traders.php"
//     static let SponserMTDataAPI                 = AjaxTiles + "sponser_mt_data_ajax.php"
//     static let FantasticFourOfferAPI            = AjaxTiles + "fantastic_four_offer.php"

    
    
    
//     static let Database                         = BaseUrl + "datatable/"
        
//     static let SpinAndWinListAPI                = Database + "spin_and_win_list.php"
//     static let PartnershipRequestsAPI           = Database + "partnership_requests.php"

//     static let MyStructuresAPI                  = Database + "my_structures.php"

//     static let Trading                          = AjaxTiles + "trading/"

//     static let OpenPendingtradeAPI              = Trading + "get_open_trade.php"
//     static let GetScriptAPI                     = Trading + "get_script.php"
//     static let AddMarketWatchAPI                = Trading + "add_marketwatch.php"
//     static let DeleteMarketWatchAPI             = Trading + "delete_marketwatch.php"
//     static let GetMarketWatchAPI                = Trading + "get_marketwatch.php"

//     static let TradingCloseAPI                  = Trading + "trade_place_close.php"
//     static let UpdateOrderProfitLossAPI         = Trading + "update_order_profit_loss.php"
//     static let ScriptsSortingsAPI               = Trading + "scripts_sortings.php"
//     static let GetSymbolUsdRateAPI              = Trading + "get_symbol_usd_rate.php"
// }