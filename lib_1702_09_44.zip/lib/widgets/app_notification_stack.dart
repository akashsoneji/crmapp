import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:crm_app/controllers/app_notification_controller.dart';
import 'package:crm_app/widgets/app_notification_item.dart';

/// Stack widget to display multiple app-wide notifications
class AppNotificationStack extends StatelessWidget {
  const AppNotificationStack({super.key});

  @override
  Widget build(BuildContext context) {
    // Get the notification controller
    if (!Get.isRegistered<AppNotificationController>()) {
      return const SizedBox.shrink();
    }

    final controller = Get.find<AppNotificationController>();

    return Obx(() {
      final notifications = controller.notifications;
      if (notifications.isEmpty) {
        return const SizedBox.shrink();
      }

      return Positioned(
        top: MediaQuery.of(context).padding.top + 10.h,
        left: 16.w, // Add horizontal padding
        right: 16.w, // Add horizontal padding
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: notifications.map((notification) {
            return AppNotificationItem(notification: notification);
          }).toList(),
        ),
      );
    });
  }
}

