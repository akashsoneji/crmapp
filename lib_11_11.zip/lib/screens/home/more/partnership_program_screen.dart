import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:pipze/constants/color.dart';
import 'package:pipze/constants/text_styles.dart';
import 'package:pipze/controllers/more/more_controller.dart';
import 'package:pipze/services/language_service.dart';

class PartnershipProgramScreen extends StatefulWidget {
  const PartnershipProgramScreen({super.key});

  @override
  State<PartnershipProgramScreen> createState() =>
      _PartnershipProgramScreenState();
}

class _PartnershipProgramScreenState extends State<PartnershipProgramScreen> {
  bool _isApplicationSubmitted = false;

  @override
  Widget build(BuildContext context) {
    final languageService = Get.find<LanguageService>();
    final moreController = Get.find<MoreController>();

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        scrolledUnderElevation: 0.0,
        backgroundColor: AppColors.backgroundLight,
        elevation: 0,
        title: Text(
          languageService.tr('partnership_program'),
          style: AppTextStyles.screenTitle,
        ),
        leading: IconButton(
          icon: SvgPicture.asset("assets/svg/trade/arro_back.svg"),
          onPressed: () => Navigator.of(context).pop(),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Verification Cards Grid
            _buildVerificationCards(
              languageService,
              moreController.dashboardModel.value?.data?.stageCompletion,
            ),

            // Submit IB Application Button
            _buildSubmitButton(
              languageService,
              moreController.dashboardModel.value?.data?.stageCompletion,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVerificationCards(
    LanguageService languageService,
    dynamic stageCompletion,
  ) {
    // Check verification status from API data
    final isEmailVerified = stageCompletion?.emailVerified != null;
    final isMobileVerified = stageCompletion?.mobileVerified != null;
    final isPersonalInfoVerified = stageCompletion?.personalDetails == true;
    final isIbRequestCompleted =
        stageCompletion?.identityVerified == true &&
        stageCompletion?.addressProofVerified == true;

    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 16.w,
      mainAxisSpacing: 16.h,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.1,
      children: [
        _buildVerificationCard(
          icon: 'assets/svg/partnership_program/email.svg',
          title: languageService.tr('email_verification'),
          isCompleted: isEmailVerified,
          isPending: !isEmailVerified,
          onTap: () {
            // Handle email verification
          },
        ),
        _buildVerificationCard(
          icon: 'assets/svg/partnership_program/mobile.svg',
          title: languageService.tr('mobile_verification'),
          isCompleted: isMobileVerified,
          isPending: !isMobileVerified,
          onTap: () {
            // Handle mobile verification
          },
        ),
        _buildVerificationCard(
          icon: 'assets/svg/partnership_program/document-copy.svg',
          title: languageService.tr('personal_information'),
          isCompleted: isPersonalInfoVerified,
          isPending: !isPersonalInfoVerified,
          onTap: () {
            // Handle personal information
          },
        ),
        _buildVerificationCard(
          icon: 'assets/svg/partnership_program/message-question.svg',
          title: languageService.tr('ib_request'),
          isCompleted: isIbRequestCompleted,
          isPending: !isIbRequestCompleted,
          onTap: () {
            // Handle IB request
          },
        ),
      ],
    );
  }

  Widget _buildVerificationCard({
    required String icon,
    required String title,
    required bool isCompleted,
    bool isPending = false,
    required VoidCallback onTap,
  }) {
    return Container(
      width: 163.5,
      height: 98,
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1), // 10% opacity
            blurRadius: 6, // matches Figma blur
            offset: const Offset(0, 0), // X: 0, Y: 0
            spreadRadius: 0,
          ),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12.r),
        child: Padding(
          padding: EdgeInsets.all(0.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Icon with status indicator
              Stack(
                children: [
                  Container(
                    width: 48.w,
                    height: 48.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24.r),
                    ),
                    child: Center(
                      child: SvgPicture.asset(
                        '$icon',
                        width: 30.55.w,
                        height: 30.55.w,
                        colorFilter: ColorFilter.mode(
                          AppColors.primary,
                          BlendMode.srcIn,
                        ),
                      ),
                    ),
                  ),
                  // Status indicator
                  Positioned(
                    top: 0,
                    right: 0,
                    child: Container(
                      width: 20.w,
                      height: 20.w,
                      decoration: BoxDecoration(
                        color:
                            isCompleted
                                ? AppColors.primary
                                : isPending
                                ? Colors.orange
                                : Colors.grey,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                      child: Center(
                        child: Icon(
                          isCompleted
                              ? Icons.check
                              : isPending
                              ? Icons.priority_high
                              : Icons.close,
                          size: 12.w,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              SizedBox(height: 12.h),

              // Title
              Text(
                title,
                style: AppTextStyles.labelOnChartPendingOrder.copyWith(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w400,
                  color: AppColors.textPrimary,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSubmitButton(
    LanguageService languageService,
    dynamic stageCompletion,
  ) {
    // Check if all verifications are completed
    final isEmailVerified = stageCompletion?.emailVerified != null;
    final isMobileVerified = stageCompletion?.mobileVerified != null;
    final isPersonalInfoVerified = stageCompletion?.personalDetails == true;
    final isIbRequestCompleted =
        stageCompletion?.identityVerified == true &&
        stageCompletion?.addressProofVerified == true;

    final canSubmit =
        isEmailVerified &&
        isMobileVerified &&
        isPersonalInfoVerified &&
        isIbRequestCompleted;

    return SizedBox(
      width: double.infinity,
      height: 46.h,
      child: ElevatedButton(
        onPressed:
            _isApplicationSubmitted
                ? () {
                  // Navigate to IB Main Screen
                  Navigator.of(context).pushReplacementNamed('/ib-main');
                }
                : canSubmit
                ? _showIbApplicationDialog
                : null,
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.zero,
          backgroundColor:
              _isApplicationSubmitted || canSubmit
                  ? AppColors.primary
                  : Colors.grey,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
          ),
          elevation: 0,
        ),
        child: Text(
          _isApplicationSubmitted
              ? 'IB Dashboard'
              : languageService.tr('submit_ib_application'),
          style: AppTextStyles.button.copyWith(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  void _showIbApplicationDialog() {
    bool isAgreed = false;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: Container(
                padding: EdgeInsets.all(20.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.r),
                  color: Colors.white,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Center(
                            child: Text(
                              'IB Application',
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w500,
                                height: 1.4,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topRight,
                          child: Container(
                            width: 23.w,
                            height: 23.w,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                            ),
                            child: InkWell(
                              onTap: () => Navigator.of(context).pop(),
                              child: Center(
                                child: SvgPicture.asset(
                                  'assets/svg/partnership_program/cancel.svg',
                                  width: 30.55.w,
                                  height: 30.55.w,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 16.h),

                    // Content
                    Text(
                      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
                      style: TextStyle(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w400,
                        color: AppColors.icongrey,
                        height: 1.33,
                      ),
                    ),

                    SizedBox(height: 20.h),

                    // Checkbox
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: 16.h,
                          width: 16.w,
                          child: Checkbox(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4.r),
                            ),
                            side: BorderSide(color: AppColors.icongrey),
                            overlayColor: WidgetStateProperty.all(
                              AppColors.icongrey,
                            ),
                            value: isAgreed,
                            onChanged: (value) {
                              setDialogState(() {
                                isAgreed = value ?? false;
                              });
                            },
                            activeColor: AppColors.primary,
                          ),
                        ),
                        SizedBox(width: 8.w),
                        Expanded(
                          child: Text(
                            'I agree to the IB Terms',
                            style: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w400,
                              height: 1.58,
                              color: AppColors.icongrey,
                            ),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 20.h),

                    // Submit button
                    SizedBox(
                      width: double.infinity,
                      height: 44.h,
                      child: ElevatedButton(
                        onPressed:
                            isAgreed
                                ? () {
                                  Navigator.of(context).pop();
                                  setState(() {
                                    _isApplicationSubmitted = true;
                                  });
                                }
                                : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.zero,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          elevation: 0,
                        ),
                        child: Text(
                          'Submit',
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
